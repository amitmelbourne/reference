package com.medibank.digital.oshc.activationreminder.model;

import org.springframework.stereotype.Component;


@Component
public class RequestPayload {

    private String funId;

    private String jsonFilename;

    public String getFunId() {
        return funId;
    }

    public void setFunId(String funId) {
        this.funId = funId;
    }

    public String getJsonFilename() {
        return jsonFilename;
    }

    public void setJsonFilename(String jsonFilename) {
        this.jsonFilename = jsonFilename;
    }
}
package com.medibank.digital.oshc.activationreminder.service;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.medibank.digital.oshc.activationreminder.model.RequestPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.util.Map;

public class AUXServiceInvoker implements RequestHandler<RequestPayload, String> {

    private static final Logger logger = LoggerFactory.getLogger(AUXServiceInvoker.class);

    public String handleRequest(RequestPayload requestPayload, Context context) {
        logger.debug("Inside AUXService Invoker..");
        try {
            String auxServiceUrl =System.getenv("auxservice_endpoint");
            MultiValueMap<String, String> multiValueMap = new HttpHeaders();
            multiValueMap.add("Accept", MediaType.APPLICATION_JSON.toString());
            multiValueMap.add("Content-type", MediaType.APPLICATION_JSON.toString());
            RestTemplate restTemplate = new RestTemplate();
            HttpEntity<RequestPayload> entity = new HttpEntity<RequestPayload>(requestPayload, multiValueMap);
            ResponseEntity<Object> response = restTemplate.exchange(auxServiceUrl, HttpMethod.POST, entity, Object.class);

        }  catch (Exception e){
            logger.error("Error while invoking AUX service"+e.toString());

        }
        return "Rerun from Lambda";
    }
}

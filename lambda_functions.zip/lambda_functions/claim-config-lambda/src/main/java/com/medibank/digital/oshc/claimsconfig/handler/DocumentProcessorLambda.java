package com.medibank.digital.oshc.claimsconfig.handler;

import java.io.IOException;
import java.net.URLDecoder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambdaAsyncClient;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.event.S3EventNotification.S3EventNotificationRecord;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.oshc.claimsconfig.model.LambdaRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DocumentProcessorLambda implements RequestHandler<S3Event, String> {

    private static final Logger logger = LoggerFactory.getLogger(DocumentProcessorLambda.class);

    public String handleRequest(S3Event s3event, Context context) {

        try {
            S3EventNotificationRecord record = s3event.getRecords().get(0);
            String srcBucket = record.getS3().getBucket().getName();
            String srcKey = record.getS3().getObject().getKey().replace('+', ' ');
            srcKey = URLDecoder.decode(srcKey, "UTF-8");
            srcKey = srcKey.replace(" ", "");
            String key[] = srcKey.split("/");
            String jsonFileName = key[key.length-1];

            logger.debug(" claim_repository_table_name ========="+System.getenv("claim_repository_table_name"));
            logger.debug(" docgen_api_endpoint ========="+System.getenv("docgen_api_endpoint"));
            logger.debug(" s3_claims_metadata_path========="+System.getenv("s3_claims_metadata_path"));

            logger.debug(" jsonFileName=====================" + jsonFileName);
            LambdaRequest lambdaRequest = new LambdaRequest();
            lambdaRequest.setJsonFileName(jsonFileName);
            lambdaRequest.setClaimsRepositoryTableName(System.getenv("claim_repository_table_name"));
            lambdaRequest.setClaimsMetadataPath(System.getenv("s3_claims_metadata_path"));
            lambdaRequest.setClaimsExceptionPath(System.getenv("s3_claims_exception_path"));
            // lambdaRequest.setDocgenAPIEndpoint(System.getenv("docgen_api_endpoint"));

            lambdaInvoker(lambdaRequest);
            return "Ok";
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String lambdaInvoker(LambdaRequest lambdaRequest){
        logger.debug("In lambdaInvoker...");

        try {
            ObjectMapper mapperObj = new ObjectMapper();
            String payload = mapperObj.writeValueAsString(lambdaRequest);
            logger.debug("Invoking DocGen Inovker lambda with....... "+payload);
            AWSLambdaAsyncClient client = new AWSLambdaAsyncClient();
            client.withRegion(Regions.AP_SOUTHEAST_2);
            InvokeRequest request = new InvokeRequest();
            logger.debug(" lambda function name ========="+System.getenv("lambda_function_name"));
            request.withFunctionName(System.getenv("lambda_function_name")).withPayload(payload);
            InvokeResult invoke = client.invoke(request);
            logger.debug("Result invoking DocGen Inovker Lambda" + ": " + invoke.getPayload());
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("Error while invoking DocGen Inovker Lambda");
        }
        return "";
    }
}

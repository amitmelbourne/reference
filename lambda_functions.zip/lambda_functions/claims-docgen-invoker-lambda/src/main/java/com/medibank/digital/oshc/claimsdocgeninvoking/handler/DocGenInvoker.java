package com.medibank.digital.oshc.claimsdocgeninvoking.handler;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.oshc.claimsdocgeninvoking.model.*;
import com.medibank.digital.oshc.claimsdocgeninvoking.model.Error;
import com.medibank.digital.oshc.claimsdocgeninvoking.util.ClaimDetailsRepository;
import com.medibank.digital.oshc.claimsdocgeninvoking.util.S3BucketReader;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class DocGenInvoker implements RequestHandler<LambdaRequest, String> {

    private static final Logger logger = LoggerFactory.getLogger(DocGenInvoker.class);

    public String handleRequest(LambdaRequest lambdaRequest, Context context) {
        logger.debug("Inside docgen invoker lambda, processing "+lambdaRequest.getJsonFileName());
        JsonGenerator jsonGenerator = null;
        ClaimDetailsRepository claimDetailsRepository = new ClaimDetailsRepository();
        boolean docgenStatus = false;
        String errorMessage = "";
        String errorType="PDF";
        try{
            S3BucketReader s3BucketReader = new S3BucketReader();
            JSONObject docGenJSONObj = s3BucketReader.readJSON(lambdaRequest.getJsonFileName(),lambdaRequest.getClaimsMetadataPath());
            logger.debug("JSON Data for  "+lambdaRequest.getJsonFileName()+":::"+docGenJSONObj);
            try{
                ObjectMapper mapper = new ObjectMapper();
                jsonGenerator = mapper.readValue(String.valueOf(docGenJSONObj), JsonGenerator.class);
                // Invoking docgen call for PDF generation
                logger.debug("Invoking docgen call for PDF generation.........");

                HttpHeaders headers = new HttpHeaders();
                headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);

                MultiValueMap<String, String> multiValueMap = new HttpHeaders();
                multiValueMap.add("Accept", MediaType.APPLICATION_JSON.toString());
                multiValueMap.add("Content-type", MediaType.APPLICATION_JSON.toString());
                RestTemplate restTemplate = new RestTemplate();
                DocumentDetails documentDetails = populateDocumentDetailsForPDF(jsonGenerator);
                HttpEntity<DocumentDetails> entity = new HttpEntity<DocumentDetails>(documentDetails, multiValueMap);
                ResponseEntity<Object> pdfResponse = restTemplate.exchange(jsonGenerator.getClaim().getServiceHost(), HttpMethod.POST, entity, Object.class);
                ResponseEntity<Object> xmlResponse = null;
                //Invoking docgen call for XML generation
                if (pdfResponse.getStatusCode() != null && pdfResponse.getStatusCode().is2xxSuccessful()) {
                    if (pdfResponse.getBody() != null ) {
                        String pdfResp = pdfResponse.getBody().toString();
                        JSONObject docRespJson = new JSONObject(pdfResp.replaceAll("=",":"));
                        String docId = docRespJson.getString("documentId");
                        logger.debug("Document Id from PDF Docgen Call :: " + docId);
                        logger.debug("Invoking docgen call for XML generation...");
                        multiValueMap = new HttpHeaders();
                        multiValueMap.add("Accept", MediaType.APPLICATION_JSON.toString());
                        multiValueMap.add("Content-type", MediaType.APPLICATION_JSON.toString());
                        documentDetails = populateDocumentDetailsForXML(jsonGenerator);
                        entity = new HttpEntity<DocumentDetails>(documentDetails, multiValueMap);
                        errorType = "XML";
                        xmlResponse = restTemplate.exchange(jsonGenerator.getClaim().getServiceHost(), HttpMethod.POST, entity, Object.class);
                    }
                }else{
                    errorMessage = pdfResponse.getStatusCode()+" :: "+pdfResponse.getBody()== null?"Unknown error":pdfResponse.getBody().toString();
                }
                if (xmlResponse != null) {
                    if (xmlResponse.getStatusCode() != null && xmlResponse.getStatusCode().is2xxSuccessful()) {
                        if (xmlResponse.getBody() != null) {
                            String xmlResp = xmlResponse.getBody().toString();
                            JSONObject docRespJson = new JSONObject(xmlResp.replaceAll("=",":"));
                            String docId = docRespJson.getString("documentId");
                            logger.debug("Document Id from XML Docgen Call :: " + docId);
                            docgenStatus = true;
                        }
                    }else{
                        errorMessage = xmlResponse.getStatusCode()+" :: "+xmlResponse.getBody()== null?"Unknown error":xmlResponse.getBody().toString();
                    }
                }
                logger.debug("transId ...."+jsonGenerator.getClaim().getTransactionId());
                //lambdaInvoker(lambdaRequest);
            }catch(Exception e){
                logger.error("Error processing "+ lambdaRequest.getJsonFileName() +": "+e.toString());
                docgenStatus = false;
                errorMessage = e.toString();
            }
            if(docgenStatus){
                claimDetailsRepository.updateClaimDocStatus(jsonGenerator.getClaim().getTransactionId(),lambdaRequest.getClaimsRepositoryTableName());
            }else{
                Error error = new Error();
                error.setErrorDesc(errorMessage);
                error.setErrorType(errorType);
                jsonGenerator.setError(error);
                ObjectMapper mapperObj = new ObjectMapper();
                try {
                    String jsonStr = mapperObj.writeValueAsString(jsonGenerator);
                    AmazonS3 s3Client= AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
                    s3Client.putObject(lambdaRequest.getClaimsExceptionPath(), lambdaRequest.getJsonFileName(), jsonStr);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }catch (Exception e){
            logger.error("Error processing "+ lambdaRequest.getJsonFileName() +": "+e.toString());
        }

        return "OK";
    }
    public DocumentDetails populateDocumentDetailsForPDF(JsonGenerator jsonGenerator){

        Claim claimData = jsonGenerator.getClaim();
        Member memberData = jsonGenerator.getMember();

        DocumentDetails documentDetails = new DocumentDetails();
        documentDetails.setFundId(memberData.getFundId());
        documentDetails.setDocType("PDF");
        documentDetails.setTemplateId("OSHC_ClaimsPdf");
        documentDetails.setConversion(true);
        documentDetails.setMemberId(claimData.getMemberId());

        Map<String,String> dynamicData = new LinkedHashMap<String,String>();
        dynamicData.put("Fund Id",memberData.getFundId());
        logger.debug("claim Lines......"+ jsonGenerator.getClaimLines().size()+"");
        dynamicData.put("datarows", jsonGenerator.getClaimLines().size()+""); // No of list items
        int i=1;
        for(ClaimLines claimLines :jsonGenerator.getClaimLines()){
            dynamicData.put("Name_R"+i, claimLines.getPatientname());
            dynamicData.put("Date_R"+i, claimLines.getServiceDate());
            dynamicData.put("Provider_R"+i, claimLines.getProviderNo());
            dynamicData.put("Item No._R"+i, claimLines.getItemNo());
            dynamicData.put("Cost_R"+i, claimLines.getServiceCost()+"");
            dynamicData.put("Status_R"+i, claimLines.getLineStatus());
            i++;
        }

        dynamicData.put("images", jsonGenerator.getUploads().size()>0?jsonGenerator.getUploads().size()+"":0+""); // No of images
        int j=0;
        for(Uploads uploads : jsonGenerator.getUploads()){
            dynamicData.put("image"+j, uploads.getName());
            dynamicData.put("format"+j, uploads.getType());
            j++;
        }
        dynamicData.put("Benefit Paid", claimData.getTotalBenefitPaid()+"");
        dynamicData.put("Member Number", claimData.getMemberId());
        dynamicData.put("AddressLine_1", memberData.getTitle()+" "+memberData.getFirstName()+" "+memberData.getLastName());
        dynamicData.put("Claim Number", claimData.getClaimId());
        dynamicData.put("Claim Date", claimData.getClaimDate());
        dynamicData.put("AddressLine_2", memberData.getAddressLine1());
        dynamicData.put("AddressLine_3", memberData.getSuburb() +" "+memberData.getState() +" "+memberData.getPostcode());
        dynamicData.put("Claim Total", claimData.getTotalCost()+"");
        dynamicData.put("Claim Result", claimData.getClaimStatus());
        dynamicData.put("FileName",claimData.getFileName());
        logger.debug("dynamicData for "+claimData.getMemberId() +"( PDF generation ) :"+dynamicData);

        documentDetails.setDynamicData(dynamicData);
        return documentDetails;
    }

    public DocumentDetails populateDocumentDetailsForXML(JsonGenerator jsonGenerator){

        DocumentDetails documentDetails = new DocumentDetails();
        Map<String,String> dynamicData = new LinkedHashMap<String,String>();
        Xml xmlData =  jsonGenerator.getXml();
        Member memberData = jsonGenerator.getMember();
        Claim claimdData = jsonGenerator.getClaim();
        int noOfPages = 1;
        if(jsonGenerator.getUploads()!=null)
            noOfPages = noOfPages + jsonGenerator.getUploads().size();
        documentDetails.setFundId(memberData.getFundId());
        dynamicData.put("Category3_Id",xmlData.getCategory3()+"");
        dynamicData.put("Membership_Number",claimdData.getMemberId());
        dynamicData.put("NumberPages",noOfPages+"");
        dynamicData.put("Status_Id",xmlData.getStatus()+"");
        dynamicData.put("FileName",claimdData.getFileName());
        logger.debug("dynamicData for "+claimdData.getMemberId() +"( XML generation ) :"+dynamicData);

        documentDetails.setDynamicData(dynamicData);
        documentDetails.setDocType("XML");
        documentDetails.setTemplateId("OSHC_ClaimsXml");
        documentDetails.setMemberId(claimdData.getMemberId());
        documentDetails.setConversion(true);
        return documentDetails;
    }

}

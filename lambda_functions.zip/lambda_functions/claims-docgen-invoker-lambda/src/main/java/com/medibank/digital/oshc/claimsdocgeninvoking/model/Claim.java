package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "transactionId",
        "memberId",
        "claimId",
        "claimDate",
        "totalCost",
        "totalBenefitPaid",
        "claimStatus",
        "whicsClaimStatus",
        "fileName",
        "serviceHost"
})
public class Claim {

    
    @JsonProperty("transactionId")
    private String transactionId;
     @JsonProperty("memberId")
    private String memberId;
     @JsonProperty("claimId")
    private String claimId;
     @JsonProperty("claimDate")
    private String claimDate;
     @JsonProperty("totalCost")
    private Double totalCost;
     @JsonProperty("totalBenefitPaid")
    private Double totalBenefitPaid;
     @JsonProperty("claimStatus")
    private String claimStatus;
     @JsonProperty("whicsClaimStatus")
    private String whicsClaimStatus;
     @JsonProperty("fileName")
    private String fileName;
    @JsonProperty("serviceHost")
    private String serviceHost;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

     @JsonProperty("transactionId")
    public String getTransactionId() {
        return transactionId;
    }

     @JsonProperty("transactionId")
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

     @JsonProperty("memberId")
    public String getMemberId() {
        return memberId;
    }

     @JsonProperty("memberId")
    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

     @JsonProperty("claimId")
    public String getClaimId() {
        return claimId;
    }

     @JsonProperty("claimId")
    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

     @JsonProperty("claimDate")
    public String getClaimDate() {
        return claimDate;
    }

     @JsonProperty("claimDate")
    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

     @JsonProperty("totalCost")
    public Double getTotalCost() {
        return totalCost;
    }

     @JsonProperty("totalCost")
    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

     @JsonProperty("totalBenefitPaid")
    public Double getTotalBenefitPaid() {
        return totalBenefitPaid;
    }

     @JsonProperty("totalBenefitPaid")
    public void setTotalBenefitPaid(Double totalBenefitPaid) {
        this.totalBenefitPaid = totalBenefitPaid;
    }

     @JsonProperty("claimStatus")
    public String getClaimStatus() {
        return claimStatus;
    }

     @JsonProperty("claimStatus")
    public void setClaimStatus(String claimStatus) {
        this.claimStatus = claimStatus;
    }

     @JsonProperty("whicsClaimStatus")
    public String getWhicsClaimStatus() {
        return whicsClaimStatus;
    }

     @JsonProperty("whicsClaimStatus")
    public void setWhicsClaimStatus(String whicsClaimStatus) {
        this.whicsClaimStatus = whicsClaimStatus;
    }

     @JsonProperty("fileName")
    public String getFileName() {
        return fileName;
    }

     @JsonProperty("fileName")
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @JsonProperty("serviceHost")
    public String getServiceHost() {
        return serviceHost;
    }

    @JsonProperty("serviceHost")
    public void setServiceHost(String serviceHost) {
        this.serviceHost = serviceHost;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}

package com.medibank.digital.oshc.claimsdocgeninvoking.model;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "OSHC_ClaimRecords")
public class ClaimGlobalDetails {
    private String transId;
    private String memberId;
    private String claimId;
    private String claimDate;
    private String totalCost;
    private String totalBenefitPaid;
    private String claimStatus;
    private String whicsClaimStatus;
    private String category1;
    private String category2;
    private String category3;
    private String docStatus;

    @DynamoDBHashKey(attributeName="transactionId")
    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    @DynamoDBAttribute(attributeName = "memberId")
    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    @DynamoDBAttribute(attributeName = "claimId")
    public String getClaimId() {
        return claimId;
    }

    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

    @DynamoDBAttribute(attributeName = "claimDate")
    public String getClaimDate() {
        return claimDate;
    }

    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

    @DynamoDBAttribute(attributeName = "totalCost")
    public String getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(String totalCost) {
        this.totalCost = totalCost;
    }

    @DynamoDBAttribute(attributeName = "totalBenefitPaid")
    public String getTotalBenefitPaid() {
        return totalBenefitPaid;
    }

    public void setTotalBenefitPaid(String totalBenefitPaid) {
        this.totalBenefitPaid = totalBenefitPaid;
    }

    @DynamoDBAttribute(attributeName = "claimStatus")
    public String getClaimStatus() {
        return claimStatus;
    }

    public void setClaimStatus(String claimStatus) {
        this.claimStatus = claimStatus;
    }

    @DynamoDBAttribute(attributeName = "whicsClaimStatus")
    public String getWhicsClaimStatus() {
        return whicsClaimStatus;
    }

    public void setWhicsClaimStatus(String whicsClaimStatus) {
        this.whicsClaimStatus = whicsClaimStatus;
    }

    @DynamoDBAttribute(attributeName = "category1")
    public String getCategory1() {
        return category1;
    }

    public void setCategory1(String category1) {
        this.category1 = category1;
    }

    @DynamoDBAttribute(attributeName = "category2")
    public String getCategory2() {
        return category2;
    }

    public void setCategory2(String category2) {
        this.category2 = category2;
    }

    @DynamoDBAttribute(attributeName = "category3")
    public String getCategory3() {
        return category3;
    }

    public void setCategory3(String category3) {
        this.category3 = category3;
    }

    @DynamoDBAttribute(attributeName = "docStatus")
    public String getDocStatus() {
        return docStatus;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

}

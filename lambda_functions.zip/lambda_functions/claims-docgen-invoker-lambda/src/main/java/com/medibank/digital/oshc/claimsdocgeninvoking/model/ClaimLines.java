package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "claimLineId",
        "lineStatus",
        "serviceDate",
        "patientId",
        "patientName",
        "itemNo",
        "providerNo",
        "providerName",
        "serviceCost",
        "serviceType",
        "benefitPaid"
})
public class ClaimLines {

    @JsonProperty("claimLineId")
    private String claimLineId;

    @JsonProperty("lineStatus")
    private String lineStatus;

    @JsonProperty("serviceDate")
    private String serviceDate;

    @JsonProperty("patientId")
    private String patientId;

    @JsonProperty("patientName")
    private String patientname;

    @JsonProperty("itemNo")
    private String itemNo;

    @JsonProperty("providerNo")
    private String providerNo;

    @JsonProperty("providerName")
    private String providerName;

    @JsonProperty("serviceCost")
    private Double serviceCost;

    @JsonProperty("serviceType")
    private String serviceType;

    @JsonProperty("benefitPaid")
    private Double benefitPaid;

    @JsonProperty("claimLineId")
    public String getClaimLineId() {
        return claimLineId;
    }

    @JsonProperty("claimLineId")
    public void setClaimLineId(String claimLineId) {
        this.claimLineId = claimLineId;
    }

    @JsonProperty("lineStatus")
    public String getLineStatus() {
        return lineStatus;
    }

    @JsonProperty("lineStatus")
    public void setLineStatus(String lineStatus) {
        this.lineStatus = lineStatus;
    }

    @JsonProperty("serviceDate")
    public String getServiceDate() {
        return serviceDate;
    }

    @JsonProperty("serviceDate")
    public void setServiceDate(String serviceDate) {
        this.serviceDate = serviceDate;
    }

    @JsonProperty("patientId")
    public String getPatientId() {
        return patientId;
    }

    @JsonProperty("patientId")
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    @JsonProperty("patientName")
    public String getPatientname() {
        return patientname;
    }

    @JsonProperty("patientName")
    public void setPatientname(String patientname) {
        this.patientname = patientname;
    }

    @JsonProperty("itemNo")
    public String getItemNo() {
        return itemNo;
    }

    @JsonProperty("itemNo")
    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    @JsonProperty("providerNo")
    public String getProviderNo() {
        return providerNo;
    }

    @JsonProperty("providerNo")
    public void setProviderNo(String providerNo) {
        this.providerNo = providerNo;
    }

    @JsonProperty("providerName")
    public String getProviderName() {
        return providerName;
    }

    @JsonProperty("providerName")
    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    @JsonProperty("serviceCost")
    public Double getServiceCost() {
        return serviceCost;
    }

    @JsonProperty("serviceCost")
    public void setServiceCost(Double serviceCost) {
        this.serviceCost = serviceCost;
    }

    @JsonProperty("serviceType")
    public String getServiceType() {
        return serviceType;
    }

    @JsonProperty("serviceType")
    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    @JsonProperty("benefitPaid")
    public Double getBenefitPaid() {
        return benefitPaid;
    }

    @JsonProperty("benefitPaid")
    public void setBenefitPaid(Double benefitPaid) {
        this.benefitPaid = benefitPaid;
    }
}

package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class DocumentDetails {


    private String docType = null;
    private String templateId = null;
    private Boolean isConversion = null;
    private String memberId = null;
    private String fundId = null;

    private Map<String,String> dynamicData;

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getFundId() {
        return fundId;
    }

    public void setFundId(String fundId) {
        this.fundId = fundId;
    }

    public Map<String, String> getDynamicData() {
        return dynamicData;
    }

    public void setDynamicData(Map<String, String> dynamicData) {
        this.dynamicData = dynamicData;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public Boolean getConversion() {
        return isConversion;
    }

    public void setConversion(Boolean conversion) {
        isConversion = conversion;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class DocumentDetails {\n");

        sb.append("    docType: ").append(toIndentedString(docType)).append("\n");
        sb.append("    templateId: ").append(toIndentedString(templateId)).append("\n");
        sb.append("    isConversion: ").append(toIndentedString(isConversion)).append("\n");
        sb.append("    memberID: ").append(toIndentedString(memberId)).append("\n");
        sb.append("    fundId: ").append(toIndentedString(fundId)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}


package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "errorType",
        "errorDesc"
})
public class Error {

    @JsonProperty("errorType")
    private String errorType;

    @JsonProperty("errorDesc")
    private String errorDesc;

    @JsonProperty("errorType")
    public String getErrorType() {
        return errorType;
    }

    @JsonProperty("errorType")
    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    @JsonProperty("errorDesc")
    public String getErrorDesc() {
        return errorDesc;
    }

    @JsonProperty("errorDesc")
    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }
}

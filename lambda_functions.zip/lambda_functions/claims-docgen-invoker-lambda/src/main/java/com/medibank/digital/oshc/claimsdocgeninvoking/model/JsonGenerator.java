package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "claim",
        "member",
        "claimLines",
        "uploads",
        "xml"
})
public class JsonGenerator {

    @JsonProperty("claim")
    private Claim claim;
    @JsonProperty("member")
    private Member member;
    @JsonProperty("claimLines")
    private List<ClaimLines> claimLines = null;
    @JsonProperty("uploads")
    private List<Uploads> uploads = null;
    @JsonProperty("xml")
    private Xml xml;
    @JsonProperty("error")
    private Error error;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("claim")
    public Claim getClaim() {
        return claim;
    }

    @JsonProperty("claim")
    public void setClaim(Claim claim) {
        this.claim = claim;
    }

    @JsonProperty("member")
    public Member getMember() {
        return member;
    }

    @JsonProperty("member")
    public void setMember(Member member) {
        this.member = member;
    }

    @JsonProperty("claimLines")
    public List<ClaimLines> getClaimLines() {
        return claimLines;
    }

    @JsonProperty("claimLines")
    public void setClaimLines(List<ClaimLines> claimLines) {
        this.claimLines = claimLines;
    }

    @JsonProperty("uploads")
    public List<Uploads> getUploads() {
        return uploads;
    }

    @JsonProperty("uploads")
    public void setUploads(List<Uploads> uploads) {
        this.uploads = uploads;
    }

    @JsonProperty("xml")
    public Xml getXml() {
        return xml;
    }

    @JsonProperty("xml")
    public void setXml(Xml xml) {
        this.xml = xml;
    }

    @JsonProperty("error")
    public Error getError() {
        return error;
    }

    @JsonProperty("error")
    public void setError(Error error) {
        this.error = error;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}


package com.medibank.digital.oshc.claimsdocgeninvoking.model;

public class LambdaRequest {

    private String jsonFileName;
    private String claimsRepositoryTableName;
    private String claimsMetadataPath;
    private String claimsExceptionPath;
    private String docgenAPIEndpoint;

    public String getJsonFileName() {
        return jsonFileName;
    }

    public void setJsonFileName(String jsonFileName) {
        this.jsonFileName = jsonFileName;
    }

    public String getClaimsRepositoryTableName() {
        return claimsRepositoryTableName;
    }

    public void setClaimsRepositoryTableName(String claimsRepositoryTableName) {
        this.claimsRepositoryTableName = claimsRepositoryTableName;
    }

    public String getClaimsMetadataPath() {
        return claimsMetadataPath;
    }

    public void setClaimsMetadataPath(String claimsMetadataPath) {
        this.claimsMetadataPath = claimsMetadataPath;
    }

    public String getClaimsExceptionPath() {
        return claimsExceptionPath;
    }

    public void setClaimsExceptionPath(String claimsExceptionPath) {
        this.claimsExceptionPath = claimsExceptionPath;
    }

    public String getDocgenAPIEndpoint() {
        return docgenAPIEndpoint;
    }

    public void setDocgenAPIEndpoint(String docgenAPIEndpoint) {
        this.docgenAPIEndpoint = docgenAPIEndpoint;
    }
}
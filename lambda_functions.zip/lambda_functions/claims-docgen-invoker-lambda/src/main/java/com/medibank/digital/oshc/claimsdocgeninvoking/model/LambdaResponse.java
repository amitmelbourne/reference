package com.medibank.digital.oshc.claimsdocgeninvoking.model;

public class LambdaResponse {
    String transId;

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }
}

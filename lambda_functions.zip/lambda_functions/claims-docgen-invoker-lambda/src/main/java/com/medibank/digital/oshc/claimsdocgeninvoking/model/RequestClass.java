package com.medibank.digital.oshc.claimsdocgeninvoking.model;

public class RequestClass {
    public String fileName;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}

package com.medibank.digital.oshc.claimsdocgeninvoking.model;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "category1",
        "category2",
        "category3",
        "status"
})
public class Xml {

    @JsonProperty("category1")
    private Integer category1;
    
    @JsonProperty("category2")
    private Integer category2;
    
    @JsonProperty("category3")
    private Integer category3;
    
    @JsonProperty("status")
    private Integer status;
    
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

     @JsonProperty("category1")
    public Integer getCategory1() {
        return category1;
    }

     @JsonProperty("category1")
    public void setCategory1(Integer category1) {
        this.category1 = category1;
    }

     @JsonProperty("category2")
    public Integer getCategory2() {
        return category2;
    }

     @JsonProperty("category2")
    public void setCategory2(Integer category2) {
        this.category2 = category2;
    }

     @JsonProperty("category3")
    public Integer getCategory3() {
        return category3;
    }

     @JsonProperty("category3")
    public void setCategory3(Integer category3) {
        this.category3 = category3;
    }

     @JsonProperty("status")
    public Integer getStatus() {
        return status;
    }

     @JsonProperty("status")
    public void setStatus(Integer status) {
        this.status = status;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}


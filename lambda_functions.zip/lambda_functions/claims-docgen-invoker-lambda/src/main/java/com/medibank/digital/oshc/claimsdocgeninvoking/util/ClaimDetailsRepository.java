package com.medibank.digital.oshc.claimsdocgeninvoking.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.medibank.digital.oshc.claimsdocgeninvoking.model.ClaimGlobalDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClaimDetailsRepository {

    private static final Logger logger = LoggerFactory.getLogger(ClaimDetailsRepository.class);

    AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
    DynamoDBMapper dbMapper = new DynamoDBMapper(amazonDynamoDB);

    public void updateClaimDocStatus(String transID,String tableName){
        logger.info("Entering updateClaimDocStatus");
        try{
            DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
            Table table = dynamoDB.getTable(tableName);
            UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("transactionId", transID)
                    .withUpdateExpression("set docStatus = :val")
                    .withValueMap(new ValueMap().withString(":val", "1")).withReturnValues(ReturnValue.UPDATED_NEW);
            UpdateItemOutcome outcome = table.updateItem(updateItemSpec);
            logger.info("UpdateItem succeeded:\n" + outcome.getItem().toJSONPretty());
            /*ClaimGlobalDetails claimGlobalDetails = readClaimGlobalDetails(transID,tableName);
            if(claimGlobalDetails!=null){
                claimGlobalDetails.setDocStatus("1");
                dbMapper.save(claimGlobalDetails,new DynamoDBMapperConfig.Builder().withTableNameOverride(DynamoDBMapperConfig.TableNameOverride
                        .withTableNameReplacement(tableName)).build());
                logger.info("Exiting updateClaimDocStatus");
            }else{
                logger.debug("Records not found.....");
            }*/
        }catch (Exception e){
            logger.error("Exception in updateClaimDocStatus :"+e.toString());
        }
    }

    public ClaimGlobalDetails readClaimGlobalDetails(String transactionId, String tableName){
        logger.debug("inside readClaimGlobalDetails... ");
        List<ClaimGlobalDetails> claimGlobalDetailsList = new ArrayList<ClaimGlobalDetails>();
        try{
            Map<String, AttributeValue> eav = new HashMap<>();
            eav.put(":transactionId",new AttributeValue().withS(transactionId));
            DynamoDBScanExpression queryExpression = new DynamoDBScanExpression()
                    .withFilterExpression("transactionId= :transactionId")
                    .withExpressionAttributeValues(eav);
            logger.debug("before get records... ");
            claimGlobalDetailsList = dbMapper.scan(ClaimGlobalDetails.class, queryExpression,
                    new DynamoDBMapperConfig.Builder().withTableNameOverride(DynamoDBMapperConfig.TableNameOverride
                            .withTableNameReplacement(tableName)).build());
            logger.debug("Size readClaimGlobalDetails... " +claimGlobalDetailsList.size());
        }catch(Exception e){
            logger.error("Error in ReadClaimGlobalDetails :"+e.toString());
        }
        return claimGlobalDetailsList.size()>0?claimGlobalDetailsList.get(0):null;
    }
}

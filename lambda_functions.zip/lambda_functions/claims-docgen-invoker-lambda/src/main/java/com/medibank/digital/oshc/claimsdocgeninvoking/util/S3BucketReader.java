package com.medibank.digital.oshc.claimsdocgeninvoking.util;


import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@Component
public class S3BucketReader {

    private static  final Logger logger= LoggerFactory.getLogger(S3BucketReader.class);

    public JSONObject readJSON(String fileName,String bucketName) {
        logger.info("Inside S3Bucket Reader, readJSON() method");
        try {
            AmazonS3 s3= AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
            S3Object s3Object = s3.getObject(new GetObjectRequest(bucketName, fileName));
            InputStream inputStreamObject = s3Object.getObjectContent();
            try {
                BufferedReader streamReader = new BufferedReader(new InputStreamReader(inputStreamObject, "UTF-8"));
                StringBuilder responseStrBuilder = new StringBuilder();
                String inputStr;
                while ((inputStr = streamReader.readLine()) != null)
                    responseStrBuilder.append(inputStr);

                JSONObject jsonObject = new JSONObject(responseStrBuilder.toString());
                return jsonObject;

            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            //if something went wrong, return null
            return null;
        } catch (AmazonServiceException ase) {
            logger.error("Caught an AmazonServiceException, which means your request made it "
                    + "to Amazon S3, but was rejected with an error response for some reason.");
            logger.error("Error Message:    " + ase.getMessage());
            logger.error("HTTP Status Code: " + ase.getStatusCode());
            logger.error("AWS Error Code:   " + ase.getErrorCode());
            logger.error("Error Type:       " + ase.getErrorType());
            logger.error("Request ID:       " + ase.getRequestId());
            ase.printStackTrace();
            throw ase;
        } catch (AmazonClientException ace) {
            logger.error("Caught an AmazonClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with S3, "
                    + "such as not being able to access the network.");
            logger.error("Error Message: " + ace.getMessage());
            ace.printStackTrace();
            throw ace;
        } catch (Exception e){
            logger.error("Error Message: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
}

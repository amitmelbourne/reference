package com.medibank.digital.oshc.claimsdocgeninvoking.util;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.lambda.model.ServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.file.Path;

import static java.nio.file.Files.deleteIfExists;

@Component
public class S3BucketUpdater {



    @Autowired
    private AmazonS3 s3;
    private static final Logger logger = LoggerFactory.getLogger(S3BucketUpdater.class);

    public String uploadFile(File file, String fileId, Path path,String bucket_name) {
        try {
            logger.info("Upload file to Amazon S3, bucketName={}, keyName={}", bucket_name, fileId);
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(file.length());
            s3.putObject(new PutObjectRequest(bucket_name, fileId, file));
        } catch (AmazonServiceException ase) {
            handleAmazonClientException("Failed to upload file to Amazon S3", ase);
        } catch (AmazonClientException ace) {
            logger.error("Caught an AmazonClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with S3, "
                    + "such as not being able to access the network.");
            logger.error("Error Message: " + ace.getMessage());
        } catch (Exception e) {
            logger.error("Error Message: " + e.getMessage());
        }
        if (objectExistInBucket(bucket_name, fileId,path)) {
            return fileId;
        } else{
            logger.info("Object doesn't exist");
            return null;
        }
    }


    public boolean objectExistInBucket(String bucketName, String keyName, Path path) throws ServiceException {
        boolean exist = false;
        try {
            if(deleteIfExists(path)){
                logger.info("Temp file deleted");
            }else{
                logger.info("Temp file not found");
            }
            s3.getObjectMetadata(bucketName, keyName);
            exist = true;
        } catch (AmazonClientException ace) {
            handleAmazonClientException(String.format("Failed to get object metadata, bucketName=%s, keyName=%s", bucketName, keyName), ace);
        } catch (Exception e) {
            logger.error("Exception while deleting temp file "+e);
        }
        return exist;
    }
    private void handleAmazonClientException(String logMessage, AmazonClientException ace)  {
        StringBuilder sb = new StringBuilder();
        sb.append(logMessage);
        sb.append("\nError Message:    " + ace.getMessage());
        if (ace instanceof AmazonServiceException) {
            AmazonServiceException ase = (AmazonServiceException)ace;
            sb.append("\nHTTP Status Code: " + ase.getStatusCode());
            sb.append("\nAWS Error Code:   " + ase.getErrorCode());
            sb.append("\nError Type:       " + ase.getErrorType());
            sb.append("\nRequest ID:       " + ase.getRequestId());
        }
        logger.error(sb.toString());

    }



}

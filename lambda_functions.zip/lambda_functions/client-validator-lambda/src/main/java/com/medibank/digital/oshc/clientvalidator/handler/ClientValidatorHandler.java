package com.medibank.digital.oshc.clientvalidator.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.medibank.digital.oshc.clientvalidator.model.LambdaRequest;
import com.medibank.digital.oshc.clientvalidator.util.ClientValidatorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientValidatorHandler implements RequestHandler<LambdaRequest, String> {
    private static final Logger logger = LoggerFactory.getLogger(ClientValidatorHandler.class);
    @Override
    public String handleRequest(LambdaRequest request, Context context) {
        logger.debug("Client Key "+request.getClientKey());
        String clientName = "";
        try {
            ClientValidatorRepository clientValidatorRepository = new ClientValidatorRepository();
            String tableName = System.getenv("partner_details_tablename");
            clientName = clientValidatorRepository.getClientName(request.getClientKey(),tableName);
            logger.debug("Client Name ::"+clientName);

        } catch (Exception e) {
            e.toString();
        }
        return clientName;
    }

}
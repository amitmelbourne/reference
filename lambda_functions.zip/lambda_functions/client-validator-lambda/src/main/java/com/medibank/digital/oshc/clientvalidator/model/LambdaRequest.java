package com.medibank.digital.oshc.clientvalidator.model;

public class LambdaRequest {
    String clientKey=null;

    public String getClientKey() {
        return clientKey;
    }

    public void setClientKey(String clientKey) {
        this.clientKey = clientKey;
    }
}

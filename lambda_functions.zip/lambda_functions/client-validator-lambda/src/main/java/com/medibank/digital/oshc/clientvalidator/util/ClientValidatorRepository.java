package com.medibank.digital.oshc.clientvalidator.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.medibank.digital.oshc.clientvalidator.model.PartnerDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClientValidatorRepository {

    private static final Logger logger = LoggerFactory.getLogger(ClientValidatorRepository.class);

    AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
    DynamoDBMapper dbMapper = new DynamoDBMapper(amazonDynamoDB);

    public String  getClientName(String clientKey,String tableName){
        logger.info("Entering getClientName");

        String clientName ="NA";
        try{
            DynamoDB dynamoDB = new DynamoDB(amazonDynamoDB);
            Table table = dynamoDB.getTable(tableName);

            Map<String, AttributeValue> eav = new HashMap<>();
            eav.put(":PartnerKey",new AttributeValue().withS(clientKey));

            DynamoDBQueryExpression<PartnerDetails> queryExpression = new DynamoDBQueryExpression<PartnerDetails>()
                    .withKeyConditionExpression("PartnerKey= :PartnerKey")
                    .withExpressionAttributeValues(eav);

            List<PartnerDetails> partnerDetailsList = dbMapper.query(PartnerDetails.class, queryExpression,
                    new DynamoDBMapperConfig.Builder().withTableNameOverride(DynamoDBMapperConfig.TableNameOverride
                            .withTableNameReplacement(tableName)).build());
            if(partnerDetailsList.size()>0){
                clientName =  partnerDetailsList.get(0).getPartnerName();
            }

            logger.info("Client Key :" + clientKey +"  Client Name ::"+clientName);

        }catch (Exception e){
            logger.error("Exception in getClientName :"+e.toString());
        }
        return clientName;
    }

}

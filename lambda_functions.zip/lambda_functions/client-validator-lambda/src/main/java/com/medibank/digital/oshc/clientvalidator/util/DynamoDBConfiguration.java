package com.medibank.digital.oshc.clientvalidator.util;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClient;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DynamoDBConfiguration {
    private final static String DYNAMODB_ENDPOINT_DEFAULT_VALUE = "https://dynamodb.ap-southeast-2.amazonaws.com";
    private static final String ROLE_ARN =
            "arn:aws:iam::652299490072:role/allow-dynamoDB-from-Coreprod-account";

    private final Logger log = LoggerFactory.getLogger(getClass());

    @Value("${dynamoDbEndpoint:" + DYNAMODB_ENDPOINT_DEFAULT_VALUE + "}")
    private String dynamoDbEndpoint;

    @Value("${crossaccountsettings:false}")
    private boolean crossaccountsettings;

    @Bean
    public AmazonDynamoDB amazonDynamoDb() {
        System.out.println("inside the amazonDynamoDb method to initiate the client ");
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setProtocol(Protocol.HTTPS);
        clientConfig.setProxyHost("proxy.aws.medibank.local");
        clientConfig.setProxyPort(8080);

        AmazonDynamoDB dynamoClient=null;
        if(crossaccountsettings) {
        AWSSecurityTokenServiceClient stsClient = new
                AWSSecurityTokenServiceClient(clientConfig);

        AssumeRoleRequest assumeRequest = new AssumeRoleRequest()
                .withRoleArn(ROLE_ARN)
                .withDurationSeconds(3600)
                .withRoleSessionName("demo");

        AssumeRoleResult assumeResult =
                stsClient.assumeRole(assumeRequest);

        BasicSessionCredentials temporaryCredentials =
                new BasicSessionCredentials(
                        assumeResult.getCredentials().getAccessKeyId(),
                        assumeResult.getCredentials().getSecretAccessKey(),
                        assumeResult.getCredentials().getSessionToken());

        System.out.println(assumeResult.getCredentials().getAccessKeyId());
        System.out.println(assumeResult.getCredentials().getSecretAccessKey());
        System.out.println(assumeResult.getCredentials().getSessionToken());
        dynamoClient = AmazonDynamoDBClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(temporaryCredentials)).withClientConfiguration(clientConfig).withRegion(Regions.AP_SOUTHEAST_2).build();
        }else {
            dynamoClient = AmazonDynamoDBClientBuilder.standard().withCredentials(new InstanceProfileCredentialsProvider(false)).withClientConfiguration(clientConfig).withRegion(Regions.AP_SOUTHEAST_2).build();
        }
        return dynamoClient;



        /*log.trace("Entering amazonDynamoDb()");
        AmazonDynamoDB client = new AmazonDynamoDBClient();
        log.info("Using DynamoDb endpoint {}", dynamoDbEndpoint);
        client.setEndpoint(dynamoDbEndpoint);
        return client;*/
    }

    @Bean
    public DynamoDBMapper dynamoDbMapper(AmazonDynamoDB amazonDynamoDB) {

        log.trace("Entering dynamoDbMapper()");
        return new DynamoDBMapper(amazonDynamoDB);
    }

}


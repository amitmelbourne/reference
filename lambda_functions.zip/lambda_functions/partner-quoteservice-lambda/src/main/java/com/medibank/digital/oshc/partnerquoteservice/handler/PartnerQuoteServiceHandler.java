package com.medibank.digital.oshc.partnerquoteservice.handler;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteRequest;
import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteRequestTable;
import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteResponse;
import com.medibank.digital.oshc.partnerquoteservice.model.QuoteRequest;
import com.medibank.digital.oshc.partnerquoteservice.service.PartnerQuoteService;
import com.medibank.digital.oshc.partnerquoteservice.util.QuoteServiceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PartnerQuoteServiceHandler implements RequestHandler<PartnerQuoteRequest, String> {
    private static final Logger logger = LoggerFactory.getLogger(PartnerQuoteServiceHandler.class);

    @Override
    public String handleRequest(PartnerQuoteRequest partnerQuoteRequest, Context context) {
        String quoteAmount = "";
        try {
            partnerQuoteRequest.setEndpointUrl(System.getenv("quote_service_endpoint"));
            String quoteRequestPayloadTable = System.getenv("quote_request_payload_table");

            QuoteServiceRepository quoteServiceRepository = new QuoteServiceRepository();
            PartnerQuoteService partnerQuoteService = new PartnerQuoteService();
            PartnerQuoteRequestTable partnerQuoteRequestPayload  = populatePartnerQuoteRequestPayload(partnerQuoteRequest);
            if (partnerQuoteRequest.getClientName() != null && !partnerQuoteRequest.getClientName().equalsIgnoreCase("")) {
                PartnerQuoteResponse partnerQuoteResponse = partnerQuoteService.getPartnerQuoteFromQuoteSVC(partnerQuoteRequest);
                quoteAmount =partnerQuoteResponse.getQuoteAmount();
                partnerQuoteRequestPayload.setValid(0);
            } else {
                partnerQuoteRequestPayload.setValid(1);
            }
            partnerQuoteRequestPayload.setId(partnerQuoteService.getSequenceId());
            quoteServiceRepository.loadPartnerRequestPayload(partnerQuoteRequestPayload, quoteRequestPayloadTable);

        } catch (Exception e) {
            logger.error("error in PartnerQuoteServiceHandler"+e.toString());
        }
        logger.debug("quoteAmount ::"+quoteAmount);
        return quoteAmount;
    }



    public PartnerQuoteRequestTable populatePartnerQuoteRequestPayload(PartnerQuoteRequest partnerQuoteRequest) {

        PartnerQuoteRequestTable partnerQuoteRequestPayload = new PartnerQuoteRequestTable();
        QuoteRequest quoteRequest = partnerQuoteRequest.getQuoteRequest();
        partnerQuoteRequestPayload.setStartDate(quoteRequest.getQuoteStart());
        partnerQuoteRequestPayload.setEndDate(quoteRequest.getQuoteEnd());
        partnerQuoteRequestPayload.setPartner(quoteRequest.getPartnerRef());
        partnerQuoteRequestPayload.setScale(quoteRequest.getScaleId().getValue());
        partnerQuoteRequestPayload.setFundId(quoteRequest.getFund()+"");
        partnerQuoteRequestPayload.setProduct("ESN");

        return partnerQuoteRequestPayload;

    }

}



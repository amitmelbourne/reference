package com.medibank.digital.oshc.partnerquoteservice.model;

public class PartnerQuoteRequest {
    private String clientKey = null;
    private String clientName = null;
    private String endpointUrl = null;
    private String transactionId = null;
    private String bpId = null;
    private QuoteRequest quoteRequest;

    public String getClientKey() { return clientKey;  }

    public void setClientKey(String clientKey) { this.clientKey = clientKey; }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getEndpointUrl() {
        return endpointUrl;
    }

    public void setEndpointUrl(String endpointUrl) {
        this.endpointUrl = endpointUrl;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getBpId() {
        return bpId;
    }

    public void setBpId(String bpId) {
        this.bpId = bpId;
    }

    public QuoteRequest getQuoteRequest() {
        return quoteRequest;
    }

    public void setQuoteRequest(QuoteRequest quoteRequest) {
        this.quoteRequest = quoteRequest;
    }

}

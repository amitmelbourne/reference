package com.medibank.digital.oshc.partnerquoteservice.model;

import java.io.Serializable;
public class QuoteDetails implements Serializable {

    private String quoteId;
    private String amount;
    private String startDate;
    private String visaEndDate;
    private Scope product;
    private String courseCompletionDate;
    private Integer fundId;

    public enum Scope {
        S, D, F, P;
    }

    public Integer getFundId() {
        return fundId;
    }

    public void setFundId(Integer fundId) {
        this.fundId = fundId;
    }

    public String getCourseCompletionDate() {
        return courseCompletionDate;
    }

    public void setCourseCompletionDate(String courseCompletionDate) {
        this.courseCompletionDate = courseCompletionDate;
    }

    public Scope getProduct() {
        return product;
    }

    public void setProduct(Scope product) {
        this.product = product;
    }

    public String getQuoteId() {
        return quoteId;
    }

    public void setQuoteId(String quoteId) {
        this.quoteId = quoteId;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getVisaEndDate() {
        return visaEndDate;
    }

    public void setVisaEndDate(String visaEndDate) {
        this.visaEndDate = visaEndDate;
    }
}

package com.medibank.digital.oshc.partnerquoteservice.model;


import java.util.Objects;

public class QuoteRequest {
    private String partnerRef = null;
    private String quoteStart = null;
    private String quoteEnd = null;

    public enum ScaleIdEnum {
        S("S"),

        F("F"),

        P("P"),

        D("D");

        private String value;

        ScaleIdEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static ScaleIdEnum fromValue(String text) {
            for (ScaleIdEnum b : ScaleIdEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            return null;
        }
    }

    private ScaleIdEnum scaleId = null;

    public enum FundEnum {
        MPL("MPL"),

        AHM("AHM");

        private String value;

        FundEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static FundEnum fromValue(String text) {
            for (FundEnum b : FundEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            return null;
        }
    }

    private FundEnum fund = null;

    public enum ProductEnum {
        ESN("ESN");

        private String value;

        ProductEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return String.valueOf(value);
        }

        public static ProductEnum fromValue(String text) {
            for (ProductEnum b : ProductEnum.values()) {
                if (String.valueOf(b.value).equals(text)) {
                    return b;
                }
            }
            return null;
        }

    }

    private ProductEnum product = null;

    public String getPartnerRef() {
        return partnerRef;
    }

    public void setPartnerRef(String partnerRef) {
        this.partnerRef = partnerRef;
    }

    public String getQuoteStart() {
        return quoteStart;
    }

    public void setQuoteStart(String quoteStart) {
        this.quoteStart = quoteStart;
    }

    public String getQuoteEnd() {
        return quoteEnd;
    }

    public void setQuoteEnd(String quoteEnd) {
        this.quoteEnd = quoteEnd;
    }


    public ScaleIdEnum getScaleId() {
        return scaleId;
    }

    public void setScaleId(ScaleIdEnum scaleId) {
        this.scaleId = scaleId;
    }

    public FundEnum getFund() {
        return fund;
    }

    public void setFund(FundEnum fund) {
        this.fund = fund;
    }

    public ProductEnum getProduct() {
        return product;
    }

    public void setProduct(ProductEnum product) {
        this.product = product;
    }


    @Override
    public int hashCode() {
        return Objects.hash(partnerRef, quoteStart, quoteEnd, scaleId, fund, product);
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class QuoteRequest {\n");

        sb.append("    partnerRef: ").append(toIndentedString(partnerRef)).append("\n");
        sb.append("    quoteStart: ").append(toIndentedString(quoteStart)).append("\n");
        sb.append("    quoteEnd: ").append(toIndentedString(quoteEnd)).append("\n");
        sb.append("    scaleId: ").append(toIndentedString(scaleId)).append("\n");
        sb.append("    fund: ").append(toIndentedString(fund)).append("\n");
        sb.append("    product: ").append(toIndentedString(product)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}


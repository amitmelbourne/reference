package com.medibank.digital.oshc.partnerquoteservice.service;

import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteRequest;
import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteResponse;
import com.medibank.digital.oshc.partnerquoteservice.model.QuoteDetails;
import com.medibank.digital.oshc.partnerquoteservice.model.QuoteRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

public class PartnerQuoteService {
    private static final Logger logger = LoggerFactory.getLogger(PartnerQuoteService.class);

    public PartnerQuoteResponse getPartnerQuoteFromQuoteSVC(PartnerQuoteRequest partnerQuoteRequest) throws Exception {
        PartnerQuoteResponse partnerQuoteResponse = null;
        try {
            QuoteRequest quoteRequest = partnerQuoteRequest.getQuoteRequest();
            int fundId = 0;
            if(quoteRequest.getFund().getValue().equals("MPL")){
                fundId = 17;
            }else if(quoteRequest.getFund().getValue().equals("AHM")){
                fundId = 16;
            }

            String queryParams = "startDate=" + quoteRequest.getQuoteStart() + "&visaEndDate=" + quoteRequest.getQuoteEnd() +
                    "&scope=" + quoteRequest.getScaleId().getValue() + "&fundId=" + fundId;

            RestTemplate restTemplate = new RestTemplate();
            MultiValueMap<String, String> multiValueMap = new HttpHeaders();
            multiValueMap.set("clientKey", partnerQuoteRequest.getClientKey());
            multiValueMap.set("transactionId", partnerQuoteRequest.getTransactionId());
            multiValueMap.set("bpId", partnerQuoteRequest.getBpId());
            HttpEntity entity = new HttpEntity(multiValueMap);

            ResponseEntity<QuoteDetails> response = null;
            response = restTemplate.exchange(partnerQuoteRequest.getEndpointUrl() + queryParams, HttpMethod.GET, entity, QuoteDetails.class);
            QuoteDetails quoteDetails = response.getBody();
            logger.debug("Quote Amount ::" + quoteDetails.getAmount());

            partnerQuoteResponse = new PartnerQuoteResponse();
            partnerQuoteResponse.setPartnerRef(partnerQuoteRequest.getClientName());
            partnerQuoteResponse.setQuoteAmount(quoteDetails.getAmount());

        } catch (Exception e) {
            logger.error("error in PartnerQuote " + e.toString());
        }

        return partnerQuoteResponse;

    }

    public int getSequenceId() {

        String endPoint = System.getenv("token_service_endpoint");
        Integer sequenceId = null;

        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", String.valueOf(MediaType.APPLICATION_JSON));
        HttpEntity entity = new HttpEntity(headers);
        RestTemplate client = new RestTemplate();
        ResponseEntity seqResponse = client.exchange(endPoint, HttpMethod.GET, entity, Object.class);
        if (seqResponse.getStatusCode().equals(HttpStatus.OK) && seqResponse.getBody() != null) {
            String tokenResp = seqResponse.getBody().toString();
            JSONObject tokenRespJson = new JSONObject(tokenResp.replaceAll("=", ":"));
            sequenceId = tokenRespJson.getInt("value");
        }
        return sequenceId;
    }
}

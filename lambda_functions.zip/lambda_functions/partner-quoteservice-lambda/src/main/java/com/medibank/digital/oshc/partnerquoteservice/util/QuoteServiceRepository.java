package com.medibank.digital.oshc.partnerquoteservice.util;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.medibank.digital.oshc.partnerquoteservice.model.PartnerQuoteRequestTable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuoteServiceRepository {

    private static final Logger logger = LoggerFactory.getLogger(QuoteServiceRepository.class);
    AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
    DynamoDBMapper dbMapper = new DynamoDBMapper(amazonDynamoDB);


    public void loadPartnerRequestPayload(PartnerQuoteRequestTable partnerQuoteRequestPayload, String tableName) {
        logger.info("Entering loadPartnerRequestPayload");
        try {
           dbMapper.save(partnerQuoteRequestPayload, new DynamoDBMapperConfig.Builder()
                    .withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement(tableName)).build());

        } catch (Exception e) {
            logger.error("Exception in loadPartnerRequestPayload :" + e.toString());
        }
    }
}


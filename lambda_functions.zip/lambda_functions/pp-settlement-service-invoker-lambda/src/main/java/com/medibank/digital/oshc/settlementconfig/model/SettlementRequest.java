package com.medibank.digital.oshc.settlementconfig.model;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SettlementRequest {

    private List<String> fileNamesList;
    private String partnerId;
    private String partnerName;

    public List<String> getFileNamesList() {
        return fileNamesList;
    }

    public void setFileNamesList(List<String> fileNamesList) {
        this.fileNamesList = fileNamesList;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }


}

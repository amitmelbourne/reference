package com.medibank.digital.oshc.settlementconfig.service;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.medibank.digital.oshc.settlementconfig.model.RequestClass;
import com.medibank.digital.oshc.settlementconfig.model.SettlementRequest;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.util.*;

public class SettlementConfig implements RequestHandler<RequestClass, String> {

    private Object input;

    @Override
    public String handleRequest(RequestClass request, Context context) {

     try {
            String settlementAPIUrl =request.getSettlementAPIUrl();
            try{
                SettlementRequest settlementRequest = new SettlementRequest();
                settlementRequest.setFileNamesList(request.getFileNamesList());
                settlementRequest.setPartnerId(request.getPartnerId());
                settlementRequest.setPartnerName(request.getPartnerName());
                MultiValueMap<String, String> multiValueMap = new HttpHeaders();
                multiValueMap.add("Accept", MediaType.APPLICATION_JSON.toString());
                multiValueMap.add("Content-type", MediaType.APPLICATION_JSON.toString());
                RestTemplate restTemplate = new RestTemplate();
                HttpEntity<SettlementRequest> entity = new HttpEntity<SettlementRequest>(settlementRequest, multiValueMap);
                ResponseEntity<Map> response = restTemplate.exchange(settlementAPIUrl, HttpMethod.POST, entity, Map.class);

            }catch(Exception e){
                System.out.println("Exception .... "+e.toString());
            }
        }  catch (Exception e){

        }
        return "Rerun from Lambda";
    }



}

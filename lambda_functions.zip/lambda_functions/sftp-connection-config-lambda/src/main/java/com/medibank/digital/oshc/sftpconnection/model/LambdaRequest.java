package com.medibank.digital.oshc.sftpconnection.model;

import java.util.List;

public class LambdaRequest {
    private List<String> fileNamesList;
    private String partnerId;
    private String partnerName;
    private String settlementFunction;
    public String settlementAPIUrl;

    public List<String> getFileNamesList() {
        return fileNamesList;
    }

    public void setFileNamesList(List<String> fileNamesList) {
        this.fileNamesList = fileNamesList;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getSettlementFunction() {
        return this.settlementFunction;
    }

    public void setSettlementFunction(String settlementFunction) {
        this.settlementFunction = settlementFunction;
    }

    public String getSettlementAPIUrl() {
        return settlementAPIUrl;
    }

    public void setSettlementAPIUrl(String settlementAPIUrl) {
        this.settlementAPIUrl = settlementAPIUrl;
    }
}


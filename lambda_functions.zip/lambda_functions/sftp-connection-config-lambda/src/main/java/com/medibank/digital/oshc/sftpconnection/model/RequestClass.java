package com.medibank.digital.oshc.sftpconnection.model;

public class RequestClass {
    public String hostname;
    public String user;
    public String password;
    public String directory;
    public String bucketName;
    public String partnerID;
    public String partnerName;
    public String settlementFunction;
    public String settlementAPIUrl;

    public String getHostname() {
        return hostname;
    }

    public void setHostname(String hostname) {
        this.hostname = hostname;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public String getSettlementAPIUrl() {
        return settlementAPIUrl;
    }

    public void setSettlementAPIUrl(String settlementAPIUrl) {
        this.settlementAPIUrl = settlementAPIUrl;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getPartnerID() {
        return partnerID;
    }

    public void setPartnerID(String partnerID) {
        this.partnerID = partnerID;
    }

    public String getSettlementFunction() {
        return settlementFunction;
    }

    public void setSettlementFunction(String settlementFunction) {
        this.settlementFunction = settlementFunction;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }
}

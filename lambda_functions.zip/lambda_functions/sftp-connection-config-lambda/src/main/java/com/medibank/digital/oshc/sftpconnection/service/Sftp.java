package com.medibank.digital.oshc.sftpconnection.service;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambdaAsyncClient;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.*;
import com.medibank.digital.oshc.sftpconnection.model.LambdaRequest;
import com.medibank.digital.oshc.sftpconnection.model.RequestClass;
import com.medibank.digital.oshc.sftpconnection.util.S3BucketUpdater;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.*;

public class Sftp implements RequestHandler<RequestClass, String> {

    private Object input;
    private static final Logger logger = LoggerFactory.getLogger(Sftp.class);

    @Override
    public String handleRequest(RequestClass request, Context context) {

        S3BucketUpdater s3BucketUpdater = new S3BucketUpdater();
        JSch ssh = new JSch();
        try {

            String hostname = request.getHostname();
            String user = request.getUser();
            String password = request.getPassword();
            String directory = request.getDirectory();
            Session session = ssh.getSession(user, hostname, 22);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setPassword(password);
            session.connect();
            System.out.printf("Connecting...");
            Channel channel = session.openChannel("sftp");
            channel.connect();

            ChannelSftp channelSftp = (ChannelSftp) channel;
            channelSftp.cd(directory);
            Vector<ChannelSftp.LsEntry> fileAndFolderList = channelSftp.ls("*");
            List<String> fileNamesList = new ArrayList<String>();
            for (ChannelSftp.LsEntry item : fileAndFolderList) {
                logger.debug("File Name : "+item.getFilename());
                if(item.getFilename().contains("STL") || item.getFilename().contains("stl")){
                    fileNamesList.add(item.getFilename());
                    InputStream is = channelSftp.get(item.getFilename());
                    s3BucketUpdater.uploadFile(is,item.getFilename(),request);
                    channelSftp.rm(item.getFilename());
                }
            }
            if(fileNamesList!=null & fileNamesList.size()>0){
                LambdaRequest lambdaRequest = new LambdaRequest();
                lambdaRequest.setPartnerId(request.getPartnerID());
                lambdaRequest.setPartnerName(request.getPartnerName());
                lambdaRequest.setFileNamesList(fileNamesList);
                lambdaRequest.setSettlementFunction(request.getSettlementFunction());
                lambdaRequest.setSettlementAPIUrl(request.getSettlementAPIUrl());
                lambdaInvoker(lambdaRequest);
            }else{
                logger.debug("No files from SFTP.......... ");
            }
        } catch (JSchException e) {
            e.printStackTrace();
        } catch (SftpException e) {
            e.printStackTrace();
        } catch (Exception e){

        }
        return "Rerun from Lambda";
    }

    public String lambdaInvoker(LambdaRequest lambdaRequest){

        ObjectMapper mapperObj = new ObjectMapper();

        try {
            String payload = mapperObj.writeValueAsString(lambdaRequest);

            logger.debug("Invoking Settlement lambda with....... "+payload);

            AWSLambdaAsyncClient client = new AWSLambdaAsyncClient();
            client.withRegion(Regions.AP_SOUTHEAST_2);
            InvokeRequest request = new InvokeRequest();
            request.withFunctionName(lambdaRequest.getSettlementFunction()).withPayload(payload);
            InvokeResult invoke = client.invoke(request);
            System.out.println("Result invoking " + "OSHC-PPSettlement" + ": " + invoke);
        } catch (IOException e) {
          e.printStackTrace();
          logger.error("Error while invoking Settlement Lambda");
        }
        return "";
    }


}

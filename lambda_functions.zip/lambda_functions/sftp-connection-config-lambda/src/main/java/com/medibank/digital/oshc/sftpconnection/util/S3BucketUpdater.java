package com.medibank.digital.oshc.sftpconnection.util;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.medibank.digital.oshc.sftpconnection.model.RequestClass;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

@Component
public class S3BucketUpdater {

    private static final Logger logger = LoggerFactory.getLogger(S3BucketUpdater.class);

    //certificates & Invoice
    public void uploadFile(InputStream input, String fileName, RequestClass request) throws Exception {
        logger.debug("In upload file method....");
        try {
            AmazonS3 amazonS3Client=AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
            ObjectMetadata metadata = new ObjectMetadata();
            PutObjectResult result = null;

            LocalDateTime date = LocalDateTime.now(ZoneId.of("Australia/Melbourne"));
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            String settlementFileName = request.getPartnerID()+"_"+request.getPartnerName()+"_PayPal_Settlement_Report_"+date.format(formatter)+".csv";
            logger.debug("settlementFileName ...." +settlementFileName);
            amazonS3Client.putObject(new PutObjectRequest(request.getBucketName()+"/"+request.getPartnerID(), fileName, input,metadata));
            logger.debug("Uploading to Archive folder ...." +fileName);
            //amazonS3Client.putObject(new PutObjectRequest(request.getBucketName()+"/archive", fileName, input,metadata));


        } catch (AmazonServiceException ase) {
            handleAmazonClientException("Failed to upload file to Amazon S3", ase);
            throw ase;
        } catch (AmazonClientException ace) {
            logger.error("Caught an AmazonClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with S3, "
                    + "such as not being able to access the network.");
            logger.error("Error Message: " + ace.getMessage());
            ace.printStackTrace();
            throw ace;
        } catch (Exception e) {
            logger.error("Error Message: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    private void handleAmazonClientException(String logMessage, AmazonClientException ace)  {
        StringBuilder sb = new StringBuilder();
        sb.append(logMessage);
        sb.append("\nError Message:    " + ace.getMessage());
        if (ace instanceof AmazonServiceException) {
            AmazonServiceException ase = (AmazonServiceException)ace;
            sb.append("\nHTTP Status Code: " + ase.getStatusCode());
            sb.append("\nAWS Error Code:   " + ase.getErrorCode());
            sb.append("\nError Type:       " + ase.getErrorType());
            sb.append("\nRequest ID:       " + ase.getRequestId());
        }
        logger.error(sb.toString());
    }
}

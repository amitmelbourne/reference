package com.medibank.digital.oshc.wrapperapiconfig.handler;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambdaAsyncClient;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.oshc.wrapperapiconfig.model.LambdaRequest;
import com.medibank.digital.oshc.wrapperapiconfig.model.PartnerQuoteRequest;
import com.medibank.digital.oshc.wrapperapiconfig.model.QuoteRequest;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.ByteBuffer;


public class WrapperAPIConfigHandler implements RequestStreamHandler {
    private static final Logger logger = LoggerFactory.getLogger(WrapperAPIConfigHandler.class);

    @Override
    public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) throws IOException {

        JSONObject responseJson = new JSONObject();

        try {
            StringBuilder sb = new StringBuilder();
            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            JSONObject event = new JSONObject(sb.toString());
            logger.debug("event.. ::"+event.toString());
            String clientKey = "";
            if (event.get("headers") != null) {
                JSONObject hps = (JSONObject) event.get("headers");
                if (hps.get("clientKey") != null) {
                    logger.debug("client key............." + (String) hps.get("clientKey"));
                    clientKey =(String) hps.get("clientKey");
                }
            }
            if (event.get("body") != null) {
                String body = (String) event.get("body");
                JSONObject jsonBody = new JSONObject(body);
                logger.debug("jsonBody:::"+jsonBody.toString());
                QuoteRequest quoteRequest = new QuoteRequest();
                quoteRequest.setPartnerRef((String)jsonBody.get("partnerRef"));
                quoteRequest.setQuoteStart((String)jsonBody.get("quoteStart"));
                quoteRequest.setQuoteEnd((String)jsonBody.get("quoteEnd"));

                quoteRequest.setFund(QuoteRequest.FundEnum.valueOf((String)jsonBody.get("fund")));
                quoteRequest.setProduct(QuoteRequest.ProductEnum.valueOf((String)jsonBody.get("product")));
                quoteRequest.setScaleId(QuoteRequest.ScaleIdEnum.valueOf((String)jsonBody.get("scaleId")));

                String quoteAmount = "";
                LambdaRequest lambdaRequest = new LambdaRequest();
                lambdaRequest.setClientKey(clientKey);
                String clientName = clientValidateLambdaInvoker(lambdaRequest);
                logger.debug("ClientName ::" + clientName);
                if(clientName ==null || clientName.equalsIgnoreCase("NA") || clientName.equalsIgnoreCase("\"NA\"")){
                    logger.debug("Client Not Found ::");
                    JSONObject headerJson = new JSONObject();
                    JSONObject responseBody = new JSONObject();
                    responseBody.put("message","Authorization information is missing or invalid");
                    responseJson.put("isBase64Encoded", false);
                    responseJson.put("statusCode", "401");
                    responseJson.put("headers", headerJson);
                    responseJson.put("body", responseBody.toString());
                }else{
                    quoteAmount = patnerQuoteServiceLambdaInvoker(clientKey,clientName, quoteRequest);
                    JSONObject responseBody = new JSONObject();

                    responseBody.put("quoteAmount", quoteAmount);
                    responseBody.put("partnerRef", quoteRequest.getPartnerRef());

                    JSONObject headerJson = new JSONObject();
                    responseJson.put("isBase64Encoded", false);
                    responseJson.put("statusCode", "200");
                    responseJson.put("headers", headerJson);
                    responseJson.put("body", responseBody.toString());
                    logger.debug("response JSON ...."+responseJson.toString());
                }
            }
        } catch (Exception e) {
            logger.error("error in WrapperAPIConfigHandler" + e.toString());
            JSONObject headerJson = new JSONObject();
            JSONObject responseBody = new JSONObject();
            responseBody.put("message","Error servicing request");

            responseJson.put("statusCode", "500");
            responseJson.put("headers", headerJson);
            responseJson.put("body", responseBody);
        }
        logger.debug("responseJSON :::"+responseJson.toString());
        OutputStreamWriter writer = new OutputStreamWriter(outputStream, "UTF-8");
        writer.write(responseJson.toString());
        writer.close();

    }

    public String clientValidateLambdaInvoker(LambdaRequest lambdaRequest) {

        String clientName = "";
        try {
            ObjectMapper mapperObj = new ObjectMapper();
            String payload = mapperObj.writeValueAsString(lambdaRequest);
            AWSLambdaAsyncClient client = new AWSLambdaAsyncClient();
            client.withRegion(Regions.AP_SOUTHEAST_2);
            InvokeRequest request = new InvokeRequest();
            request.withFunctionName(System.getenv("client_validator_function_name")).withPayload(payload);
            ByteBuffer byteBuffer = client.invoke(request).getPayload();
            clientName = new String(byteBuffer.array(), "UTF-8");
        } catch (IOException e) {
            logger.error("Error :"+e.toString());

        }
        return clientName;
    }

    public String patnerQuoteServiceLambdaInvoker(String clientKey,String clientName, QuoteRequest quoteRequest) {
        String quoteAmount = null;
        ObjectMapper mapperObj = new ObjectMapper();
        try {
            PartnerQuoteRequest partnerQuoteRequest = new PartnerQuoteRequest();
            partnerQuoteRequest.setClientKey(clientKey);
            partnerQuoteRequest.setClientName(clientName);
            partnerQuoteRequest.setQuoteRequest(quoteRequest);
            String payload = mapperObj.writeValueAsString(partnerQuoteRequest);
            AWSLambdaAsyncClient client = new AWSLambdaAsyncClient();
            client.withRegion(Regions.AP_SOUTHEAST_2);
            InvokeRequest request = new InvokeRequest();
            request.withFunctionName(System.getenv("partner_quote_service_function_name")).withPayload(payload);

            ByteBuffer byteBuffer = client.invoke(request).getPayload();
            quoteAmount = new String(byteBuffer.array(), "UTF-8");
            logger.debug("partnerQuoteResponse ::" + quoteAmount);

        } catch (IOException e) {
            logger.error("Error :"+e.toString());

        }
        return quoteAmount.replace("\"","");

    }

}



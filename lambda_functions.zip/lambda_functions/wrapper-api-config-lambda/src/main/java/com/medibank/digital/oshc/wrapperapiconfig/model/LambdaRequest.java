package com.medibank.digital.oshc.wrapperapiconfig.model;

public class LambdaRequest {
    String clientKey=null;

    public String getClientKey() {
        return clientKey;
    }

    public void setClientKey(String clientKey) {
        this.clientKey = clientKey;
    }
}

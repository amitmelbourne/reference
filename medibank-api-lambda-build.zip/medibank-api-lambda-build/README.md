# api-gateway-openapi
---

This repository contains CloudFormation templates and Python code to use AWS
API Gateway in front of the My Medibank APIs.

## Architecture

Because the API microservices are hosted inside a private VPC and AWS API
Gateway can only directly access resources hosted publically on the Internet,
all requests are proxied via a Lambda function that is running inside in the
VPC.

For authenticated requests we use an API Gateway custom authorizer that --
another Lambda function that knows how to authenticate the JWT tokens used and
provide authorisation information to API Gateway.

## CloudFormation templates

The AWS API Gateway Rest API, it's resources and the Lambda functions are
created by the template in `cloudformation/rest-api.yaml`. API Gateway stages
and the Lambda Aliases that they map requests to are created by the template in
`cloudformation/api-stage.yaml`.

By using Lambda Aliases instead of invoking the Lambda functions directly,
we're able to publish immutable versions of the Lambda Functions and adjust
which version is invoked by each stage with minimal difficulty.

## Python Lambda Functions

There are two Lambda functions:

* LambdaProxyFunction - This function is the target for all requests proxied
from API Gateway. Most requests are handed off to a backend microservice but
sessions and some reference requests are handled but the Lambda itself. This
function is also responsible for checking logins against Okta and generating,
signing and encrypting the JWT tokens use for authentication.

* DefaultJWTAuthorizer - This function is an API Gateway customer authorizer.
When an authenticatated request is made, the auth header is handed to this
function for verification. As a custom authorizer, the response from this
function include an IAM policy that's used to check authorisation when API
calls are made. Current requirements are pretty simple, so the function is only
capable of producing two different IAM policies based on the contents of the
JWT.

#!/bin/bash

stackName=$1
stackUrl=$2
StackParams=$3
paramFile="file://${StackParams}"

statuses=(
"CREATE_IN_PROGRESS"
"CREATE_FAILED"
"CREATE_COMPLETE"
"ROLLBACK_IN_PROGRESS"
"ROLLBACK_FAILED"
"ROLLBACK_COMPLETE"
"DELETE_IN_PROGRESS"
"DELETE_FAILED"
"UPDATE_IN_PROGRESS"
"UPDATE_COMPLETE_CLEANUP_IN_PROGRESS"
"UPDATE_COMPLETE"
"UPDATE_ROLLBACK_IN_PROGRESS"
"UPDATE_ROLLBACK_FAILED"
"UPDATE_ROLLBACK_COMPLETE_CLEANUP_IN_PROGRESS"
"UPDATE_ROLLBACK_COMPLETE"
"REVIEW_IN_PROGRESS"
)

exists=$(
    aws cloudformation list-stacks \
    --stack-status-filter ${statuses[*]} \
    --query 'length(StackSummaries[?StackName==`'${stackName}'`])'

)
echo $exists

if [[ ${exists} -ne 1 ]]; then
    aws cloudformation create-stack \
        --stack-name ${stackName} \
        --template-url ${stackUrl} \
        --parameters ${paramFile} \
        --capabilities CAPABILITY_IAM \
    && aws cloudformation wait stack-exists \
        --stack-name ${stackName} \
    && aws cloudformation wait stack-create-complete \
        --stack-name ${stackName}
else
    aws cloudformation update-stack \
        --stack-name ${stackName} \
        --template-url ${stackUrl} \
        --parameters ${paramFile} \
        --capabilities CAPABILITY_IAM \
    && aws cloudformation wait stack-update-complete \
        --stack-name ${stackName}
fi

error_states=( $(echo ${statuses[@]} | xargs -n1 | grep -E 'ROLLBACK_|_FAILED$') )
stack_status=$(
    aws cloudformation list-stacks \
    --stack-status-filter ${error_states[*]} \
    --query 'length(StackSummaries[?StackName==`'${stackName}'`])'
)

exit ${stack_status}
# -*- coding: utf8 -*-
"""
Lambda function to validate authorisation tokens.
"""
import sys
import traceback
import os
from shared import logging
from shared.auth_policy import AuthPolicy, HttpVerb
from shared.util import get_encryption_key
from shared.tokens import Issuers as TokenIssuers
from lambda_function.util import parse_arn, parse_arn_resource, parse_token

__copyright__ = '2017 Medibank Private Limited'

logging.getLogger().info("Default auhtorizer startup.")

def lambda_handler(event, lambda_context):
    """
    A JWT bearer-token based API Gateway custom authorizer.
    """
    logging.set_levels(
        os.getenv('LOG_LEVEL', 'DEBUG'),
        os.getenv('BOTO_LOG_LEVEL', 'ERROR'),
    )


    transaction_info_filter = logging.UpdateRecordFilter(
        aws_request_id = lambda_context.aws_request_id,
    )

    with logging.set_filter(transaction_info_filter):
        log = logging.getLogger(__name__)

        context = parse_arn(event['methodArn'])
        context.update(parse_arn_resource(context.get('arn_resource', '')))
        log.debug(
            'Handling authorization event.',
            extra = dict(
                event = event,
                context = context,
            ),
        )

        try:
            claims = parse_token(str(event['authorizationToken']), get_encryption_key())
            context.update(claims)
        except Exception as ex:
            # The JWE and JWT modules raise exceptions when the signature is
            # invalid or the token has expired. For now we just raise
            # Exception('Unauthorized') which ends up being translated to a 401
            # Unauthorized response by API Gateway.
            log.critical(
                'Exception during token decoding.',
                extra = dict(
                    exception = str(ex),
                    context = context,
                ),
            )
            exc_info = sys.exc_info()
            sys.stderr.write(traceback.format_exc(exc_info[2]))
            raise Exception('Unauthorized')

        principal_id = context.get('claim_sub')
        if not principal_id:
            log.critical(
                'Unable to get subscriber from token claims.',
                extra = dict(
                    context = context,
                ),
            )
            raise Exception('Unauthorized')

        policy = (
            AuthPolicy()
            .withPrincipalId(principal_id)
            .withAwsAccountId(context.get('arn_account_id'))
            .withRestApiId(context.get('resource_api_id'))
            .withRegion(context.get('arn_region'))
            .withStage(context.get('resource_stage'))
        )

        issuer = claims.get('claim_iss')
        if issuer is None:
            # Something is wrong with this token
            raise Exception('Unauthorized')
        elif issuer == TokenIssuers.YoungAdults:
            policy.allowMethod(HttpVerb.PUT, '/members/me/youngadults')
        elif issuer == TokenIssuers.OnlineMemberServices:
            policy.denyMethod(HttpVerb.ALL, '/members/me/youngadults')
            policy.allowAllMethods()
        elif issuer == TokenIssuers.OverseasHealthCover:
            # TODO Implement OSHC policy
            policy.denyAllMethods()
        else:
            # Token has an invalid issuer
            raise Exception('Unauthorized')

        auth_response = policy.build()
        auth_response['context'] = context

        log.debug(
            'Returning successful response.',
            extra = dict(
                auth_response = auth_response,
            ),
        )

        return auth_response

"""
Utility functions.
"""
from itertools import izip
from jwe import decrypt
from jwt import decode

__copyright__ = '2017 Medibank Private Limited'

__all__ = (
    'parse_arn',
    'parse_arn_resource',
    'parse_token',
)

def _prefixed_dict(pfx, keys, values):
    """
    Return a dict -- based on iterables of keys and values -- with a string
    prefixed to each key.
    """
    zipped = izip(keys, values)
    return dict(( (pfx + str(k), str(v)) for k,v in zipped if k ))

def parse_arn(arn):
    """
    Parse an AWS ARN
    """
    return _prefixed_dict(
        'arn_',
        (None, None, None, 'region', 'account_id', 'resource'),
        arn.split(':', 5),
    )

def parse_arn_resource(arn_resource):
    """
    Parse the resource portion is an API Gateway ARN
    """
    return _prefixed_dict(
        'resource_',
        ('api_id', 'stage', 'method', 'path'),
        arn_resource.split('/', 3)
    )

def parse_token(token, encryption_key):
    """
    Decrypt and decode an encrypted Javascript Web Token.
    """
    jwt_token = decrypt(token, encryption_key)
    claims = decode(jwt_token, encryption_key, algorithms=['HS256'])
    return _prefixed_dict(
        'claim_',
        claims.iterkeys(),
        claims.itervalues(),
    )

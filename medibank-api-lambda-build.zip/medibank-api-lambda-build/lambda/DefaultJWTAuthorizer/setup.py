from setuptools import setup, find_packages

setup(
    name             = 'DefaultJWTAuthorizer',
    version          = '0.1',
    description      = 'An AWS Lambda function to parse and validate JWTs presented to AWS API Gateway.',
    url              = 'https://stash.aws.medibank.local/scm/oms/api-gateway-openapi.git',
    author           = 'James Sinclair',
    author_email     = 'james.sinclair@shinesolutions.com.au',
    packages         = find_packages(),
    install_requires = [
        'PyJWT',
        'PyJWE',
    ],
)

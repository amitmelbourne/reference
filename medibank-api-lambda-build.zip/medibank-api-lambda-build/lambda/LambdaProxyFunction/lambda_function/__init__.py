# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
Lambda function to handle Medibank APIs.
"""
import uuid
from shared import logging
import lambda_proxy
from lambda_proxy.lookup import lookup_handler_func, lookup_url_func

def xray_setup():
    """
    Set up reporting to AWS X-Ray.
    """
    #pylint: disable=unused-import,unused-variable
    import boto3
    import botocore
    import requests
    from aws_xray_sdk.core import xray_recorder, patch_all
    patch_all()
xray_setup()

__copyright__ = '2017 Medibank Private Limited'

logging.getLogger().info("Lambda proxy handler startup.")

def handler(event, context):
    """
    Handle an API Gateway Lambda proxy event.
    """
    stage_vars = lambda_proxy.StageVarParser()
    stage_vars.update(event)

    logging.set_levels(stage_vars.log_level, stage_vars.boto_log_level)
    log = logging.getLogger(__name__)

    request_context = event.get('requestContext', {})
    transaction_id = request_context.get('requestId', str(uuid.uuid4()))
    transaction_info_filter = logging.UpdateRecordFilter(
        transactionId  = transaction_id,
        apiId          = request_context.get('apiId'),
        stage          = request_context.get('stage'),
        aws_request_id = getattr(context, 'aws_request_id', None),
    )

    with logging.set_filter(transaction_info_filter):
        handler_func = lookup_handler_func(
            event.get('resource'),
            event.get('httpMethod'),
        )

        url_func = lookup_url_func(
            event.get('resource'),
        )

        cleaned_event = event.copy()
        if 'body' in cleaned_event:
            del cleaned_event['body']


        log.info(
            'Dump request event',
            extra = dict(
                event = cleaned_event,
                handler_func = handler_func.__name__,
                url_func = url_func.__name__,
            ),
        )

        log.debug(
            # TODO We're potentially logging passwords here. Should we encrypt?
            'Dump request event body',
            extra = dict(
                event_body = event.get('body'),
            ),
        )


        event['headers'] = lambda_proxy.Headers(event['headers'])

        err = lambda_proxy.check_content_type(event)
        if err:
            log.error('Content-Type header check failed')
            return err.with_headers(TransactionId = transaction_id)

        err = lambda_proxy.check_payload_json(event['body'])
        if err:
            log.error('Payload parse check failed')
            return err.with_headers(TransactionId = transaction_id)

        try:
            resp = handler_func(event, stage_vars, url_func, transaction_id)
        except Exception as ex:
            log.exception(
                'Unhandled exception in handler function.',
                extra = dict(
                    handler_func = handler_func.__name__,
                    url_func = url_func.__name__,
                    exception = str(ex),
                ),
            )
            resp = lambda_proxy.responses.Error_500_InternalServerError()

        if not resp.get('body'):
            resp.update_headers({
                'Content-Type':   '',
                'Content-Length': 0,
            })

        log.debug(
            'Returning response.',
            extra = dict(
                response = resp,
            )
        )

        return resp.with_headers(TransactionId = transaction_id)

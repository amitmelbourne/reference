# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
An AWS API Gateway Lambda Proxy implementation of the Medibank APIs.
"""
import os
import re
import json
from datetime import timedelta
from base64 import b64decode
from itertools import izip
from shared import logging
from requests.structures import CaseInsensitiveDict
from lambda_proxy import responses

__copyright__ = '2017 Medibank Private Limited'

def check_content_type(event):
    """
    Ensure events that include a body have a 'Content-Type' header and the
    claimed content type is 'application/json'.
    """
    log = logging.getLogger(__name__)

    body = event.get('body')
    if body is None or body == '':
        return None

    content_type = event.get('headers', {}).get('Content-Type')
    if content_type is None or content_type == '':
        log.error('Missing or empty "Content-Type" header')
        return responses.Error_400_BadRequest()

    claimed_content_type = next((
        s.strip().lower()
        for s in content_type.split(';')
    ))
    if claimed_content_type != 'application/json':
        log.error(
            'Unsupported media type',
            extra = dict(
                details = dict(
                    content_type = content_type
                )
            )
        )
        return responses.Error_415_UnsupportedMediaType()

    return None

def check_payload_json(payload):
    """
    Ensure a given payload can be parsed as JSON.
    """
    log = logging.getLogger(__name__)
    if payload is None:
        return None
    try:
        json.loads(payload)
    except Exception:
        log.error('Payload not valid JSON')
        log.debug(
            # TODO We're potentially logging passwords here. Should we encrypt?
            'Payload details',
            extra = dict(payload = payload)
        )
        return responses.Error_400_BadRequest()

    return None

def _parse_timespan(timespan):
    """
    Parse a human-style timestamp and return a datetime.timedelta object.
    Timespans are designated by a number and unit. Any number of number+unit
    pairs may be specified.

    Supported units:
        s: Seconds
        m: Minutes (60 seconds)
        h: Hours (3600 seconds)
        d: Days (86400 seconds)
        w: Weeks (604800 seconds)

    Examples:
        10m  = 10 minutes (600 seconds)
        3h4m = 3 hours 4 minute (11040 seconds)
        2w1d = 2 weeks 1 day (1296000 seconds)
    """
    _multipliers = { 's':1, 'm':60, 'h':60*60, 'd':60*60*24, 'w':60*60*24*7 }
    pairs = re.findall('([0-9]+)([smhdw])', timespan)
    if not pairs:
        raise MalformedTimespanException('The timespan "%s" could be be parsed.'%timespan)
    seconds = 0
    for number, unit in pairs:
        seconds += int(number) * _multipliers.get(unit, 0)
    return timedelta(seconds=seconds)

class StageVarParser(object):
    """
    A utility class to help retrieve and parse API Gateway stage variables.
    """
    _default_mapped_headers = '''
        Accept Content-Type If-Match X-Forwarded-For bpId creationTime memberId
        sessionId timestamp trackingId transactionId userId x-channel x-os x-app-version repeatabilityCreation user-agent RequestID
    '''
    def __init__(self):
        self._stage_vars = {}
        self._request_path = None

    def update(self, event):
        """
        Update the StageVarParser object with an API Gateway Lambda proxy
        event.
        """
        self._request_path = event['path']
        self._stage_vars = event.get('stageVariables', {})

    def _stage_var_no_default(self, name):
        """
        Retrieve a stage variable that has no default value.

        Raises MissingStageVariableException if the stage variable is not found
        in the API Gateway Lambda proxy event.
        """
        if name not in self._stage_vars:
            raise MissingStageVariableException(
                'Stage variable "%s" not found and has no default value.'%name
            )
        else:
            return self._stage_vars[name]

    @property
    def backend_endpoint(self):
        """
        Retrieve the 'backend_endpoint' variable.
        """
        return self._stage_var_no_default('backend_endpoint')

    @property
    def okta_base_url(self):
        """
        Retrieve the 'okta_base_url' variable.
        """
        return self._stage_var_no_default('okta_base_url')

    @property
    def okta_proxies(self):
        """
        Retrieve and decode the 'okta_proxies' variable.
        """
        if 'okta_proxies' not in self._stage_vars:
            return {}
        return json.loads(b64decode(self._stage_vars['okta_proxies']))

    @property
    def session_time(self):
        """
        Retrieve and parse the 'session_time' variable.

        Default: 20m
        """
        return _parse_timespan(self._stage_vars.get('session_time', '20m'))

    @property
    def session_revalidate_time(self):
        """
        Retrieve and parse the 'session_time' variable.

        Default: 10m
        """
        return _parse_timespan(self._stage_vars.get('session_revalidate_time', '10m'))

    @property
    def log_level(self):
        """
        Retrieve the 'log_level' variable.

        Default: INFO
        """
        return self._stage_vars.get('log_level', 'INFO')

    @property
    def boto_log_level(self):
        """
        Retrieve the 'log_level' variable.

        Default: ERROR
        """
        return self._stage_vars.get('boto_log_level', 'ERROR')

    @property
    def request_mapped_headers(self):
        """
        Retrieve and parse the 'request_mapped_headers' variable -- a list if
        headers mapped directly from the client (front end) request through to
        the integration (back end) request.

        Default:
            Accept
            Content-Type
            If-Match
            X-Forwarded-For
            bpId
            creationTime
            memberId
            sessionId
            timestamp
            trackingId
            transactionId
            userId
            x-channel
            x-os
            x-app-version
            repeatabilityCreation
            user-agent
            RequestID
        """
        return self._mapped_headers('request_mapped_headers')
        
    @property
    def response_mapped_headers(self):
        """
        Retrieve and parse the 'request_mapped_headers' variable -- a list if
        headers mapped directly from the integration (back end) response
        through to the client (front end) response.

        Default:
            Accept
            Content-Type
            If-Match
            X-Forwarded-For
            bpId
            creationTime
            memberId
            sessionId
            timestamp
            trackingId
            transactionId
            userId
            x-channel
            x-os
            x-app-version
            repeatabilityCreation
            user-agent
            RequestID
        """
        return self._mapped_headers('response_mapped_headers')

    def _mapped_headers(self, name):
        headers = self._stage_vars.get(name, self._default_mapped_headers)
        return set(headers.strip().lower().split())

class Headers(CaseInsensitiveDict):
    """
    A utility class to make managing request and response headers easier. As a
    subclass of the 'request' module's CaseInsensitiveDict class, key lookup is
    not case-sensitive. In addition, the 'update' method returns 'self' for
    easy chaining and filter methods are provided to allow easier mapping of
    headers between requests and responses.
    """
    def update(self, *args, **kwargs):
        """
        Call the super class 'update' method and return 'self' to allow chaining.

        Example:
            headers = Headers(event_headers).update(transactionId='abc-123')
        """
        super(Headers, self).update(*args, **kwargs)
        return self

    def has_header(self, header):
        """
        Test whether a given header exists in the Headers 'dict'.
        """
        return header in self

    def filter_include(self, iterable):
        """
        Return a new Headers object containing only the headers in an iterable
        of header names. Keys specified in the iterable but not found in the
        Headers object are ignored.
        """
        include_keys = set(( i.lower() for i in iterable ))
        return Headers(
            ( (k,v) for k,v in self.iteritems() if k.lower() in include_keys )
        )

    def filter_exclude(self, iterable):
        """
        Return a new Headers object without the headers in an iterable of
        header names. Keys specified in the iterable but not found in the
        Headers object are ignored.
        """
        exclude_keys = set(( i.lower() for i in iterable ))
        return Headers(
            ( (k,v) for k,v in self.iteritems() if k.lower() not in exclude_keys )
        )

def log_response(resp, verbose = True, sensitive = False, **kwargs):
    """
    Extract some diagnostic information from a 'requests' module 'Response'
    object and return a 'dict' that can be passed to a 'logging' module call.
    """
    if sensitive:
        # TODO Find out how Medibank wants to handle this.
        pass

    keys = ('url', 'status_code', 'reason', 'headers')
    mapped_response = {
        key:getattr(resp, key, None)
        for key in keys
    }

    if verbose:
        try:
            json_response = resp.json()
            mapped_response['json'] = json_response
        except:
            mapped_response['text'] = resp.text

    mapped_response['size'] = len(resp.text)
    mapped_response['latency'] = int(resp.elapsed.total_seconds() * 1000)

    kwargs.update(dict(
        response = mapped_response
    ))

    return kwargs

class MalformedTimespanException(Exception):
    """
    An exception raised when a timespan cannot be parsed.
    """
    pass

class MissingStageVariableException(Exception):
    """
    An exception raised when a stage variable with no default value is
    accessed.
    """
    pass

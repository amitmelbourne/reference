# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
A collections of Python decorators that can be used to wrap handlers.
"""
from functools import wraps
from shared import logging
from lambda_proxy import Headers
from lambda_proxy.handlers._helpers import check_token_valid
from lambda_proxy.responses import Error_401_Unauthorized

__copyright__ = '2017 Medibank Private Limited'

def fix_event_headers(handler):
    """
    A decorator that wraps a request handler which wraps the event's headers in
    our Headers class.
    """
    @wraps(handler)
    def wrapped_handler(event, *args):
        """
        Wrap an API event's headers in our own Headers class.
        """

        event['headers'] = Headers(event['headers'])

        return handler(event, *args)
    return wrapped_handler

def enforce_api_session_token(handler):
    """
    A decorator to enforce APISessionToken expiration and send an updated token
    for valid tokens that are nearing expiration.
    """
    @wraps(handler)
    def wrapped_handler(event, stage_vars, *args):
        """
        Validate the supplied token and update if it's nearing expiration.
        """
        log = logging.getLogger(__name__)
        token_valid, new_token = check_token_valid(event, stage_vars)
        if not token_valid:
            return Error_401_Unauthorized()

        resp = handler(event, stage_vars, *args)

        if new_token is not None:
            log.debug('Setting an updated APISessionToken')
            resp.update_headers(APISessionToken = new_token)

        return resp
    return wrapped_handler

# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
A collections of helpers for request handlers.
"""
import os
import requests
import arrow
from shared import logging
from shared.util import get_okta_api_key
from shared.tokens import OnlineMemberServicesJwt
from lambda_proxy import log_response

__copyright__ = '2017 Medibank Private Limited'

def generate_api_session_token(bp_id, session_id, okta_session):
    """
    Generate a token for use in the APISessionToken header.
    """
    token = (
        OnlineMemberServicesJwt(bp_id)
        .with_expiration(okta_session['expiresAt'])
        .with_claims({
            'bpId': bp_id,
            'sessionId': session_id,
            'token': okta_session['id'],
            'oktaUserId': okta_session['userId'],
            'userId': okta_session['login'],
        })
    )

    return token.jwe

def check_token_valid(event, stage_vars, force_refresh = False):
    """
    Check whether the unwrapped APISessionToken is still valid. If the token is
    close to expiry (or it's explicitly requested), will also refresh the Okta
    session and generate a new token.
    """
    log = logging.getLogger(__name__)

    claims = extract_claims(event)
    if claims is None:
        # The request is unauthenticated so there's no token to check or
        # refresh
        return True, None

    log.debug(
        'Authorizer claims.',
        extra = dict(
            claims = claims,
        )
    )

    now = arrow.utcnow()

    session_expires_at = arrow.get(claims.get('exp', 0))
    session_last_validated_at = arrow.get(claims.get('iat', 0))
    session_age = now - session_last_validated_at

    session_timing_info = dict(
        expires_at = session_expires_at.isoformat(),
        last_validated_at = session_last_validated_at.isoformat(),
        age = session_age.total_seconds(),
        revalidate_time = stage_vars.session_revalidate_time.total_seconds(),
    )

    if session_expires_at < now:
        log.info('Session expired')
        return False, None


    log.debug(
        'Session timing info',
        extra = dict(
            session_timing_info = session_timing_info,
        )
    )
    if session_age > stage_vars.session_revalidate_time or force_refresh:
        log.info(
            'Revalidating session',
            extra = dict(
                sessionId = claims.get('sessionId', None),
            ),
        )
        with requests.Session() as okta_api:
            okta_api.headers.update({
                'Accept':        'application/json',
                'Content-Type':  'application/json',
                'Authorization': ' '.join(('SSWS', get_okta_api_key()))
            })
            if stage_vars.okta_proxies:
                okta_api.proxies = stage_vars.okta_proxies

            okta_refresh = okta_api.post(
                os.path.join(
                    stage_vars.okta_base_url,
                    'api/v1',
                    'sessions',
                    claims.get('token'),
                    'lifecycle/refresh',
                )
            )

            if okta_refresh.status_code != 200:
                log.error(
                    'Unexpected response from Okta',
                    extra = log_response(okta_refresh),
                )
                return False, None

        return True, generate_api_session_token(
            claims['bpId'],
            claims['sessionId'],
            okta_refresh.json(),
        )

    return True, None

def extract_claims(event):
    """
    Extract JWT claims from the requestContext.authorizer object. Because the
    authorizer can only communicate a flat object to us, claims are prefixed
    with 'claims_'.
    """
    authorizer = event.get('requestContext', {}).get('authorizer')

    if authorizer is None:
        return None

    return {
        k.replace('claim_', ''):v
        for k,v in authorizer.iteritems()
        if k.startswith('claim_')
    }

# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
A collection of generic handlers used to implement API Gateway Lambda proxy
functions.
"""
import json
import collections
import requests
from shared import logging
import lambda_proxy.responses as responses
from lambda_proxy.handlers._decorators import enforce_api_session_token
from lambda_proxy.handlers._helpers import extract_claims
from lambda_proxy import Headers, log_response

__copyright__ = '2017 Medibank Private Limited'

def not_implemented(*_):
    """Generic '501 Not Implemented' handler"""
    return responses.Error_501_NotImplemented()

HEADERS_MAPPINGS = {
    'Access-Control-Request-Headers': 'Access-Control-Allow-Headers',
}

METHOD_MAPPINGS = {
    '/sessions/{id}': 'DELETE,GET',
}
def options(event, *_):
    """Generic 'OPTIONS' handler"""
    req_headers = Headers(event['headers'])

    resp_headers = Headers()
    for req_h, resp_h in HEADERS_MAPPINGS.iteritems():
        if req_h in req_headers:
            resp_headers[resp_h] = req_headers[req_h]

    resource_methods = METHOD_MAPPINGS.get(
        event.get('resource'),
        req_headers['Access-Control-Request-Method'],
    )
    resp_headers['Access-Control-Allow-Methods'] = resource_methods

    return responses.Options_200_Ok().with_headers(resp_headers)

@enforce_api_session_token
def medibank_api_microservice(event, stage_vars, url_func, transaction_id):
    """Pass the incoming request to the matching Medibank API microservice"""
    log = logging.getLogger(__name__)

    claims = extract_claims(event)

    integ_request = dict(
        method  = event['httpMethod'],
        url     = url_func(event['path'], stage_vars.backend_endpoint),
        # This is a hard limit in API Gateway, and we can't request to
        # change it. There's no point letting a request go longer.
        timeout = 30,
    )

    # Ensure payload is valid JSON
    if isinstance(event['body'], basestring) and event['body'] != '':
        integ_request['data'] = json.dumps(
            json.loads(event['body']),
            separators=(',', ':'),
        )

    if isinstance(event['queryStringParameters'], collections.Mapping):
        integ_request['params'] = {
            k:v for k,v in event['queryStringParameters'].iteritems()
        }

    secure_headers = ('bpId', 'userId')
    integ_request['headers'] = (
        Headers(event['headers'])
        .filter_exclude(secure_headers)
        .filter_include(stage_vars.request_mapped_headers)
        .update(Headers(claims).filter_include(secure_headers))
        .update(transactionId = transaction_id)
    )

    filtered = ('data',)
    with requests.Session() as mb_users_api:
        log.info(
            'Sending request to backend API',
            extra = dict(
                integ_request = {
                    k:v for k,v in integ_request.iteritems()
                    if k not in filtered
                }
            )
        )
        log.debug(
            'Request details',
            extra = dict(
                integ_request = {
                    k:v for k,v in integ_request.iteritems()
                    if k in filtered
                }
            )
        )
        integ_response = mb_users_api.request(**integ_request)

    client_response_headers = (
        Headers(integ_response.headers)
        .filter_include(stage_vars.response_mapped_headers)
    )

    if integ_response.text:
        body = integ_response.json()
    else:
        body = ''

    # By default we pass 2XX, 400 and 404 responses through to the client.
    # Everything else is logged and rewritten to a 500 Internal Server Error.
    status = integ_response.status_code
    if 200 <= status <= 299:
        log.debug(
            'Received %d response from intergration backend.', status,
            extra = log_response(integ_response),
        )
        return (
            responses.SuccessResponse(status)
            .with_headers(client_response_headers)
            .with_body(body)
        )
    elif status in (500,) and body:
        log.debug(
            'Received %d response from intergration backend.', status,
            extra = log_response(integ_response),
        )
        return (
            responses.ErrorResponse(status, integ_response.reason)
            .with_headers(client_response_headers)
            .with_body(body)
        )
    elif status in (400, 403, 404):
        log.debug(
            'Received %d response from intergration backend.', status,
            extra = log_response(integ_response),
        )
        response = (
            responses.ErrorResponse(status, integ_response.reason)
            .with_headers(client_response_headers)
        )
        if body:
            response.with_body(body)

        return response

    log.error(
        'Received unexpected response from intergration backend.',
        extra = log_response(integ_response),
    )
    return responses.Error_500_InternalServerError()

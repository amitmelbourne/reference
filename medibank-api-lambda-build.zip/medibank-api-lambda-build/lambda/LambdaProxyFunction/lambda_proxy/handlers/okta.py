# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
A collection of handlers that implement authentication with Okta.
"""
import os
import json
import urllib
import uuid
import requests
from shared import logging
from shared.util import get_okta_api_key
import lambda_proxy
from lambda_proxy import Headers, log_response
from lambda_proxy.handlers._helpers import (
    extract_claims,
    check_token_valid,
    generate_api_session_token,
)

__copyright__ = '2017 Medibank Private Limited'

def session_delete(event, stage_vars, *_):
    """Deletes an Okta session."""
    log = logging.getLogger(__name__)

    token_valid, _ = check_token_valid(event, stage_vars)
    if not token_valid:
        return lambda_proxy.responses.Error_401_Unauthorized()

    with requests.Session() as okta_api:
        okta_api.headers.update({
            'Accept':        'application/json',
            'Content-Type':  'application/json',
            'Authorization': ' '.join(('SSWS', get_okta_api_key()))
        })
        if stage_vars.okta_proxies:
            okta_api.proxies = stage_vars.okta_proxies

        okta_session_id = (
            event
            .get('requestContext', {})
            .get('authorizer', {})
            .get('claim_token')
        )
        if okta_session_id is None:
            log.error(
                'Session delete request missing an Okta session Id (requestContext.claim_token).',
                extra = dict(
                    requestContext = event.get('requestContext', None)
                )
            )
            return lambda_proxy.responses.Error_500_InternalServerError()

        delete_session = okta_api.delete(
            os.path.join(
                stage_vars.okta_base_url,
                'api/v1',
                'sessions',
                urllib.quote(okta_session_id)
            )
        )

    if delete_session.status_code == 204:
        return lambda_proxy.responses.Success_204_NoContent()

    log.error(
        'Unexpected response from Okta',
        extra = log_response(delete_session),
    )
    return lambda_proxy.responses.Error_401_Unauthorized()

def session_validate(event, stage_vars, *_):
    """
    Validate (and refresh) an Okta session.
    """

    token_valid, new_token = check_token_valid(event, stage_vars)
    if not token_valid:
        return lambda_proxy.responses.Error_401_Unauthorized()

    if new_token is not None:
        api_session_token = new_token
    else:
        api_session_token = Headers(event['headers']).get('APISessionToken', '')

    return (
        lambda_proxy.responses.Success_200_Ok()
        .with_headers(
            APISessionToken = api_session_token,
        )
    )

def session_create(event, stage_vars, _, transaction_id):
    """
    Authenticate a user against Okta and generate a session token for them.
    """
    log = logging.getLogger(__name__)

    payload = json.loads(event['body'])
    headers = requests.structures.CaseInsensitiveDict(event['headers'])

    if '@' not in payload.get('username', ''):
        log.error(
            'Username does not appear to be an Okta user -- no "@" character.',
            extra = dict(
                user = payload.get('username'),
            ),
        )
        return lambda_proxy.responses.Error_501_NotImplemented()

    err, okta_profile = okta_lookup_user(
        stage_vars.okta_proxies,
        stage_vars.okta_base_url,
        payload.get('username'),
    )
    if err is not None:
        return err

    err, okta_login_response = check_okta_credentials(
        stage_vars.okta_proxies,
        stage_vars.okta_base_url,
        payload.get('username'),
        payload.get('password'),
    )
    if err is not None:
        return err

    if not okta_profile.get('emailVerified', False):
        # TODO Implement uServiceCall_VerifyEmail
        return lambda_proxy.responses.Error_403_Forbidden().with_body({
            'errorCode':'ERR_00036',
            'errorDescription':'User has not verified email address.',
        })

    session_id = str(uuid.uuid4())

    err, member_info = fetch_member_info(
        stage_vars.backend_endpoint,
        okta_profile.get('BP_ID', ''),
        payload.get('username'),
        session_id,
        transaction_id,
        'v1',
        headers.get('trackingId', None),
    )
    if err is not None:
        return err

    crypted_token = generate_api_session_token(
        okta_profile.get('BP_ID', None),
        session_id,
        okta_login_response,
    )

    return (
        lambda_proxy.responses.Success_201_Created()
        .with_body({
            'sessionId': session_id,
            'customerId': okta_profile.get('BP_ID', None),
            'member': member_info,
        })
        .with_headers(
            APISessionToken = crypted_token,
            Location = os.path.join(
                event.get('requestContext', {}).get('path', '/'),
                session_id,
            ),
        )
    )

def session_create_v2(event, stage_vars, _, transaction_id):
    """
    Authenticate a user against Okta and generate a session token for them.
    """
    log = logging.getLogger(__name__)

    payload = json.loads(event['body'])
    headers = requests.structures.CaseInsensitiveDict(event['headers'])

    if '@' not in payload.get('username', ''):
        log.error(
            'Username does not appear to be an Okta user -- no "@" character.',
            extra = dict(
                user = payload.get('username'),
            ),
        )
        return lambda_proxy.responses.Error_501_NotImplemented()

    err, okta_profile = okta_lookup_user(
        stage_vars.okta_proxies,
        stage_vars.okta_base_url,
        payload.get('username'),
    )
    if err is not None:
        return err

    err, okta_login_response = check_okta_credentials(
        stage_vars.okta_proxies,
        stage_vars.okta_base_url,
        payload.get('username'),
        payload.get('password'),
    )
    if err is not None:
        return err

    if not okta_profile.get('emailVerified', False):
        # TODO Implement uServiceCall_VerifyEmail
        return lambda_proxy.responses.Error_403_Forbidden().with_body({
            'errorCode':'ERR_00036',
            'errorDescription':'User has not verified email address.',
        })

    session_id = str(uuid.uuid4())

    err, member_info = fetch_member_info(
        stage_vars.backend_endpoint,
        okta_profile.get('BP_ID', ''),
        payload.get('username'),
        session_id,
        transaction_id,
        'v2',
        headers.get('trackingId', None),
    )
    if err is not None:
        return err

    crypted_token = generate_api_session_token(
        okta_profile.get('BP_ID', None),
        session_id,
        okta_login_response,
    )

    return (
        lambda_proxy.responses.Success_201_Created()
            .with_body({
            'sessionId': session_id,
            'customerId': okta_profile.get('BP_ID', None),
            'member': member_info,
        })
            .with_headers(
            APISessionToken = crypted_token,
            Location = os.path.join(
                event.get('requestContext', {}).get('path', '/'),
                session_id,
            ),
        )
    )

def read_profile(event, stage_vars, _, transaction_id):
    """
    Read profile (just BP ID at the moment) of the user who is identified in
    the 'sub' claim of the authorizer requestContext.
    """
    log = logging.getLogger(__name__)

    claims = extract_claims(event)
    headers = requests.structures.CaseInsensitiveDict(event['headers'])

    err, okta_profile = okta_lookup_user(
        stage_vars.okta_proxies,
        stage_vars.okta_base_url,
        claims.get('sub'),
    )
    if err is not None:
        return err

    if not okta_profile.get('emailVerified', False):
        # TODO Implement uServiceCall_VerifyEmail
        return lambda_proxy.responses.Error_403_Forbidden().with_body({
            'errorCode':'ERR_00036',
            'errorDescription':'User has not verified email address.',
        })

    err, _ = fetch_member_info(
        stage_vars.backend_endpoint,
        okta_profile.get('BP_ID', ''),
        claims.get('sub'),
        transaction_id,
        transaction_id,
        'v1',
        headers.get('trackingId', None),
    )
    if err is not None:
        return err

    bp_id = okta_profile.get('BP_ID', None)

    return (
        lambda_proxy.responses.Success_200_Ok()
        .with_body({
            'bpId': okta_profile.get('BP_ID', None),
            'email': claims.get('sub'),
        })
    )

def okta_lookup_user(okta_proxies, okta_base_url, username):
    """
    Look up a user in Okta.
    """
    log = logging.getLogger(__name__)

    with requests.Session() as okta_api:
        okta_api.headers.update({
            'Accept':        'application/json',
            'Content-Type':  'application/json',
            'Authorization': ' '.join(('SSWS', get_okta_api_key()))
        })
        if okta_proxies:
            okta_api.proxies = okta_proxies

        okta_lookup = okta_api.get(
            os.path.join(
                okta_base_url,
                'api/v1',
                'users',
                urllib.quote(username)
            )
        )

    log.info(
        'Okta lookup response.',
        extra = log_response(
            okta_lookup,
            username = username,
            verbose = False,
        ),
    )

    if okta_lookup.status_code in (500, 503, 504):
        return lambda_proxy.responses.Error_500_InternalServerError(), None
    if okta_lookup.status_code == 403:
        return lambda_proxy.responses.Error_403_Forbidden(), None
    if okta_lookup.status_code not in (200, 204):
        log.error(
            'Unexpected response from Okta',
            extra = log_response(okta_lookup),
        )
        return lambda_proxy.responses.Error_401_Unauthorized(), None

    okta_lookup_response = okta_lookup.json()
    log.debug(
        'User lookup details.',
        extra = dict(okta_lookup_response = okta_lookup_response)
    )
    return validate_okta_profile(okta_lookup_response)

def validate_okta_profile(okta_lookup_response):
    """
    Ensure the user's account is in a good state and extract their profile
    information.
    """
    if okta_lookup_response.get('status', '') == 'LOCKED_OUT':
        return lambda_proxy.responses.Error_403_LockedOut(), None
    elif okta_lookup_response.get('status', '') in ('STAGED', 'RECOVERY'):
        return lambda_proxy.responses.Error_403_Forbidden().with_body({
            'errorCode':'ERR_00036',
            'errorDescription':'User has not verified email address.',
        }), None

    return None, okta_lookup_response.get('profile', {})

def check_okta_credentials(okta_proxies, okta_base_url, username, password):
    """
    Validate the user's credentials against Okta and return the login response.
    """
    log = logging.getLogger(__name__)

    with requests.Session() as okta_api:
        okta_api.headers.update({
            'Accept':        'application/json',
            'Content-Type':  'application/json',
            'Authorization': ' '.join(('SSWS', get_okta_api_key()))
        })
        if okta_proxies:
            okta_api.proxies = okta_proxies

        okta_login = okta_api.post(
            os.path.join(
                okta_base_url,
                'api/v1/sessions',
            ),
            json = {
                'username': username,
                'password': password,
            }
        )

    log.info(
        'Okta login response.',
        extra = log_response(
            okta_login,
            username = username,
            verbose = False,
        ),
    )

    if okta_login.status_code in (500, 503, 504):
        return lambda_proxy.responses.Error_500_InternalServerError(), None
    if okta_login.status_code == 403:
        return lambda_proxy.responses.Error_403_Forbidden(), None
    if okta_login.status_code not in (200, 204):
        log.error(
            'Unexpected response from Okta',
            extra = log_response(okta_login),
        )
        return lambda_proxy.responses.Error_401_Unauthorized(), None

    okta_login_response = okta_login.json()
    log.debug(
        'User login details.',
        extra = dict(okta_login_response = okta_login_response)
    )
    return None, okta_login_response

def fetch_member_info(backend_endpoint, bp_id, username, session_id, transaction_id, source, tracking_id = None):
    """
    Fetch detailed member information from the Users API.
    """
    log = logging.getLogger(__name__)

    with requests.Session() as mb_users_api:
        mb_users_api.headers.update({
            'Accept':        'application/json',
            'Content-Type':  'application/json',
            'bpId':          bp_id,
            'userId':        username,
            'sessionId':     session_id,
            'transactionId': transaction_id,
        })
        if tracking_id:
            mb_users_api.headers.update(trackingId = transaction_id)

        validateUserPath = 'validateOmsUser'
        if source == 'v2':
            validateUserPath = 'validateOmsUserV2'

        validate_oms_user = mb_users_api.get(
            os.path.join(
                backend_endpoint,
                'users', 'users',
                username,
                validateUserPath,
            )
        )

    log.info(
        'Users API validateOmsUser response.',
        extra = log_response(
            validate_oms_user,
            username = username,
            verbose = False,
        ),
    )

    if validate_oms_user.status_code == 403:
        return (
            lambda_proxy.responses.Error_403_Forbidden()
            .with_body(validate_oms_user.json())
        ), None
    if validate_oms_user.status_code != 200:
        log.error(
            'Unexpected response from validateOmsUser',
            extra = log_response(
                validate_oms_user,
                username = username,
            ),
        )
        return lambda_proxy.responses.Error_500_InternalServerError(), None

    validate_oms_user_response = validate_oms_user.json()
    log.debug(
        'Users API validateOmsUser details.',
        extra = dict(
            validate_oms_user_response = validate_oms_user_response
        )
    )

    return None, validate_oms_user_response.get('member', {})

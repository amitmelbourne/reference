# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
Handlers for reference data.
"""
import os
import gzip
import json
import lambda_proxy.responses

__copyright__ = '2017 Medibank Private Limited'

class ReferenceDataParser(object):
    """
    A singleton class to hold reference data loaded from a file.
    """
    _domain_data = None

    def load_domain_data(self, filename):
        """
        Load domain reference data from a gzipped JSON file.
        """
        self._domain_data = json.load(gzip.open(filename))

    def get_domain(self, domain):
        """
        Get reference data for a domain.
        """
        if self._domain_data is None:
            self.load_domain_data(
                os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    '..', 'resources', 'referenceData.json.gz',
                )
            )
        return self._domain_data.get(domain)

_REFERENCE_DATA = ReferenceDataParser()

def by_domain(event, *_):
    """
    Returns static reference data by domain.
    """

    domain = event.get('pathParameters', {}).get('domain')
    if domain is None:
        return lambda_proxy.responses.Error_400_BadRequest()

    reference_data = _REFERENCE_DATA.get_domain(domain)
    if reference_data is None:
        return lambda_proxy.responses.Error_404_NotFound()

    return (
        lambda_proxy.responses.Success_200_Ok()
        .with_body(reference_data)
    )

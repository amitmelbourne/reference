# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
Handlers for Young Adult POST and PUT requests
"""
import json
import requests
from shared import logging
from shared.tokens import YoungAdultsJwt
import lambda_proxy.responses
from lambda_proxy import  Headers, log_response
from lambda_proxy.handlers._helpers import extract_claims

__copyright__ = '2017 Medibank Private Limited'


def post(event, stage_vars, url_func, transaction_id):
    """
    Handle a Young Adults POST request -- this is the YA equivalent of a login
    function.
    """
    log = logging.getLogger(__name__)

    integration_request_headers = (
        Headers(event['headers'])
        .filter_include(stage_vars.request_mapped_headers)
        .update(transactionId = transaction_id)
    )

    integration_response = requests.post(
        url_func(event['path'], stage_vars.backend_endpoint),
        headers = integration_request_headers,
        data    = event['body']
    )

    log.info(
        'Integration response',
        extra = log_response(integration_response, verbose = False),
    )
    if integration_response.status_code != 200:
        log.error(
            'Received unhandled integration response',
            extra = log_response(integration_response, verbose = False)
        )
        return lambda_proxy.responses.Error_401_Unauthorized()

    try:
        response_payload = integration_response.json()
    except ValueError:
        # Couldn't parse the backend response as JSON...
        log.error(
            'Integration response not JSON.',
            extra = dict(
                body = integration_response.text,
                headers = dict(integration_response.headers),
            )
        )
        return lambda_proxy.responses.Error_500_InternalServerError()

    log.debug(
        'Integration response payload.',
        extra = dict(
            body = integration_response.text,
        )
    )

    token = (
        YoungAdultsJwt(response_payload['id'])
        .with_lifetime(stage_vars.session_time.total_seconds())
    )

    token['M1'], response_payload['id'] = response_payload['id'], 'M1'

    for idx, child in enumerate(response_payload.get('children', []), 1):
        masked_child_id = 'C%d'%idx
        token[masked_child_id], child['id'] = child['id'], masked_child_id

    response_headers = (
        Headers(integration_response.headers)
        .filter_include(stage_vars.response_mapped_headers)
        .update({'Access-Control-Expose-Headers': 'APIFWACToken'})
        .update(APIFWACToken = token.jwe)
    )

    return (
        lambda_proxy.responses.SuccessResponse(integration_response.status_code)
        .with_body(response_payload)
        .with_headers(response_headers)
    )

def put(event, stage_vars, url_func, transaction_id):
    """
    Update Young Adult child information.
    """
    log = logging.getLogger(__name__)

    request_payload = json.loads(event.get('body', ''))

    claims = extract_claims(event)

    log.debug(
        'Authorizer claims.',
        extra = dict(
            claims = claims,
        )
    )

    request_payload['id'] = claims['M1']

    for child in request_payload.get('children', []):
        child['id'] = claims[child['id']]

    lowercased_headers = {
        k.lower():v for k,v in event['headers'].iteritems()
    }

    headers = {
        k:v for k,v in lowercased_headers.iteritems()
        if k.lower() in stage_vars.request_mapped_headers
    }
    headers.update(
        bpId          = request_payload['id'],
        transactionId = transaction_id,
    )

    log.debug(
        'Backend request.',
        extra = dict(
            backend_url = url_func(event['path'], stage_vars.backend_endpoint),
            headers = headers,
            payload = request_payload,
        )
    )

    integration_response = requests.put(
        url_func(event['path'], stage_vars.backend_endpoint),
        headers = headers,
        data = json.dumps(request_payload),
    )

    log.info(
        'Backend response.',
        extra = log_response(integration_response),
    )

    response_headers = (
        Headers(integration_response.headers)
        .filter_include(stage_vars.response_mapped_headers)
        .update({'Access-Control-Expose-Headers': 'APIFWACToken'})
    )
    return (
        lambda_proxy.responses.SuccessResponse(integration_response.status_code)
        .with_body(integration_response.text)
        .with_headers(response_headers)
    )

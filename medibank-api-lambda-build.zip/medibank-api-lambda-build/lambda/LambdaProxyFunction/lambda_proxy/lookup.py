# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
A collection of functions to look up which event handler and URL builder to
use.
"""
from collections import namedtuple
from shared import logging
from lambda_proxy.handlers import okta, reference, youngadults, generic

__copyright__ = '2017 Medibank Private Limited'

HandlerFunctionEntry = namedtuple('HandlerFunctionEntry', ['resource', 'method'])

HANDLER_FUNCTIONS = {
    HandlerFunctionEntry('/sessions', 'POST'):                       okta.session_create,
    HandlerFunctionEntry('/sessionsV2', 'POST'):                    okta.session_create_v2,
    HandlerFunctionEntry('/sessions/{id}', 'DELETE'):                okta.session_delete,
    HandlerFunctionEntry('/sessions/{id}', 'GET'):                   okta.session_validate,
    HandlerFunctionEntry('/sessions/profile', 'GET'):                okta.read_profile,
    HandlerFunctionEntry('/reference/{domain}', 'GET'):              reference.by_domain,
    HandlerFunctionEntry('/members/{MemberID}/youngadults', 'POST'): youngadults.post,
    HandlerFunctionEntry('/members/{MemberID}/youngadults', 'PUT'):  youngadults.put,
}

def lookup_handler_func(resource, http_method):
    """
    Look up the event handler function based on the REST API resource name and
    HTTP method.
    """
    if (resource, http_method) in HANDLER_FUNCTIONS:
        return HANDLER_FUNCTIONS[(resource, http_method)]
    elif http_method == 'OPTIONS':
        return generic.options

    return generic.medibank_api_microservice

def _split_request_path(request_path):
    """
    Removes leading forward-slashes and splits a string. We do it this way to
    preserve multiple forward-slashes -- collapsing them into a single
    forward-slash like we would with filesystem paths isn't correct here.
    """
    return request_path.lstrip('/').split('/')

def _join_request_path(*parts):
    """
    Join the parts of a request path with forward-slashes after stripping them
    from each element.
    """
    return '/'.join(( p.strip('/') for p in parts ))

def v1_api_url(request_path, backend_endpoint):
    """
    Map a front-end URL to the 'v1' URL format for Medibank's µservices.
    Basically it doubles the first piece the of the URL (the API name). This
    format is used by almost all µservices so it is the default URL function.
    """
    log = logging.getLogger(__name__)
    request_parts = _split_request_path(request_path)

    url = _join_request_path(
        backend_endpoint,
        request_parts[0],
        *request_parts
    )

    log.debug(
        'Built v1 API Endpoint',
        extra = dict(
            details = dict(
                request_path = request_path,
                request_parts = request_parts,
                backend_endpoint = backend_endpoint,
                url = url,
            )
        )
    )

    return url

def v2_api_url(request_path, backend_endpoint):
    """
    Map a front-end URL to the 'v2' URL format for Medibank's µservices. This
    format is only used with a few µservices and the exact behaviour is
    dependent on the µservice.
    """
    log = logging.getLogger(__name__)
    request_parts = [ p for p in request_path.split('/') if p != '' ]

    if request_parts[0] in ('claims',):
        request_parts[0] = request_parts[0] + 'v2'
    elif request_parts[0] == 'products':
        if len(request_parts) > 2 and request_parts[2] == 'coverages':
            request_parts = [ 'coverages', request_parts[1] ]

    url = _join_request_path(
        backend_endpoint,
        *request_parts
    )

    log.debug(
        'Built v2 API Endpoint',
        extra = dict(
            details = dict(
                request_path = request_path,
                request_parts = request_parts,
                backend_endpoint = backend_endpoint,
                url = url,
            )
        )
    )

    return url

def verify_token_url(request_path, backend_endpoint):
    """
    Map /users/{username}/verifyToken to /tokens/{username}/verifyToken
    """
    log = logging.getLogger(__name__)
    request_parts = _split_request_path(request_path)

    url = _join_request_path(
        backend_endpoint,
        'tokens',
        'tokens',
        *(request_parts[1:])
    )

    log.debug(
        'Built verifyToken Endpoint',
        extra = dict(
            details = dict(
                request_path = request_path,
                request_parts = request_parts,
                backend_endpoint = backend_endpoint,
                url = url,
            )
        )
    )

    return url

URL_FUNCTIONS = {
    '/claims/types/{productID}': v2_api_url,
    '/products/{productID}':v2_api_url,
    '/products/{productID}/coverages':v2_api_url,
    '/users/{username}/verifyToken':verify_token_url,
}

def lookup_url_func(resource):
    """
    Look up the URL mapping function based on the REST API resource name.
    """
    return URL_FUNCTIONS.get(resource, v1_api_url)

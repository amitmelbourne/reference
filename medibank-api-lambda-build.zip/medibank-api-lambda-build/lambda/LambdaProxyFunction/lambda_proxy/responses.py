# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
Classes to represent an AWS API Gateway Lambda Proxy response and some
singletons for common response codes.
"""
import json
from collections import Mapping, Iterable

__copyright__ = '2017 Medibank Private Limited'

DEFAULT_API_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Expose-Headers': 'ETag,Location,APISessionToken',
}

class BaseResponse(dict):
    """
    The base class for API Gateway Lambda proxy responses. Lambda expects our
    functions to return a 'dict'. API Gateway expects the 'dict' to contain
    three keys:

    status_code:    The HTTP integer status code for the response
    headers:        A 'dict' of HTTP headers for the response
    body:           The stringified body of the response

    This class and it's subclasses make it a bit simpler (and more intuitive)
    to manage the response 'dict'.
    """
    def __init__(self, status_code, body = None, headers = None, **kwargs):
        super(BaseResponse, self).__init__()
        self.update(
            statusCode = status_code,
            body       = None,
            headers    = {},
        )
        if body:
            self.with_body(body)
        if headers:
            self.update_headers(headers)
        if kwargs:
            self.update_headers(kwargs)

    @property
    def body(self):
        """
        The body of the response.
        """
        return self['body']

    @property
    def headers(self):
        """
        The response headers.
        """
        return self['headers']

    def with_body(self, body):
        """
        Update the body of the response. Arguments are handled differently
        based on their type.

        Strings:
            Anything that subclasses from 'basestring' is used to directly
            update the body.

        Mappings and iterables:
            Anything that subclasses from 'collections.Mapping' or
            'collections.Iterable' is converted to JSON.

        Other types:
            Everything else is first converted to a string with the 'str'
            built-in function.
        """
        if isinstance(body, basestring):
            self.update(body = body)
        elif isinstance(body, Mapping):
            self.update(body = json.dumps(dict(body), separators=(',',':')))
            self.update_headers({'Content-Type': 'application/json'})
        elif isinstance(body, Iterable):
            self.update(body = json.dumps(list(body), separators=(',',':')))
            self.update_headers({'Content-Type': 'application/json'})
        else:
            self.update(body = str(body))
        return self

    def update_headers(self, *args, **kwargs):
        """
        Update the response headers. Positional arguments are passed to the
        'dict.update' method individually and all keyword arguments are passed
        as a single 'dict'.
        """
        for arg in args:
            self.headers.update(arg)
        self.headers.update(kwargs)
        return self

    def with_headers(self, *args, **kwargs):
        """
        An alias for the 'update_headers' method for naming consistency.
        """
        return self.update_headers(*args, **kwargs)

class SuccessResponse(BaseResponse):
    """
    The class used for successful API responses that should include the
    APISessionToken header.
    """
    def __init__(self, status_code):
        super(SuccessResponse, self).__init__(
            status_code = status_code,
            headers = DEFAULT_API_HEADERS.copy(),
        )

class ErrorResponse(BaseResponse):
    """
    The class used for error API responses that should include the
    APISessionToken header.
    """
    def __init__(self, status_code, message):
        super(ErrorResponse, self).__init__(
            status_code = status_code,
            body = dict(message = message),
            headers = DEFAULT_API_HEADERS.copy(),
        )

# pylint: disable=invalid-name

def Success_200_Ok():
    """200 OK"""
    return SuccessResponse(200)

def Success_201_Created():
    """201 Created"""
    return SuccessResponse(201)

def Success_204_NoContent():
    """204 No Content"""
    return SuccessResponse(204)


def Error_400_BadRequest():
    """400 Bad Request"""
    return ErrorResponse(400, 'Bad Request')

def Error_401_Unauthorized():
    """401 Unauthorized"""
    return ErrorResponse(401, 'Unauthorized')

def Error_403_LockedOut():
    """403 Locked Out"""
    return ErrorResponse(403, 'Locked Out')

def Error_403_Forbidden():
    """403 Forbidden"""
    return ErrorResponse(403, 'Forbidden')

def Error_404_NotFound():
    """404 Not Found"""
    return ErrorResponse(404, 'Not Found')

def Error_415_UnsupportedMediaType():
    """415 Unsupported Media Type"""
    return ErrorResponse(415, 'Unsupported Media Type')


def Error_500_InternalServerError():
    """500 Internal Server Error"""
    return ErrorResponse(500, 'Internal Server Error')

def Error_501_NotImplemented():
    """501 Not Implemented"""
    return ErrorResponse(501, 'Not Implemented')


def Options_200_Ok():
    """200 OK"""
    return BaseResponse(200, headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Max-Age': 86400,
    })

from setuptools import setup, find_packages

setup(
    name             = 'LambdaProxyFunction',
    version          = '0.1',
    description      = 'An AWS Lambda function to proxy requests to backend microservices.',
    url              = 'https://stash.aws.medibank.local/scm/oms/api-gateway-openapi.git',
    author           = 'James Sinclair',
    author_email     = 'james.sinclair@shinesolutions.com.au',
    packages         = find_packages(),
    # We're assuming a couple of packages are already installed here because
    # they're included in the AWS Lambda environment by default. This makes our
    # deployment ZIP file about 8MiB smaller.
    #
    # boto3==1.4.7
    # botocore==1.7.37
    install_requires = [
        'aws_xray_sdk',
        'requests',
        'arrow',
    ],
    package_data = {
        'lambda_proxy': [
            'resources/*.json.gz'
        ],
    },
)

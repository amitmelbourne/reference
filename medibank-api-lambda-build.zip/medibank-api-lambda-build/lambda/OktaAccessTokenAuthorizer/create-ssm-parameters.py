#!/usr/bin/env python
from __future__ import print_function

import sys
import json
from getpass import getpass
import boto3

ssm   = boto3.client('ssm')
apigw = boto3.client('apigateway')
kms   = boto3.client('kms')

apigw_parameters = {
  "okta_issuer": {
    "Type": "String",
    "Description": "The Okta issuer URI that should be trusted.",
    "Required": True,
  },
  "okta_trusted_audience": {
    "Type": "StringList",
    "Description": "The trusted values for the 'aud' claim in Okta access tokens.",
    "Required": True,
  },
  "okta_client_secret": {
    "Type": "SecureString",
    "Description": "The client secret used when accessing Okta.",
    "Required": True,
  },
  "okta_client_id": {
    "Type": "SecureString",
    "Description": "The client id used when accessing Okta.",
    "Required": True,
  },
  "log_level": {
    "Type": "String",
    "Description": "The overall logging level.",
    "Required": False,
  },
  "boto_log_level": {
    "Type": "String",
    "Description": "The logging level for certain chatty 'boto3' loggers.",
    "Required": False,
  },
}

ssm_parameters = apigw_parameters.copy()

parameters = {}
for arg in sys.argv[1:]:
    name, _, value = arg.partition('=')
    if name and value:
        parameters[name] = value

def read_parameter(name, prompt, default = None, secret = False):
    if name in parameters:
        return parameters[name]
    input_func = getpass if secret else raw_input
    try:
        value = input_func(prompt)
    except EOFError:
        print()
        return None
    return default if value == '' else value

api_id       = read_parameter('api_id', 'Enter API Gateway API ID: ')
stage        = read_parameter('stage',  'Enter API Gateway stage:  ')
param_prefix = '/APIGW/%s/%s/'%(api_id,stage)

try:
    api_stage = apigw.get_stage(restApiId = api_id, stageName = stage)
except Exception as e:
    print('Unable to find specified API Gateway stage.')
    raise SystemExit(2)

copy = None
while True:
    copy = read_parameter('copy', 'Do you want to copy values from another stage? (y/N): ', 'n').lower()
    if copy == '':
        copy = 'n'
    if copy in 'yn':
        copy = copy == 'y'
        break

copy_parameters = {}
copy_prefix = None
if copy:
    copy_api_id = read_parameter('copy_api_id', 'Enter the API Gateway API ID to copy from (%s):'%api_id, api_id)
    copy_stage  = read_parameter('copy_stage',  'Enter the API Gateway stage to copy from:  ')
    copy_prefix = '/APIGW/%s/%s/'%(copy_api_id,copy_stage)
    try:
        copy_parameters = ssm.get_parameters_by_path(
            Path=copy_prefix,
            Recursive=True,
            WithDecryption=True,
        ).get('Parameters', [])
    except Exception as e:
        copy_parameters = ssm.get_parameters_by_path(
            Path=copy_prefix,
            Recursive=True,
            WithDecryption=False,
            ParameterFilters = [
                {'Key':'Type','Option':'Equals','Values':['String','StringList']},
            ],
        ).get('Parameters', [])

    for parameter in copy_parameters:
        stringified_parameter = ( (k,str(v)) for k,v in parameter.items() )
        name = parameter['Name'].replace(copy_prefix, '')
        ssm_parameters.get(name, {}).update(stringified_parameter)

key = read_parameter('key', 'Enter the KMS key to use for encryption of SecureString parameters: ')

print('\n*** Use ctrl-d at a prompt to skip setting that parameter ***\n')
for name, details in ssm_parameters.items():
    if details['Type'] == 'SecureString':
        current = '*' * 8 if 'Value' in details else None
        default = details.get('Value')
        secret  = True
        details['KeyId'] = key
    else:
        current = default = details.get('Value')
        secret  = False
    prompt = details.get('Description')
    if current:
        prompt += ' (%s)'%current
    prompt += ': '
    value = read_parameter(name, prompt, default, secret)
    details['Name'] = param_prefix + name
    details['Value'] = value
    details['Overwrite'] = True

print('\n*** Parameter values that will be set ***\n')
longest_name = max(( len(n) for n in ssm_parameters ))
name_width = longest_name + len(param_prefix) + 2
for name, details in ( (k,v) for k,v in ssm_parameters.items() if v['Value'] is not None ):
    print(
        ('{:%d}{}'%name_width).format(
            param_prefix + name,
            '*' * 8 if details['Type'] == 'SecureString' else details['Value']
        )
    )

print('\n*** Press enter to continue, crtl-c to cancel ***\n')
raw_input()

put_parameter_kwargs = {
    'Name',
    'Description',
    'Value',
    'Type',
    'KeyId',
    'Overwrite',
    'AllowedPattern'
}
for name, details in ( (k,v) for k,v in ssm_parameters.items() if v['Value'] is not None ):
    kwargs = { k:v for k,v in details.items() if k in put_parameter_kwargs }
    put = ssm.put_parameter(**kwargs)
    print(('{:%d}version {}'%name_width).format(kwargs['Name'], put.get('Version', 'unknown')))

# -*- coding: utf8 -*-
"""
Lambda function to validate authorisation tokens.
"""
import sys
import os
import re
from hashlib import sha1
import lambda_function.logging as logging
from lambda_function.auth_policy import AuthPolicy, HttpVerb
from lambda_function.util import parse_arn, parse_arn_resource, prefix_keys
from lambda_function.ssm_parameters import CachedSSMParameters
from lambda_function.okta import OktaClient

__copyright__ = '2017 Medibank Private Limited'

logging.getLogger().info("Default authorizer startup.")

POLICY_RE = re.compile(
    r'(ALLOW|DENY) (GET|POST|PUT|DELETE|PATCH|HEAD|ANY) (/.*)',
    flags = re.IGNORECASE,
)

def lambda_handler(event, lambda_context):
    """
    A JWT bearer-token based API Gateway custom authorizer.
    """

    logging.set_levels(
        os.getenv('LOG_LEVEL', 'DEBUG'),
        os.getenv('BOTO_LOG_LEVEL', 'ERROR'),
    )

    method_arn = parse_arn(event['methodArn'])
    resource = parse_arn_resource(method_arn.get('resource', ''))
    api_id, stage = resource['api_id'], resource['stage']

    apigw_parameters = CachedSSMParameters('/APIGW/{}/{}'.format(api_id, stage))

    logging.set_levels(
        apigw_parameters.get('log_level', 'INFO'),
        apigw_parameters.get('boto_log_level', 'ERROR'),
    )

    transaction_info_filter = logging.UpdateRecordFilter(
        aws_request_id = lambda_context.aws_request_id,
        api_id         = api_id,
        stage          = stage,
    )

    with logging.set_filter(transaction_info_filter):
        log = logging.getLogger(__name__)

        log.debug(
            'Handling authorization event.',
            extra = dict(
                event = event,
                method_arn = method_arn,
                resource = resource,
            ),
        )

        try:
            claims = OktaClient(
                apigw_parameters.okta_issuer,
                apigw_parameters.okta_client_id,
                apigw_parameters.okta_client_secret,
            ).validate_access_token(
                event['authorizationToken'],
                apigw_parameters.okta_trusted_audience,
            )
        except Exception:
            log.exception('Exception during token validation.')
            raise Exception('Unauthorized')

        log.debug(
            'Token claims',
            extra = dict(
                claims = claims,
            )
        )

        if claims is None:
            raise Exception('Unauthorized')

        if not claims.get('sub'):
            log.critical(
                'Unable to get subscriber from token claims.',
                extra = dict(
                    claims = claims,
                    method_arn = method_arn,
                    resource = resource,
                ),
            )
            raise Exception('Unauthorized')

        issuer_hash = sha1(claims['iss'].encode('utf8')).hexdigest()[:12]
        issuer_scope_mappings = CachedSSMParameters('/OktaOIDC/issuers/{}'.format(issuer_hash))
        if issuer_scope_mappings.issuer_uri != claims['iss']:
            log.critical('Issuer hash doesn not match issuer URI', extra = dict(
                issuer = claims['iss'],
                issuer_hash = issuer_hash,
                issuer_scope_mappings_uri = issuer_scope_mappings.issuer_uri,
            ))
            raise Exception('Unauthorized')

        policy = build_policy(
            claims         = claims,
            method_arn     = method_arn,
            resource       = resource,
            scopes         = ( i.strip() for i in claims['scope'].split() ),
            scope_mappings = issuer_scope_mappings
        )

        auth_response = policy.build()
        auth_response['context'] = ctx = {}
        ctx.update(prefix_keys('method_arn_', method_arn))
        ctx.update(prefix_keys('resource_', resource))
        ctx.update(prefix_keys('claim_', claims))

        log.debug(
            'Returning successful response.',
            extra = dict(
                auth_response = auth_response,
            ),
        )

        return auth_response

def build_policy(claims, method_arn, resource, scopes, scope_mappings):
    """
    Build an AWS API Gateway IAM policy which gives execute-api access to
    specific method/endpoint pairs based on token scopes.
    """
    log = logging.getLogger(__name__)

    auth_policy = (
        AuthPolicy()
        .withPrincipalId(claims.get('sub'))
        .withAwsAccountId(method_arn.get('account_id'))
        .withRegion(method_arn.get('region'))
        .withRestApiId(resource.get('api_id'))
        .withStage(resource.get('stage'))
    )

    for scope in scopes:
        policies = scope_mappings.get('scopes/{}'.format(scope), [])
        for policy in policies:
            policy_match = POLICY_RE.fullmatch(policy)

            if policy_match:
                action, method, path = policy_match.groups()
                action_func = getattr(auth_policy, action.lower() + 'Method')
                action_func(
                    getattr(HttpVerb, method.upper()),
                    path
                )
            elif policy:
                log.warning(
                    'Scope exists in Parameter Store but policy does not match'
                    'regular expression.',
                    extra = dict(
                        scope = scope,
                        policy = policy,
                    )
                )
            else:
                # unknown scopes are ignored
                continue

    return auth_policy

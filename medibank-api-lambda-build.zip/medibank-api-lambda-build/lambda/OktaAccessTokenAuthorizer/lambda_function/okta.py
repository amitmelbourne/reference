"""
Okta OIDC client.
"""
import requests
import lambda_function.logging as logging

__copyright__ = '2017 Medibank Private Limited'

class OktaClient(object):
    """
    Okta OIDC client.
    """
    __global_cache = {}
    __log = logging.getLogger('__name__')

    def __init__(self, issuer_uri, client_id, client_secret):
        self.__issuer_uri = issuer_uri
        self.__client_id = client_id
        self.__client_secret = client_secret
        self.__pfx = '/{}/{}'.format(issuer_uri, client_id)
        self.__refresh()
        self.__cache = self.__global_cache.get(self.__pfx)

    def __refresh(self):
        """
        Refresh cached authorisation server metadata.
        """
        metadata_resp = requests.get(
            '{}/.well-known/openid-configuration'.format(self.__issuer_uri),
        )
        metadata_resp.raise_for_status()
        self.__global_cache[self.__pfx] = metadata_resp.json()

    def validate_access_token(self, token, trusted_audiences):
        """
        Validate an Okta token using the OIDC introspection endpoint
        """
        resp = self.introspect_token(token, 'access_token')
        self.__log.debug(
            'Token introspection response',
            extra = dict(
                response = resp,
            )
        )
        if resp.get('active') and resp.get('aud') in trusted_audiences:
            return resp
        return None


    def introspect_token(self, token, token_type_hint):
        """
        Pass a token to the OIDC token introspection endpoint to validate it.
        """
        introspection_resp = requests.post(
            self.__cache.get('introspection_endpoint'),
            auth = (
                self.__client_id,
                self.__client_secret,
            ),
            data = dict(
                token_type_hint = token_type_hint,
                token           = token,
            )
        )
        introspection_resp.raise_for_status()
        return introspection_resp.json()

"""
Access to AWS EC2 SSM Parameter Store.
"""
import boto3
import lambda_function.logging as logging

__copyright__ = '2017 Medibank Private Limited'

class CachedSSMParameters(object):
    """
    Cached access to SSM Parameter Store parameters.
    """
    __cache = {}
    __log = logging.getLogger(__name__)

    def __init__(self, prefix):
        self.__pfx = '/' + prefix.strip('/') + '/'

        ssm = boto3.client('ssm')
        try:
            parameter_resp = ssm.get_parameters_by_path(
                Path = self.__pfx,
                Recursive = True,
                WithDecryption = True,
            )
            self.__cache.update((
                (p['Name'], p) for p in parameter_resp.get('Parameters', [])
            ))
            self.__log.info(
                'Updated SSM Parameter cache',
                extra = dict(
                    prefix = self.__pfx,
                    parameter_versions = {
                        p['Name'][len(self.__pfx):] : p['Version']
                        for p in parameter_resp.get('Parameters', [])
                    },
                )
            )
            self.__log.debug(
                'SSM Parameter values',
                extra = dict(
                    prefix = self.__pfx,
                    parameter_versions = {
                        p['Name'][len(self.__pfx):] : p['Value']
                        for p in parameter_resp.get('Parameters', [])
                    },
                )
            )
        except:
            self.__log.exception(
                'Unable to fetch parameters from SSM Parameter Store.',
                extra = dict (
                    prefix = self.__pfx,
                )
            )

    def get(self, parameter, default = None):
        """
        Fetch a parameter from SSM Parameter Store for return a default value.
        """
        param = self.__cache.get(self.__pfx + parameter, None)
        if param is None:
            return default
        if param['Type'] == 'StringList':
            value = [ i.strip() for i in param['Value'].split(',') ]
        else:
            value = param['Value']
        return value


    def __getattr__(self, parameter):
        val = self.get(parameter)
        if val is None:
            raise AttributeError(
                'Parameter "{}" not found in SSM Parameter Store under prefix {}.'.format(
                    parameter,
                    self.__pfx,
                )
            )
        return val

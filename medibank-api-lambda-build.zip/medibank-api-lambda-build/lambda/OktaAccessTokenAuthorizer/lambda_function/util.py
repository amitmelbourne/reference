"""
Utility functions.
"""

__copyright__ = '2017 Medibank Private Limited'

__all__ = (
    'parse_arn',
    'parse_arn_resource',
)

def prefix_keys(pfx, mapping):
    """
    Return a dict -- based on iterables of keys and values -- with a string
    prefixed to each key.
    """
    return { (pfx + str(k)):v for k,v in mapping.items() if k }

def parse_arn(arn):
    """
    Parse an AWS ARN
    """
    return dict(zip(
        ('region', 'account_id', 'resource'),
        ( str(i) for i in arn.split(':', 5)[3:] ),
    ))

def parse_arn_resource(arn_resource):
    """
    Parse the resource portion is an API Gateway ARN
    """
    return dict(zip(
        ('api_id', 'stage', 'method', 'path'),
        ( str(i) for i in arn_resource.split('/', 3) ),
    ))

from setuptools import setup, find_packages

setup(
    name             = 'OktaAccessTokenAuthorizer',
    version          = '0.1',
    description      = 'An AWS Lambda function to validate Okta OIDC access tokens presented to AWS API Gateway.',
    #url              = 'https://stash.aws.medibank.local/scm/oms/api-gateway-openapi.git',
    author           = 'James Sinclair',
    author_email     = 'james.sinclair@shinesolutions.com.au',
    packages         = find_packages(),
    install_requires = [
        'requests',
        'python-json-logger',
    ],
)

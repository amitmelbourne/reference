from setuptools import setup, find_packages

setup(
    name             = 'shared',
    version          = '0.1',
    description      = 'Code shared between DefaultJWTAuthorizer and LambdaProxyFunction.',
    url              = 'https://stash.aws.medibank.local/scm/oms/api-gateway-openapi.git',
    author           = 'James Sinclair',
    author_email     = 'james.sinclair@shinesolutions.com.au',
    packages         = find_packages(),
    # We're assuming a couple of packages are already installed here because
    # they're included in the AWS Lambda environment by default. This makes our
    # deployment ZIP file about 8MiB smaller.
    #
    # boto3==1.4.7
    # botocore==1.7.37
    install_requires = [
        'arrow',
        'PyJWT',
        'PyJWE',
        'python-json-logger',
    ],
)

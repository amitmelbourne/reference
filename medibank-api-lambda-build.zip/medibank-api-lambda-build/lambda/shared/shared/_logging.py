"""
Set up JSON log messages and remove formatters and/or filters added by the Lambda service.
"""
from __future__ import print_function
import os
import logging as logging_module
from datetime import datetime
from contextlib import contextmanager
from pythonjsonlogger import jsonlogger
from shared.exceptions import LoggingLevelNotFoundException

__copyright__ = '2017 Medibank Private Limited'

# TODO This module should be a class and singleton object to avoid global vars.
# pylint: disable=global-statement

class LogFormatter(jsonlogger.JsonFormatter):
    """
    A pythonjsonlogger.jsonlogger.JsonFormatter subclass to add a few extra
    fields we want logged.
    """
    def add_fields(self, log_record, record, message_dict):
        super(LogFormatter, self).add_fields(log_record, record, message_dict)
        if not log_record.get('timestamp'):
            # this doesn't use record.created, so it is slightly off
            now = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.%fZ')
            log_record['timestamp'] = now
        if log_record.get('level'):
            log_record['level'] = log_record['level'].upper()
        else:
            log_record['level'] = record.levelname

class UpdateRecordFilter(object):
    """
    A Python 'logging' module filter that copies some extra attributes onto
    every message. Used to add things like the 'transactionId'.
    """
    def __init__(self, **extra):
        self._extra = extra

    def filter(self, record):
        """
        Add our extra attributes to a 'LogRecord' object.
        """
        for key, value in self._extra.iteritems():
            setattr(record, key, value)
        return True

def _get_logging_level(level_name):
    level = getattr(logging_module, str(level_name).upper(), None)
    if not isinstance(level, int):
        raise LoggingLevelNotFoundException('Logging level "%s" not found.' % level_name)
    return level

_ROOT_LOGGER_CONFIGURED = False
def _config_root_logger():
    global _ROOT_LOGGER_CONFIGURED
    log_handler = logging_module.StreamHandler()
    log_handler.setFormatter(
        LogFormatter('(timestamp) (level) (name) (message)')
    )
    root_logger = logging_module.getLogger()
    for handler in root_logger.handlers:
        root_logger.removeHandler(handler)
    root_logger.addHandler(log_handler)
    _ROOT_LOGGER_CONFIGURED = True

_LEVELS_SET = False
def set_levels(root_level = 'INFO', boto_level = 'ERROR', other_level = 'ERROR'):
    """
    Set logging levels for the root logger, the boto loggers and a few others.
    """
    global _LEVELS_SET
    print(
        '{'
        '"message":"Setting levels",'
        '"root_level":"%s",'
        '"boto_level":"%s",'
        '"other_level":"%s"'
        '}'%(
            root_level.upper(),
            boto_level.upper(),
            other_level.upper(),
        )
    )
    root_level = _get_logging_level(root_level)
    boto_level = _get_logging_level(boto_level)
    other_level = _get_logging_level(other_level)

    for boto_logger in ('boto', 'boto3', 'botocore'):
        logging_module.getLogger(boto_logger).setLevel(boto_level)

    for other_logger in ('chardet', 'chardet.charsetprober'):
        logging_module.getLogger(other_logger).setLevel(other_level)

    if not _ROOT_LOGGER_CONFIGURED:
        _config_root_logger()

    logging_module.getLogger().setLevel(root_level)
    _LEVELS_SET = True

def getLogger(name = None): # pylint: disable=invalid-name
    """
    Set logging levels (if they're not set) then fetch and return a 'logging'
    module logger for 'name'.
    """
    if not _LEVELS_SET:
        set_levels(
            os.getenv('LOG_LEVEL', 'INFO'),
            os.getenv('BOTO_LOG_LEVEL', 'ERROR'),
        )
    return logging_module.getLogger(name)

@contextmanager
def set_filter(logging_filter):
    """
    A context manager. Before the 'with' block executes, all filters are
    removed from each logging handler and the 'logging_filter' is added. After
    the 'with' block completes, 'logging_filter' is removed from each handler.
    """
    for handler in logging_module.getLogger().handlers:
        for filt in handler.filters:
            handler.removeFilter(filt)
        handler.addFilter(logging_filter)
    yield
    for handler in logging_module.getLogger().handlers:
        handler.removeFilter(logging_filter)

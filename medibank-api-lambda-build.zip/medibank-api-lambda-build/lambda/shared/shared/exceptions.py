"""
Exception classes.
"""

__copyright__ = '2017 Medibank Private Limited'

class LoggingLevelNotFoundException(Exception):
    """
    Raised when an invalid logging level is specified.
    """
    pass

class MissingEnvVariableException(Exception):
    """
    Raised when a Lambda environment variable is not set and has no default
    value.
    """
    pass

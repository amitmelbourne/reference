# vi: set ts=4 sts=4 sw=4 et fdm=indent fileencoding=utf8 sta :
"""
Helper functions for JWE/JWT operations.
"""
import arrow
import jwt
import jwe
from shared import logging
from shared.util import get_encryption_key

__copyright__ = '2017 Medibank Private Limited'

class Issuers(object):
    """
    A mapping to make code more readable.
    """
    # pylint: disable=no-init
    YoungAdults = 'mpl.ya'
    OnlineMemberServices = 'mpl.oms'
    OverseasHealthCover = 'mpl.oshc'

class JavascriptWebToken(dict):
    """
    Manage claims, signing and encrypting of a Javascript Web Token. Most
    methods of this class return the object being acted upon so that method
    calls can be chained like this:

        token = (
            shared.tokens.JavascriptWebToken.new(bp_id)
            .with_expiration(okta_session['expiresAt'])
            .with_claims({
                'bpId': bp_id,
                'sessionId': session_id,
            })
        )

    """
    _lifetime = 3600
    _expiration = None
    _algorithm = 'HS256'
    _reserved = set(('sub', 'iss', 'aud', 'nbf', 'jti', 'iat', 'exp'))

    def __init__(self, subject, *args, **kwargs):
        super(JavascriptWebToken, self).__init__(*args, **kwargs)
        self['sub'] = subject
        self['iss'] = 'jwt.issuer'
        self._lifetime = 3600
        self._log = logging.getLogger(__name__)

    @staticmethod
    def new(subject, *args, **kwargs):
        """
        Return a new JavascriptWebToken object.
        """
        return JavascriptWebToken(subject, *args, **kwargs)

    def with_issuer(self, issuer):
        """
        Set the JWT 'iss' registered claim and return the JavascriptWebToken to
        allow chaining.
        """
        self['iss'] = issuer
        return self

    def with_audience(self, audience):
        """
        Set the JWT 'aud' registered claim and return the JavascriptWebToken to
        allow chaining.
        """
        self['aud'] = audience
        return self

    def with_not_before(self, not_before):
        """
        Set the JWT 'nbf' registered claim and return the JavascriptWebToken to
        allow chaining.
        """
        self['nbf'] = not_before
        return self

    def with_jwt_id(self, jwt_id):
        """
        Set the JWT 'jti' registered claim and return the JavascriptWebToken to
        allow chaining.
        """
        self['jti'] = jwt_id
        return self

    def with_claims(self, *args, **kwargs):
        """
        Update JWT claims (with the same arguments as dict.update takes) but
        don't allow overriding reserved claims.
        """
        temp = {}
        temp.update(*args, **kwargs)
        self.update({ i for i in temp.iteritems() if i[0] not in self._reserved })
        return self

    def with_lifetime(self, lifetime):
        """
        Set the lifetime (in seconds) of the JWT. This is used to calculate the
        expiration ('exp' claim) when the JWT is generated and signed.
        """
        self._lifetime = int(lifetime)
        return self

    def with_expiration(self, expiration):
        """
        Directly set the expiration ('exp' claim) for the JWT based on a
        timestamp as understood by the arrow.get function.
        """
        self._expiration = arrow.get(expiration)
        return self

    def with_algorithm(self, algorithm):
        """
        Set the algorithm used to sign the JWT.
        """
        self._algorithm = algorithm
        return self

    @property
    def jwt(self):
        """
        Generate and sign the JWT.
        """
        now = arrow.utcnow()
        if self._expiration is None:
            self._expiration = now.shift(seconds = self._lifetime)

        self['iat'] = now.timestamp
        self['exp'] = self._expiration.timestamp

        self._log.debug(
            'Generating token',
            extra = dict(
                claims    = { k:v for k,v in self.iteritems() },
                algorithm = self._algorithm,
            )
        )

        return jwt.encode(
            self, get_encryption_key(),
            algorithm = self._algorithm,
        )

    @property
    def jwe(self):
        """
        Encrypt the JWT to make a JWE.
        """
        self._log.debug('Encrypting token')
        return jwe.encrypt(
            self.jwt,
            get_encryption_key(),
        )

class YoungAdultsJwt(JavascriptWebToken):
    """
    A JavascriptWebToken subclass that sets the issuer so we can identify the
    token as having been issued by the OMS Young Adults API.
    """
    def __init__(self, subject, *args, **kwargs):
        super(YoungAdultsJwt, self).__init__(subject, *args, **kwargs)
        self['iss'] = Issuers.YoungAdults

class OnlineMemberServicesJwt(JavascriptWebToken):
    """
    A JavascriptWebToken subclass that sets the issuer so we can identify the
    token as having been issued by the general OMS API.
    """
    def __init__(self, subject, *args, **kwargs):
        super(OnlineMemberServicesJwt, self).__init__(subject, *args, **kwargs)
        self['iss'] = Issuers.OnlineMemberServices

class OverseasHealthCoverJwt(JavascriptWebToken):
    """
    A JavascriptWebToken subclass that sets the issuer so we can identify the
    token as having been issued by the OSHC.
    """
    def __init__(self, subject, *args, **kwargs):
        super(OverseasHealthCoverJwt, self).__init__(subject, *args, **kwargs)
        self['iss'] = Issuers.OverseasHealthCover

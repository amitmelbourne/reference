# vi: set ts=4 sts=4 sw=4 et fdm=indent fenc=utf8 sta :
"""
Helper functions for JWE/JWT operations.
"""
import os
import json
from base64 import b64decode
import jwe
import boto3
from botocore.client import Config
from shared import logging
from shared.exceptions import MissingEnvVariableException

__copyright__ = '2017 Medibank Private Limited'

BOTO3_CLIENT_CONFIG = json.loads(os.getenv('BOTO3_CLIENT_CONFIG', '{}'))
CLIENT_CONFIG = Config(**BOTO3_CLIENT_CONFIG)

# TODO This module should be a class and singleton object to avoid global vars.
# pylint: disable=global-statement

_ENCRYPTION_KEY = None
def get_encryption_key():
    """
    Fetch and decrypt the ecnryption key used with JavascriptWebToken.
    """
    global _ENCRYPTION_KEY
    if _ENCRYPTION_KEY is None:
        secret_key = _get_encrypted_env_var('JWT_SECRET_KEY')
        _ENCRYPTION_KEY = jwe.kdf(secret_key, secret_key)
    return _ENCRYPTION_KEY

_OKTA_API_KEY = None
def get_okta_api_key():
    """
    Fetch and decrypt the Okta admin API key.
    """
    global _OKTA_API_KEY
    if _OKTA_API_KEY is None:
        _OKTA_API_KEY = _get_encrypted_env_var('OKTA_API_KEY')
    return _OKTA_API_KEY

def _get_encrypted_env_var(env_var_name):
    log = logging.getLogger(__name__)
    kms = boto3.client('kms', config = CLIENT_CONFIG)
    encrypted_env_var = os.getenv(env_var_name, '')
    if not encrypted_env_var:
        raise MissingEnvVariableException('Envrionment variable "%s" is not set.'%env_var_name)
    secret = (
        kms.decrypt(CiphertextBlob = b64decode(encrypted_env_var))
        .get('Plaintext')
    )
    if secret:
        log.debug(
            "Successfully decrypted secret.",
            extra = dict(secret_length = len(secret)),
        )
    return secret

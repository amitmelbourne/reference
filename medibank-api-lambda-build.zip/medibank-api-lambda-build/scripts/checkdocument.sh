#!/bin/bash -xe


apiID=$1
region=$2

dStages=($(aws apigateway get-stages --rest-api-id ${apiID} --region ${region} | jq -r '.item|map("\(.deploymentId)-\(.stageName)")[]'))

for dStage in "${dStages[@]}"; do
    stage=$( sed -e 's/.*-//' <<< ${dStage} )
    curr=/opt/sourcedocs/${dStage}.json

    if ! [[ -e $curr ]]; then
        aws apigateway get-export --rest-api-id ${apiID} --stage-name ${stage} --region ${region} --export-type swagger ${curr}
        chmod o+r ${curr}
    fi

    ln -sf ${curr} /var/www/html/${stage}.json

done



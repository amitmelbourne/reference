#!/bin/bash


pushd "$(dirname ${0})" > /dev/null
SCRIPT_PATH="$(pwd)"
CFTMPL_PATH="$SCRIPT_PATH/../cloudformation"
LAMBDA_PATH="$SCRIPT_PATH/../lambda"
popd > /dev/null

pushd "$LAMBDA_PATH"
pip install -r requirements.txt -t .
zip -r ../young-adult-api.zip .
popd

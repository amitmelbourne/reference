package com.medibank.digital.notification;

import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.DeleteMessageBatchRequest;
import com.amazonaws.services.sqs.model.DeleteMessageBatchRequestEntry;
import com.amazonaws.services.sqs.model.DeleteMessageBatchResult;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.google.common.base.Preconditions;
import com.medibank.digital.notification.config.AppConfig;
import com.medibank.digital.notification.config.EmailNotification;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.HashMap;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.app.VelocityEngine;

import java.util.*;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

@Slf4j
@Component("awsLambdaSqsFunction")
public class AwsLambdaSqsFunction implements Function<Void, Void> {

    @Autowired
    private AppConfig appConfig;

    @Autowired
    private AmazonSQS amazonSqs;

    @Autowired
    private EmailNotification emailNotification;

    @Autowired
    private VelocityEngine velocityEngine;

    public static final String SUBJECT = "SUBJECT";
    public static final String TEMPLATE_ID = "TEMPLATE_ID";
    public static final String ATTACHMENT_URI = "ATTACHMENT_URI";
    public static final String FAILURE_REASON = "failureReason";

    @Override
    public Void apply(Void empty) {
        String queueMsg = null;
        String emailBody = null;
        List<File> attachmentList = null;
        Map<String, String> jsonMsg = new HashMap<>();
        String queueUrl = appConfig.getQueueUrl();
        List<Message> messageList = this.getQueueMessageByQueueUrl(queueUrl);
        for (Message message : messageList) {
            queueMsg = message.getBody().toString();
            if (queueMsg != null) {
                try {
                    jsonMsg = jsonParse(queueMsg);
                    attachmentList = getAttachment(queueMsg);
                    emailBody = getEmailString(jsonMsg.get(TEMPLATE_ID), queueMsg);
                    emailNotification.sendEmail(jsonParseForRecipient(queueMsg), jsonMsg.get(SUBJECT), attachmentList, emailBody);

                } catch (Exception e) {
                    try {
                        log.info("$$$$$$$$$$$$$$$#######################$$$$$$$$$$$$$$$$$$################# Second Attempt  : ");
                        log.error("Error while sending email notification", e);
                        emailNotification.sendEmail(jsonParseForRecipient(queueMsg), jsonMsg.get(SUBJECT), attachmentList, emailBody);
                    } catch (Exception ae) {
                        log.info("$$$$$$$$$$$$$$$#######################$$$$$$$$$$$$$$$$$$################# Sending JSON to another Queue  : ");
                        sendQueueMessageByQueueUrl(queueMsg, e.getMessage());
                        log.error("Error while sending email notification", e);
                    }
                }
                this.deleteMessagesByQueueUrl(messageList, queueUrl);
            }
        }

        return empty;
    }


    private void deleteMessagesByQueueUrl(List<Message> messageList, String queueUrl) {
        Preconditions.checkArgument(!messageList.isEmpty(), "Empty list for removal.");
        List<DeleteMessageBatchRequestEntry> deleteMessageEntries = new ArrayList<>();
        messageList.forEach(message ->
                deleteMessageEntries.add(
                        new DeleteMessageBatchRequestEntry(message.getMessageId(), message.getReceiptHandle())
                ));
        DeleteMessageBatchRequest deleteRequest = new DeleteMessageBatchRequest();
        deleteRequest.setQueueUrl(queueUrl);
        deleteRequest.setEntries(deleteMessageEntries);
        DeleteMessageBatchResult result = amazonSqs.deleteMessageBatch(deleteRequest);
    }

    private static Map<String, String> jsonParse(String queueMsg) {
        log.info("$$$$$$$$$$$$$$$#######################$$$$$$$$$$$$$$$$$$################# JSON PARSE  : " + queueMsg);
        Map jsonMsg = new HashMap<>();
        String subject = null;
        String url = null;
        String templateUrl = null;
        try {
            JSONObject jsonObj = new JSONObject(queueMsg.trim());
            subject = (String) jsonObj.get("subject");
            templateUrl = (String) jsonObj.get("templateId");
            JSONArray attachments = jsonObj.getJSONArray("attachments");
            if (attachments != null) {
                for (int i = 0; i < attachments.length(); i++) {
                    url = attachments.getJSONObject(i).getString("url");
                }
            }
            if (StringUtils.isNotBlank(subject)) {
                jsonMsg.put(SUBJECT, subject.trim());
            }
            if (StringUtils.isNotBlank(templateUrl)) {
                jsonMsg.put(TEMPLATE_ID, templateUrl.trim());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsonMsg;
    }

    private static ArrayList jsonParseForRecipient(String queueMsg) {
        ArrayList<String> recipient = new ArrayList<String>();
        JSONObject jsonObj = new JSONObject(queueMsg.trim());
        JSONArray to = jsonObj.getJSONArray("to");
        if (to != null) {
            for (int i = 0; i < to.length(); i++) {
                recipient.add(to.getJSONObject(i).getString("recipient"));
            }
        }
        log.debug("Recipients: "+ recipient);
        return recipient;
    }

    private static Map<String, String> jsonParseForContent(String queueMsg) {
        Map<String, String> key = new HashMap();
        JSONObject jsonObj = new JSONObject(queueMsg.trim());
        JSONArray contentArr = jsonObj.getJSONArray("content");
        if (contentArr != null) {
            for (int i = 0; i < contentArr.length(); i++) {
                key.put(contentArr.getJSONObject(i).getString("key"), contentArr.getJSONObject(i).getString("value"));
            }
        }
        return key;
    }

    private List<Message> getQueueMessageByQueueUrl(String queueUrl) {
        //ReceiveMessageRequest messageRequest = new ReceiveMessageRequest(queueUrl).
          //      withWaitTimeSeconds(5).withMaxNumberOfMessages(1);
        ReceiveMessageRequest messageRequest = new ReceiveMessageRequest(queueUrl).withMaxNumberOfMessages(10);
        List<Message> messages = amazonSqs.receiveMessage(messageRequest).getMessages();
        log.debug("Receive Message Request Size: "+ messages.size());
        return messages;
    }

    private void sendQueueMessageByQueueUrl(String message, String error) {
        String dlqQueueUrl = appConfig.getDlqQueueUrl();
        JSONObject jsonObj = new JSONObject(message.trim());
        jsonObj.put(FAILURE_REASON, error);
        try {
            amazonSqs.sendMessage(new SendMessageRequest()
                    .withQueueUrl(dlqQueueUrl)
                    .withMessageBody(jsonObj.toString()));
        } catch (Exception e) {
            log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$############################################### sendQueueMessageByQueueUrl Exception : " + e.getMessage());
        }
    }

    public List<File> getAttachment(String queueMsg) {

        List<File> attachment = new ArrayList<File>();
        JSONObject jsonObj = new JSONObject(queueMsg.trim());
        JSONArray attach = jsonObj.getJSONArray("attachments");
        if (attach != null) {
            for (int i = 0; i < attach.length(); i++) {
                File file = null;
                if (StringUtils.isNotBlank(attach.getJSONObject(i).getString("url"))) {
                    log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$############################################### getAttachment attachment URI  : " + attach.getJSONObject(i).getString("url"));
                    try {
                        URL attachUrl = new URL(attach.getJSONObject(i).getString("url"));
                        String[] docTokens = attachUrl.getPath().split("/");
                        String documentBucketName = docTokens[1];
                        List<String> tokens = new ArrayList<>(Arrays.asList(docTokens));
                        tokens.remove(docTokens[0]);
                        tokens.remove(docTokens[1]);
                        String documentKey = String.join("/", tokens);
                        log.info("Document bucket name, "+ documentBucketName + " key, "+ documentKey);
                        AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
                        file = new File("/tmp/".concat(documentKey));
                        if (file.exists()) {
                            file.delete();
                        }
                        s3.getObject(
                                new GetObjectRequest(documentBucketName, documentKey),
                                file
                        );
                    } catch (Exception ace) {
                        sendQueueMessageByQueueUrl(queueMsg, ace.getMessage());
                        log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$############################################## $$$$ Exception Occured in file Creation: " + ace.getMessage());
                    }
                    attachment.add(file);
                }
            }
        }
        return attachment;
    }


    public String getEmailString(String ddocUrl, String queueMsg) {
        log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$############################################### getAttachment attachment URI  : " + ddocUrl);
        File file = null;
        String template = null;
        Map<String, String> mp = null;
        StringWriter swOut = null;
        Properties props = new Properties();
        props.put("runtime.log.logsystem.class", "org.apache.velocity.runtime.log.SimpleLog4JLogSystem");
        props.put("runtime.log.logsystem.log4j.category", "velocity");
        props.put("runtime.log.logsystem.log4j.logger", "velocity");

        try {
            URL attachUrl = new URL(ddocUrl);
            String[] docTokens = attachUrl.getPath().split("/");
            String documentBucketName = docTokens[1];
            List<String> tokens = new ArrayList<>(Arrays.asList(docTokens));
            tokens.remove(docTokens[0]);
            tokens.remove(docTokens[1]);
            String documentKey = String.join("/", tokens);
            log.info("Document bucket name, "+ documentBucketName + " key, "+ documentKey);
            // String documentKey = docTokens[2] + "/" + docTokens[3] + "/" + docTokens[4];
            AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion(Regions.AP_SOUTHEAST_2).build();
            template = s3.getObjectAsString(documentBucketName, documentKey);
            Velocity.init(props);
            VelocityContext context = new VelocityContext();
            mp = jsonParseForContent(queueMsg);

            if (mp != null && !mp.isEmpty()) {
                Iterator it = mp.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry) it.next();
                    context.put(pair.getKey().toString(), pair.getValue().toString());
                    it.remove(); // avoids a ConcurrentModificationException
                }
            }
            swOut = new StringWriter();
            Velocity.evaluate(context, swOut, "notification", template);
        } catch (Exception ace) {
            sendQueueMessageByQueueUrl(queueMsg, ace.getMessage());
            log.info("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$############################################## $$$$ Exception Occured in Template Creation: " + ace.getMessage());
        }
        return swOut.toString().trim();
    }
}

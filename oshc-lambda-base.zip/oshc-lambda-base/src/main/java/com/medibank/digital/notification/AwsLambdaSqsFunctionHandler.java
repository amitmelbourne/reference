package com.medibank.digital.notification;

import org.springframework.cloud.function.adapter.aws.SpringBootRequestHandler;

public class AwsLambdaSqsFunctionHandler extends SpringBootRequestHandler<Void,Void>{
}

package com.medibank.digital.notification.config;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.ClientConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.regions.Regions;

@Configuration
public class AwsClientConfig {
    @Bean
    public AmazonSQS awsSQSClient(){
        AmazonSQS awsSQS;
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setProxyHost("proxy.aws.medibank.local");
        clientConfig.setProxyPort(8080);
        awsSQS = new AmazonSQSClient(clientConfig);

        // awsSQS = AmazonSQSClientBuilder.standard().withClientConfiguration(clientConfig).withRegion(Regions.AP_SOUTHEAST_2).build();
        return awsSQS;

    }
}

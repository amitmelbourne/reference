package com.medibank.digital.notification.config;


import org.apache.velocity.app.VelocityEngine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import javax.mail.Message.RecipientType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.InternetAddress;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class EmailNotification {

    private static final String ENCODING = "UTF-8";
    private static final String HTML_MAIL_TYPE = "html";
    public static final String ATTACHMENTS_PROP_NAME = "ATTACHMENTS";

    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private VelocityEngine velocityEngine;
    @Value("${app.config.url}")
    private String appUrl;
    @Value("${app.config.mail.enabled}")
    private boolean mailEnabled;


    public boolean sendEmail(final ArrayList<String> recipients, final String subject, final List<File> attachmentList, final String emailBody) throws Exception {
        return sendEmail(recipients, subject, null, attachmentList, emailBody);
    }

    

    public boolean sendEmail(final ArrayList<String> recipients, final String subject, final String from, final List<File> attachmentList, final String emailBody) throws Exception {
        boolean returnValue = true;
        if (!mailEnabled) {
            return true;
        }

        mailSender.send(new MimeMessagePreparator() {
            @Override
            public void prepare(MimeMessage message) throws Exception {
                if (!StringUtils.isEmpty(from)) {
                    message.setFrom(from);
                }
                InternetAddress[] recipientAddress = new InternetAddress[recipients.size()];
                int counter = 0;
                for (String recipient : recipients) {
                    recipientAddress[counter] = new InternetAddress(recipient.trim());
                    counter++;
                }
                message.setSubject(subject);
                message.setRecipients(RecipientType.TO, recipientAddress);

                MimeMultipart content = new MimeMultipart("related");
                MimeBodyPart mainPart = new MimeBodyPart();
                mainPart.setText(emailBody, ENCODING, HTML_MAIL_TYPE);
                content.addBodyPart(mainPart);
                if(attachmentList != null){
                    for (File f : attachmentList) {
                        MimeBodyPart filePart = new MimeBodyPart();
                        filePart.attachFile(f);
                        content.addBodyPart(filePart);
                    }
                }
                   message.setContent(content);
            }
        });

        return returnValue;

    }

}

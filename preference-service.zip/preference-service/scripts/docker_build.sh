#!/bin/bash

set -e
set -x

export DOCKER_IMAGE='652299490072.dkr.ecr.ap-southeast-2.amazonaws.com/medibank-digital/preference-service'

export RELEASE_VERSION=${RELEASE_VERSION:-1.0}
export VERSION_MAJOR=${VERSION_MAJOR:-0}
export BUILD_NUMBER=${BUILD_NUMBER:-0}
export VERSION="$RELEASE_VERSION.$VERSION_MAJOR-$BUILD_NUMBER"

set +x
eval $(aws --region ap-southeast-2 ecr get-login)
set -x

docker build -t $DOCKER_IMAGE:$VERSION .
docker tag $DOCKER_IMAGE:$VERSION $DOCKER_IMAGE:$VERSION
docker push $DOCKER_IMAGE:$VERSION

docker build -t $DOCKER_IMAGE:latest .
docker tag $DOCKER_IMAGE:latest $DOCKER_IMAGE:latest
docker push $DOCKER_IMAGE:latest

echo "docker_image_version=$VERSION" > docker_image_version

exit 0
#!/bin/sh

set -x
set -e

if [ -z "${ENVIRONMENT}" ]; then
    echo "ENVIRONMENT variable not set"
    exit 1
fi

set JAVA_OPTS="-Xms128m -Xmx256m"

java ${JAVA_OPTS} \
     -XX:MaxRAM=1000m  \
	 -XX:+UseSerialGC \
	 -XX:MinHeapFreeRatio=20 \
	 -XX:MaxHeapFreeRatio=40 \
	 -javaagent:/medibank/newrelic/newrelic.jar \
     -Dnewrelic.environment=$ENVIRONMENT \
     -Dspring.profiles.active=$ENVIRONMENT \
     -jar /medibank/service/preference.jar
	 
     

package com.medibank.digital.mym.preference;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by 920538 on 02/17/2018.
 */
@SpringBootApplication

public class PreferenceServiceApplication {
    public static void main(String[] args) {

        SpringApplication.run(com.medibank.digital.mym.preference.PreferenceServiceApplication.class, args);
    }
}

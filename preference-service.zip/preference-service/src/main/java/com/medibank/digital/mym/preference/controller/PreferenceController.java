package com.medibank.digital.mym.preference.controller;

import com.medibank.digital.mym.preference.PreferenceServiceApplication;
import com.medibank.digital.mym.preference.helper.BeanObjectFactory;
import com.medibank.digital.mym.preference.model.PreferenceBean;
import com.medibank.digital.mym.preference.model.Response;
import com.medibank.digital.mym.preference.service.PreferenceService;
import com.medibank.digital.mym.preference.util.CommonUtility;
import com.medibank.digital.mym.preference.util.ErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PreferenceController {

    @Autowired
    private PreferenceService preferenceService;

    @Autowired
    private BeanObjectFactory beanObjectFactory;

    @Autowired
    private CommonUtility commonUtility;

    private static final Logger log = LoggerFactory.getLogger(PreferenceController.class);

    @RequestMapping(value = "/preference", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    public @ResponseBody
    ResponseEntity<?> saveUserPreference(@RequestBody PreferenceBean preferenceDetails) {
        try {
            log.info("Saving the User Preference ------>");
            if(preferenceDetails.getBpId()==null){
                throw new Exception(ErrorType.ERROR_BPID_NULL.getDescription());
            }
            preferenceService.savePreferenceData(preferenceDetails);
            Response response = beanObjectFactory.getResponse();
            response.setMessage("Success");
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        }
        catch(Exception ex){
            return new ResponseEntity<>(commonUtility.setExceptionResponse(ex),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/preference", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody
    ResponseEntity<?> getUserPreference(@RequestParam(value = "bpId") String bpId,
                                        @RequestParam(value = "preferenceType", required = false) String preferenceType,
                                        @RequestParam(value = "preferenceSubType", required = false) String preferenceSubType) {
        try {
            log.info("Getting  the User Preference for User /preference?bpId="+bpId);
            if (bpId == null) {
                throw new Exception(ErrorType.ERROR_BPID_NULL.getDescription());
            }
            List<PreferenceBean> response = preferenceService.getUserPreference(bpId, preferenceType, preferenceSubType);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception ex) {
            if (ex.getMessage().equalsIgnoreCase(ErrorType.ERROR_PREFERENCE_NOT_FOUND.getDescription())) {
                Response response = beanObjectFactory.getResponse();
                response.setMessage("No User Preference returned for bpId: " + bpId);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
            return new ResponseEntity<>(commonUtility.setExceptionResponse(ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * getting all the preferences for the user .
     */
    @RequestMapping(value = "/preference/{bpId}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody
    ResponseEntity<?> getUserPreferenceList(@PathVariable String bpId) {
        try {
            log.info("Getting  the User Preference for User /preference/"+bpId);
            if (bpId == null) {
                throw new Exception(ErrorType.ERROR_BPID_NULL.getDescription());
            }
            List<PreferenceBean> response = preferenceService.getUserPreference(bpId,null,null);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception ex) {
            if (ex.getMessage().equalsIgnoreCase(ErrorType.ERROR_PREFERENCE_NOT_FOUND.getDescription())) {
                Response response = beanObjectFactory.getResponse();
                response.setMessage("No User Preference returned for bpId: " + bpId);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
            return new ResponseEntity<>(commonUtility.setExceptionResponse(ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     *  getting the user Preference for a particular preferenceType and SubType .
     */
    @RequestMapping(value = "/preference/{bpId}/preferenceType/{preferenceType}/preferenceSubType/{preferenceSubType}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody
    ResponseEntity<?> getUserPreferenceOfpreferenceType(@PathVariable String bpId,
                                        @PathVariable String preferenceType,
                                        @PathVariable String preferenceSubType) {
        try {
            log.info("Getting  the User Preference for  preferenceType and preferenceSubType ");
            if (bpId == null) {
                throw new Exception(ErrorType.ERROR_BPID_NULL.getDescription());
            }
            List<PreferenceBean> response = preferenceService.getUserPreference(bpId, preferenceType, preferenceSubType);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception ex) {
            if (ex.getMessage().equalsIgnoreCase(ErrorType.ERROR_PREFERENCE_NOT_FOUND.getDescription())) {
                Response response = beanObjectFactory.getResponse();
                response.setMessage("No Preference returned for bpId: " + bpId);
                return new ResponseEntity<>(response, HttpStatus.OK);
            }
            return new ResponseEntity<>(commonUtility.setExceptionResponse(ex), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @RequestMapping(value = "/healthCheck", method = RequestMethod.GET, produces = "text/plain")
    public ResponseEntity getHealthCheck() throws Exception {
        return ResponseEntity.ok("Up and Running");
    }

}

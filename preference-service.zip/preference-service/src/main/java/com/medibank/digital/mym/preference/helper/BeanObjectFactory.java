package com.medibank.digital.mym.preference.helper;

import com.medibank.digital.mym.preference.model.*;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public class BeanObjectFactory {


    @Lookup
    public Response getResponse() {
        return null;
    }
}

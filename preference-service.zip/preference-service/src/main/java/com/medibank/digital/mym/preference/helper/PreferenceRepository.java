package com.medibank.digital.mym.preference.helper;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.medibank.digital.mym.preference.model.PreferenceBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PreferenceRepository {

    private static final Logger logger = LoggerFactory.getLogger(PreferenceRepository.class);

    @Autowired
    private DynamoDBMapper dbMapper;

    @Value("${user.preference.db.name}")
    private String tableName;

    public void saveUserPreference(PreferenceBean userPreferenceData) throws Exception {
        logger.info("Saving preference for bpId: "+ userPreferenceData.getBpId()+" in tableName"+tableName);
        dbMapper.save(userPreferenceData,new DynamoDBMapperConfig.Builder().withSaveBehavior(DynamoDBMapperConfig.SaveBehavior.APPEND_SET).
                withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement(tableName)).build());
    }

    public List<PreferenceBean> getUserPreference(String bpId, String preferenceType, String preferenceSubType) throws Exception {

        Map<String, AttributeValue> eav = new HashMap<>();
        eav.put(":bpId", new AttributeValue().withS(bpId));
        if (preferenceType != null) {
            eav.put(":preferenceType", new AttributeValue().withS(preferenceType));
        }
        if (preferenceSubType != null) {
            eav.put(":preferenceSubType", new AttributeValue().withS(preferenceSubType));
        }
        String filterExpression = ("bpId= :bpId");
        filterExpression = filterExpression + (preferenceType != null ? (" AND preferenceType= :preferenceType") : "") +
                (preferenceSubType != null ? (" AND preferenceSubType= :preferenceSubType") : "");

        DynamoDBQueryExpression queryExpression = new DynamoDBQueryExpression()
                .withKeyConditionExpression(filterExpression)
                .withExpressionAttributeValues(eav);

        List<PreferenceBean> preferenceBeans = new ArrayList<>();
        preferenceBeans = dbMapper.query(PreferenceBean.class, queryExpression,
                new DynamoDBMapperConfig.Builder().withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement(tableName)).build()
        );

        if (preferenceBeans!=null && preferenceBeans.size() > 0) {
            return preferenceBeans;
        } else {
            return preferenceBeans;
        }
    }
}

package com.medibank.digital.mym.preference.model;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Component
@DynamoDBTable(tableName = "User-Preference")
public class PreferenceBean {
    private String	bpId;
    private String	preferenceType_preferenceSubType;
    private String policyId;
    private String preferenceType;
    private String preferenceSubType;
    private String value;
    private String startDate;
    private String endDate;

    @DynamoDBHashKey(attributeName = "bpId")
    public String getBpId() {
        return bpId;
    }

    public void setBpId(String bpId) {
        this.bpId = bpId;
    }

    @DynamoDBRangeKey(attributeName = "preferenceType-preferenceSubType")
    public String getPreferenceType_preferenceSubType() {
        return preferenceType_preferenceSubType;
    }

    public void setPreferenceType_preferenceSubType(String preferenceType_preferenceSubType) {
        this.preferenceType_preferenceSubType = preferenceType_preferenceSubType;
    }
    @DynamoDBAttribute(attributeName = "policyId")
    public String getPolicyId() {
        return policyId;
    }

    public void setPolicyId(String policyId) {
        this.policyId = policyId;
    }

    @DynamoDBAttribute(attributeName = "preferenceType")
    public String getPreferenceType() {
        return preferenceType;
    }

    public void setPreferenceType(String preferenceType) {
        this.preferenceType = preferenceType;
    }
    @DynamoDBAttribute(attributeName = "preferenceSubType")
    public String getPreferenceSubType() {
        return preferenceSubType;
    }

    public void setPreferenceSubType(String preferenceSubType) {
        this.preferenceSubType = preferenceSubType;
    }
    @DynamoDBAttribute(attributeName = "value")
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @DynamoDBAttribute(attributeName = "startDate")
    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @DynamoDBAttribute(attributeName = "endDate")
    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "PreferenceBean{" +
                "bpId='" + bpId + '\'' +
                ", policyId='" + policyId + '\'' +
                ", preferenceType='" + preferenceType + '\'' +
                ", preferenceSubType='" + preferenceSubType + '\'' +
                ", value='" + value + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                '}';
    }
}

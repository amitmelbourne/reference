package com.medibank.digital.mym.preference.service;

import com.medibank.digital.mym.preference.helper.PreferenceRepository;
import com.medibank.digital.mym.preference.model.PreferenceBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.constraints.Max;
import java.util.List;

@Service
public class PreferenceService {

    @Autowired
    private PreferenceRepository preferenceRepository;

    public void savePreferenceData(PreferenceBean preferenceDetails) throws Exception {
        preferenceDetails.setPreferenceType_preferenceSubType(preferenceDetails.getPreferenceType() + "-" +preferenceDetails.getPreferenceSubType());
        preferenceRepository.saveUserPreference(preferenceDetails);
    }

    public List<PreferenceBean> getUserPreference(String bpId, String preferenceType, String preferenceSubType) throws Exception {
        return preferenceRepository.getUserPreference(bpId,preferenceType,preferenceSubType);
    }
}

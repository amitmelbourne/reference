package com.medibank.digital.mym.preference.util;

import com.medibank.digital.mym.preference.helper.BeanObjectFactory;
import com.medibank.digital.mym.preference.model.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CommonUtility {
    @Autowired
    private BeanObjectFactory beanObjectFactory;

    public Response setExceptionResponse(Exception ex){
        Response error= beanObjectFactory.getResponse();
        if(ex instanceof NullPointerException) {
            error.setMessage("Error servicing request");
        }else {
            error.setMessage(ex.getMessage());
        }
        return error;
    }
}

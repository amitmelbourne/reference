package com.medibank.digital.mym.preference.util;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DynamoDBConfiguration {

    private final Logger log = LoggerFactory.getLogger(getClass());


    @Bean
    public AmazonDynamoDB amazonDynamoDb() {
        System.out.println("inside the amazonDynamoDb method to initiate the client ");
        ClientConfiguration clientConfig = new ClientConfiguration();
        clientConfig.setProtocol(Protocol.HTTPS);
        clientConfig.setProxyHost("proxy.aws.medibank.local");
        clientConfig.setProxyPort(8080);

        AmazonDynamoDB dynamoClient = null;
        dynamoClient = AmazonDynamoDBClientBuilder.standard().withCredentials(new InstanceProfileCredentialsProvider(false)).withClientConfiguration(clientConfig).withRegion(Regions.AP_SOUTHEAST_2).build();

        return dynamoClient;

    }

    @Bean
    public DynamoDBMapper dynamoDbMapper(AmazonDynamoDB amazonDynamoDB) {

        log.trace("Entering dynamoDbMapper()");
        return new DynamoDBMapper(amazonDynamoDB);
    }

}


package com.medibank.digital.mym.preference.util;

public enum ErrorType {
    ERROR_PREFERENCE_NOT_FOUND("ERR_P001", "Preference not found for User"),
    ERROR_BPID_NULL("bpId cannot be null");

    private final String code;

    private final String description;

    private ErrorType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    private ErrorType(String description) {
        this.code = "";
        this.description = description;
    }

    public String getCode() {
        return code;
    }
    public String getDescription() {
        return description;
    }
}

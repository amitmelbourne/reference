package com.medibank.digital.mym.preference.controller

import com.medibank.digital.mym.preference.helper.BeanObjectFactory
import com.medibank.digital.mym.preference.model.PreferenceBean
import com.medibank.digital.mym.preference.service.PreferenceService
import com.medibank.digital.mym.preference.util.CommonUtility
import spock.lang.Specification

class PreferenceControllerTest extends Specification{
    private PreferenceController controller;
    def preferenceService = Mock(PreferenceService)
    def beanObjectFactory = Mock(BeanObjectFactory)
    def commonUtility = Mock(CommonUtility)

    void setup() {
        controller = new PreferenceController('preferenceService': preferenceService,
                'beanObjectFactory': beanObjectFactory,
                'commonUtility': commonUtility);
    }

    def "get All UserPreference for a bpId"() {
        setup:
        List<PreferenceBean> preferenceList = new ArrayList<>();
        PreferenceBean userPreference = new PreferenceBean();
        userPreference.setBpId("100001");
        preferenceList.add(userPreference)

        when:
        String bpId = "100001";
        def response = controller.getUserPreferenceList(bpId)
        preferenceService.getUserPreference(_, _, _) >> preferenceList;

        then:
        response.getStatusCodeValue() == 200;

    }

    def "get  UserPreference for a particular notification Type and SubType"() {
        setup:
        List<PreferenceBean> preferenceList = new ArrayList<>();
        PreferenceBean userPreference = new PreferenceBean();
        userPreference.setBpId("100001");
        preferenceList.add(userPreference)

        when:
        String bpId = "100001";
        def preferenceType = 'settings';
        def preferenceSubType = 'policy_dropdown_preference';
        def response = controller.getUserPreferenceOfpreferenceType(bpId, preferenceType, preferenceSubType)
        preferenceService.getUserPreference(_, _, _) >> preferenceList;

        then:
        response.getStatusCodeValue() == 200;

    }
}

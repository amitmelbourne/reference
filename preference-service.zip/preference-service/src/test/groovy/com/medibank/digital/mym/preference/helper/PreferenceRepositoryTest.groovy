package com.medibank.digital.mym.preference.helper

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedQueryList
import com.amazonaws.services.dynamodbv2.datamodeling.PaginatedScanList
import com.medibank.digital.mym.preference.model.PreferenceBean
import spock.lang.Specification

class PreferenceRepositoryTest extends Specification{
    PreferenceRepository repository;
    DynamoDBMapper dbMapper

    void setup() {
        dbMapper = Mock(DynamoDBMapper);
        repository = new PreferenceRepository('dbMapper': dbMapper);
    }

    def "saving UserPreference in dynamodb returning SUCCESS"(){
      setup:
      PreferenceBean preferenceDetails = new PreferenceBean(bpId: '10001', preferenceType: 'setting',
              preferenceSubType: 'policy_dropdown_preference');
      when:
      repository.saveUserPreference(preferenceDetails);

      then:
      1*dbMapper.save(_,_);
    }

    def "getting  UserPreference from dynamodb returning SUCCESS"() {
        setup:
        DynamoDBScanExpression queryExpression = Mock(DynamoDBScanExpression);
        def bpId = '10001';
        def preferenceType = 'settings';
        def preferenceSubType = 'policy_dropdown_preference';
        def preferenceDetails = new PreferenceBean(bpId: '10001', preferenceType: 'setting',
                preferenceSubType: 'policy_dropdown_preference');
        def PaginatedQueryListMock = Mock(PaginatedQueryList);

        when:
        repository.getUserPreference(bpId, preferenceType, preferenceSubType);

        then:
        PaginatedQueryListMock.get(0) >> preferenceDetails
        1 * PaginatedQueryListMock.size() >> 1
        1 * dbMapper.query(_, _, _) >> PaginatedQueryListMock;
    }
}

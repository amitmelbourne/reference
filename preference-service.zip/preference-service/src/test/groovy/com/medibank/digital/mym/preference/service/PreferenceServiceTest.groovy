package com.medibank.digital.mym.preference.service

import com.medibank.digital.mym.preference.helper.PreferenceRepository
import com.medibank.digital.mym.preference.model.PreferenceBean
import spock.lang.Specification

class PreferenceServiceTest extends Specification {

    private PreferenceService service;
    private PreferenceRepository preferenceRepository;
    PreferenceBean preferenceDetails;

    void setup() {

        preferenceRepository = Mock(PreferenceRepository);
        service = new PreferenceService('preferenceRepository': preferenceRepository);
        preferenceDetails = new PreferenceBean(bpId: '10001', preferenceType: 'setting',
                preferenceSubType: 'policy_dropdown_preference');

    }

    def "verify savePreferenceData SUCCESS"() {

        when:
        def result = service.savePreferenceData(preferenceDetails);

        then:
        1 * preferenceRepository.saveUserPreference(_);

    }

    def "verify getUserPreference for a bpId only SUCCESS  "() {
        setup:
        def bpId = '10001';
        def preferenceType = 'settings';
        def preferenceSubType = 'policy_dropdown_preference';

        def preferenceDetails2 = new PreferenceBean(bpId: '10001', preferenceType: 'notifications',
                preferenceSubType: 'pop_ups');
        def preferenceDetailsList = new ArrayList();
        preferenceDetailsList.add(preferenceDetails);
        preferenceDetailsList.add(preferenceDetails2);

        when:
        def result = service.getUserPreference(bpId, preferenceType, preferenceSubType);

        then:
        1 * preferenceRepository.getUserPreference(_, _, _) >> preferenceDetailsList;
        result.size() == 2
    }

    def "verify getUserPreference for a  bpId,preferenceType and SubType  SUCCESS  "() {
        setup:
        def bpId = '10001';
        def preferenceType = 'settings';
        def preferenceSubType = 'policy_dropdown_preference';
        def preferenceDetailsList = new ArrayList();
        preferenceDetailsList.add(preferenceDetails);

        when:
        def result = service.getUserPreference(bpId, preferenceType, preferenceSubType);

        then:
        1 * preferenceRepository.getUserPreference(_, _, _) >> preferenceDetailsList;
        result.size() == 1

    }

}

""""returns addition of two number"""
def add(num1,num2):
    return num1 + num2

def sub(num1,num2):
    return num1-num2

def mul(num1,num2):
    return num1*num2

def div(num1,num2):
    return num1/num2

def main():
    """"calling input function"""
    num1 = int(input("Enter num1 "))
    num2 = int(input("Enter num2 "))
    print(add(num1,num2))
    print(sub(num1,num2))
    print(mul(num1,num2))
    print(div(num1,num2))

main()

def main():
    print("Hello World")
    myName = input("What you want to run? ")
    print(myName)

def printlist():
    mylist = ['Amit', 'dilip', 'kamal']
    print ('\n'.join(mylist))

def printlistwitharg(mylist):
    print ('\n'.join(mylist))

myVar = 'Tinu'
main()
print (myVar)
printlist()
mylist = ['tinu', 'mastu', 'ashu']
printlistwitharg(mylist)

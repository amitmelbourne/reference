#!/bin/sh

set -x
set -e

if [ -z "${ENVIRONMENT}" ]; then
    echo "ENVIRONMENT variable not set"
    exit 1
fi

java -Dspring.profiles.active=$ENVIRONMENT \
     -jar /medibank/service/service.jar

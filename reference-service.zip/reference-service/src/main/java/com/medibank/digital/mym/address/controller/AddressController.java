package com.medibank.digital.mym.address.controller;

import com.medibank.digital.mym.address.model.Address;
import com.medibank.digital.mym.address.services.AddressService;
import com.medibank.digital.mym.address.util.CommonUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Created by 920465 on 12/20/2017.
 */
@RestController
public class AddressController implements ErrorController {
    private static final Logger logger = LoggerFactory.getLogger(AddressController.class);

    @Autowired
    private CommonUtility commonUtility;

    @Autowired
    private AddressService addressService;

    private static final String PATH = "/error";

    @RequestMapping(value = "/reference/select" , method = RequestMethod.GET, produces = "application/json")
        public @ResponseBody ResponseEntity<?> validateAddress(@RequestParam(value="address", required = true) String address){
        try {
            logger.info("Inside /reference/select: param1= "+address);

            Address response = addressService.validateAddress(address);
            logger.info("Exiting /validateaddress");
            return new ResponseEntity<Object>(response, HttpStatus.OK);

        }catch (Exception ex)
        {   Error error= new Error();
            logger.error(ex.getMessage());
            return new ResponseEntity<Object>(commonUtility.setExceptionResponse(ex),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/reference/address" , method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody ResponseEntity<?> searchAddress(@RequestParam(value="address", required = false) String address,
                                                               @RequestParam(value="limit", required = false) String limit,
                                                               @RequestParam(value="as", required = false) String as,
                                                               @RequestParam(value="addressFormat", required = false) String addressFormat,
                                                               @RequestParam(value="callback", required = false) String callback){
        try {
            logger.info("Inside /reference/address: param1= "+address + "param2+"+limit +"param3+"+as +"param4+"+addressFormat+"param5+"+callback);
            String response = addressService.searchAddress(address,limit,as,addressFormat,callback);
            logger.info("Exiting searchAddress");
            return new ResponseEntity<Object>(response, HttpStatus.OK);

        }catch (Exception ex)
        {   Error error= new Error();
            logger.error(ex.getMessage());
            return new ResponseEntity<Object>(commonUtility.setExceptionResponse(ex),HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/addresses/healthcheck" , method = RequestMethod.GET)
    public @ResponseBody String healthcheck(){
        return "SUCCESS";
    }


    @RequestMapping(value = PATH)
    public String error() {
        return "Internal System Error";
    }

    @Override
    public String getErrorPath() {
        return PATH;
    }
}

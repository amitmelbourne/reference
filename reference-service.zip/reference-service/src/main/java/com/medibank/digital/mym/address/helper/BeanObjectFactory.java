package com.medibank.digital.mym.address.helper;

import com.medibank.digital.mym.address.model.Address;
import com.medibank.digital.mym.address.model.Error;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public class BeanObjectFactory {


    @Lookup
    public Error getError(){
        return null;
    }

    @Lookup
    public Address getAddress(){
        return null;
    }





}

package com.medibank.digital.mym.address.interceptors;

import com.medibank.digital.mym.address.model.LogModel;
import com.medibank.digital.mym.address.util.LogRecordSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Map;

public class CustomLoggingFilter extends CommonsRequestLoggingFilter {

    public static final Logger EVENT_DEBUG_LOG = LoggerFactory.getLogger("FILE");

    private LogRecordSerializer logRecordSerializer = new LogRecordSerializer(Arrays.asList("payload"), "payload");

    @Override
    protected boolean shouldLog(HttpServletRequest request) {
        return true;
    }

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {
        super.beforeRequest(request, message);
        logger.info(message);
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {
        super.afterRequest(request, message);
        logger.info(message);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if (isAsyncDispatch(request)) {
            filterChain.doFilter(request, response);
        } else {
            doFilterWrapped(wrapRequest(request), wrapResponse(response), filterChain);
        }
    }

    protected void doFilterWrapped(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response, FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(request, response);
        } finally {
            if (!request.getRequestURI().contains("healthcheck")) {
                logRequest(request);
                logResponse(request, response);
                response.copyBodyToResponse();
            }
        }
    }


    private void logResponse(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response) throws IOException {
        byte[] content = response.getContentAsByteArray();
        String responseBody = "";
        if (content.length > 0) {
            responseBody = new String(response.getContentAsByteArray());
        }
        LogModel logModel = new LogModel();
        logModel.setLoggingHost(getHostName(request.getRequestURL().toString()));
        logModel.setOperation(request.getMethod()+ " "+ request.getRequestURI() );
        logModel.setStatus(Integer.toString(response.getStatusCode()));

        logModel.setTxnState("API_Response_Sent");
        logModel.setPayload(responseBody);
        EVENT_DEBUG_LOG.info(logRecordSerializer.serialize(logModel));
    }

    private void logRequest(ContentCachingRequestWrapper request) throws IOException {
        byte[] content = request.getContentAsByteArray();
        String requestBody = "";
        if (content.length > 0) {
            requestBody = new String(request.getContentAsByteArray());
        }
        LogModel logModel = new LogModel();

        logModel.setLoggingHost(getHostName(request.getRequestURL().toString()));
        logModel.setOperation(request.getMethod()+ " "+ request.getRequestURI() );
        logModel.setTxnState("API_Request_Received");
        logModel.setPayload(requestBody);
        StringBuffer queryParams = new StringBuffer();
        for ( Map.Entry<String, String[]> entry: request.getParameterMap().entrySet()){
            queryParams.append(entry.getKey())
                       .append("-")
                       .append(entry.getValue()[0])
                       .append(";");
        }
        if (queryParams.length() > 0) {
            logModel.setQueryParams(queryParams.toString());
        }
        EVENT_DEBUG_LOG.info(logRecordSerializer.serialize(logModel));
    }

    private static ContentCachingRequestWrapper wrapRequest(HttpServletRequest request) {
        if (request instanceof ContentCachingRequestWrapper) {
            return (ContentCachingRequestWrapper) request;
        } else {
            return new ContentCachingRequestWrapper(request);
        }
    }

    private static ContentCachingResponseWrapper wrapResponse(HttpServletResponse response) {
        if (response instanceof ContentCachingResponseWrapper) {
            return (ContentCachingResponseWrapper) response;
        } else {
            return new ContentCachingResponseWrapper(response);
        }
    }

    private static String getHostName(String urlString) throws MalformedURLException {
        URL url = new URL(urlString);
        return url.getHost();
    }
}

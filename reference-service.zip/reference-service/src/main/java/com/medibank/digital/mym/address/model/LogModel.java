package com.medibank.digital.mym.address.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.springframework.stereotype.Component;

@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"transactionId", "bpId", "operation", "queryParams", "status", "txnState","loggingComponent", "loggingHost", "referer", "payload"})
public class LogModel {

    @JsonProperty("transactionId")
    private String transactionId;

    @JsonProperty("bpId")
    private String bpId;

    @JsonProperty("operation")
    private String operation;

    @JsonProperty("status")
    private String status;

    @JsonProperty("txnState")
    private String txnState;

    @JsonProperty("loggingComponent")
    private String loggingComponent;

    @JsonProperty("loggingHost")
    private String loggingHost;

    @JsonProperty("referer")
    private String referer;

    @JsonProperty("queryParams")
    private String queryParams;

    @JsonProperty("payload")
    private String payload;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getBpId() {
        return bpId;
    }

    public void setBpId(String bpId) {
        this.bpId = bpId;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTxnState() {
        return txnState;
    }

    public void setTxnState(String txnState) {
        this.txnState = txnState;
    }

    public String getLoggingComponent() {
        return loggingComponent;
    }

    public void setLoggingComponent(String loggingComponent) {
        this.loggingComponent = loggingComponent;
    }

    public String getLoggingHost() {
        return loggingHost;
    }

    public void setLoggingHost(String loggingHost) {
        this.loggingHost = loggingHost;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public String getQueryParams() { return queryParams; }

    public void setQueryParams(String queryParams) { this.queryParams = queryParams; }

    public String getReferer() {
        return referer;
    }

    public void setReferer(String referer) {
        this.referer = referer;
    }
}

package com.medibank.digital.mym.address.services;


import com.medibank.digital.mym.address.helper.BeanObjectFactory;
import com.medibank.digital.mym.address.model.Address;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;


/**
 * Created by 920465 on 12/18/2017.
 */
@Service
public class AddressService {

    private static final Logger logger = LoggerFactory.getLogger(AddressService.class);

    @Autowired
    private BeanObjectFactory beanObjectFactory;

    @Value("${app.config.address.veda.username}")
    private String apiUserName;

    @Value("${app.config.address.veda.password}")
    private String apiPassword;

    @Value("${app.config.address.validation.veda.endpoint.url}")
    private String url;

    @Value("${app.config.address.search.veda.endpoint.url}")
    private String autocompleteUrl;

    @Value("${api.config.proxy.host}")
    private String httpProxy;

    @Value("${api.config.proxy.port}")
    private Integer port;

    //private static String url = "http://localhost:8080/autocomplete/address/validateAddress";


    public Address validateAddress(String selectedAddress) throws Exception {

        logger.info("Inside validateAddress");
        URIBuilder uri=new URIBuilder(url);
        uri.addParameter("address",selectedAddress);
        String finalUrl = uri.toString();
        logger.info("HTTP url: "+finalUrl);
        // Create a method instance.
        HttpGet method = new HttpGet(finalUrl);

        try {
            // Create an instance of HttpClient.
            CloseableHttpClient client = getCloseableHttpClient();

            HttpResponse response = client.execute(method);

            String responseBody = getStringFromInputStream(response.getEntity().getContent());

            logger.info("response body: "+ responseBody );

            if(response.getStatusLine().getStatusCode()== HttpStatus.SC_OK) {
                JSONObject jsonResponse = new JSONObject(responseBody);

                String line2 = (String) jsonResponse.get("StreetAddress2");
                String suburb = (String) jsonResponse.get("LocName1");
                String state = (String) jsonResponse.get("State");
                String pc = (String) jsonResponse.get("PostCode");
                Address address = beanObjectFactory.getAddress();

                if(!line2.equalsIgnoreCase(suburb+" "+state+" "+pc)){
                    address.setLine2((String) jsonResponse.get("StreetAddress2"));
                }
                else {
                    address.setLine2("");
                }

                address.setLine1((String) jsonResponse.get("StreetAddress1"));
                address.setSuburb(suburb);//need to confirm
                address.setState(state);
                address.setPostcode(pc);
                logger.info("response: "+jsonResponse.toString());
                logger.info("Exiting validateAddress");
                return address;
            }
            else{
                throw new Exception(response.getStatusLine().toString());
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
            throw new Exception("Error occurred while validating address ");
        } finally {
            // Release the connection.
            method.releaseConnection();
        }

    }

    public String searchAddress(String searchAddress,String limit,String as,String addressFormat,String callback) throws Exception {

        logger.info("Inside validateAddress");
        URIBuilder uri=new URIBuilder(autocompleteUrl);
        uri.addParameter("address",searchAddress);
        uri.addParameter("limit",limit);
        uri.addParameter("as",as);
        uri.addParameter("addressFormat",addressFormat);
        uri.addParameter("callback",callback);
        String finalUrl = uri.toString();
        logger.info("HTTP url: "+finalUrl);
        // Create a method instance.
        HttpGet method = new HttpGet(finalUrl);

        try {
            // Create an instance of HttpClient.
            CloseableHttpClient client = getCloseableHttpClient();

            HttpResponse response = client.execute(method);

            String responseBody = getStringFromInputStream(response.getEntity().getContent());

            logger.info("response body: "+ responseBody );

            if(response.getStatusLine().getStatusCode()== HttpStatus.SC_OK) {
                JSONObject jsonResponse = new JSONObject(responseBody);
                logger.info("response: "+jsonResponse.toString());
                logger.info("Exiting searchAddress");
                return jsonResponse.toString();
            }
            else{
                throw new Exception(response.getStatusLine().toString());
            }
        } catch (IOException e) {
            logger.error(e.getMessage());
            throw new Exception("Error occurred while retrieving address ");
        } finally {
            // Release the connection.
            method.releaseConnection();
        }

    }

    protected CloseableHttpClient getCloseableHttpClient() {
        HttpHost proxy = new HttpHost(httpProxy,port);
        DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
        org.apache.http.client.CredentialsProvider credsProvider = new BasicCredentialsProvider();
        credsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials(apiUserName, apiPassword));
        return HttpClientBuilder.create().setDefaultCredentialsProvider(credsProvider).build();
    }


    private static String getStringFromInputStream(InputStream is) throws Exception{

        BufferedReader br = null;
        StringBuilder sb = new StringBuilder();

        String line;
        try {

            br = new BufferedReader(new InputStreamReader(is));
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        return sb.toString();

    }


}

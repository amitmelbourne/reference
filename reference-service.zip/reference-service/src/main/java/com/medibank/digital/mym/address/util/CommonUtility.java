package com.medibank.digital.mym.address.util;

import com.medibank.digital.mym.address.helper.BeanObjectFactory;
import com.medibank.digital.mym.address.model.Error;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by 920466 on 12/12/2017.
 */
@Component
public class CommonUtility {

    @Autowired
    private BeanObjectFactory beanObjectFactory;


    public Error setExceptionResponse(Exception ex){
        Error error= beanObjectFactory.getError();
        error.setMessage(ex.getMessage());
        return error;
    }
    public static String sysDate(){
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
        return date.format(formatter);
    }

    public static  String addOneDay(String date) {

        return LocalDate.parse(date).plusDays(1).toString();
    }
}

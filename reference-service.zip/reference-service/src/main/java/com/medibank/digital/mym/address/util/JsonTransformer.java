package com.medibank.digital.mym.address.util;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.HashMap;

public class JsonTransformer {
    private static final ObjectMapper MAPPER = new ObjectMapper(); // Jackson's JSON marshaller
    static {
        MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * Keep it static
     */
    private JsonTransformer() {}

    /**
     * Serializes an Object to its JSON representation
     */
    public static <T> String toString(T obj) {
        try {
            return MAPPER.writeValueAsString(obj);
        } catch (IOException e) {
            throw new RuntimeException("Error serializing object to JSON", e);
        }
    }

    /**
     * Deserializes an Object of clazz from its JSON representation
     */
    public static <T> T fromString(String json, Class<T> clazz) {
        T o = null;
        if (json != null && json.length() > 0) {
            try {
                o = MAPPER.readValue(json, clazz);
            } catch (IOException e) {
                throw new IllegalArgumentException("Error deserializing JSON to object", e);
            }
        }
        return o;
    }

    /**
     * Serializes an Object to its JSON representation
     */
    public static <T> HashMap<String,Object> jsonToMap(T obj) throws IOException {
        TypeReference<HashMap<String, Object>> typeRef = new TypeReference<HashMap<String, Object>>() {};

        return MAPPER.readValue(toString(obj), typeRef);
    }
}

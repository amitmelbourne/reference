package com.medibank.digital.mym.address.util;

import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Serializes different objects to log record given format:
 * {@code (?<key_value>.*) payload=(?<payload>.*)$}
 *
 * @author dmitry.pokidov
 */
public class LogRecordSerializer {
    private static final String PAYLOAD_FIELD_NAME = "payload";

    private List<String> dataFields;
    private String payloadField;

    /**
     * Creates a new log record serializer.
     * {@code payload} argument is required and can't be blank.
     * @param dataFields
     * @param payloadField
     */
    public LogRecordSerializer(List<String> dataFields, String payloadField) {
        if (StringUtils.isBlank(payloadField)) {
            throw new IllegalArgumentException("Payload field must be defined");
        }

        this.dataFields = dataFields == null ? Collections.<String>emptyList() : dataFields;
        this.payloadField = payloadField;
    }

    /**
     * Serializes {@code event} to key-value map.
     * Each pair is separated by space. All text fields ({@code dataFields})
     * are wrapped in []. The {@code payload} field is writing last.
     * @param event log event, can't be {@code null}
     * @return serialized string
     * @throws IOException {@link IOException} errors
     * @throws IllegalArgumentException if {@code event == null}
     */
    public String serialize(Object event) throws IOException {
        if (event == null) {
            throw new IllegalArgumentException("Log event can't be null");
        }

        StringBuilder sb = new StringBuilder();
        Map<String, Object> map = JsonTransformer.jsonToMap(event);
        String payload = "";
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (payloadField.equals(entry.getKey())) {
                payload = String.valueOf(entry.getValue());
                continue;
            }
            writeField(sb, entry.getKey(), entry.getValue());
        }

        writeField(sb, PAYLOAD_FIELD_NAME, payload);

        return sb.toString();
    }

    private void writeField(StringBuilder sb, String key, Object value) {
        if (sb.length() > 0) {
            sb.append(" ");
        }

        sb.append(key).append("=");

        boolean isDataField = dataFields.contains(key) || PAYLOAD_FIELD_NAME.equals(key);
        if (isDataField) {
            sb.append("[");
        }
        sb.append(value);
        if (isDataField) {
            sb.append("]");
        }
    }
}

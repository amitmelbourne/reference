package com.medibank.digital.mym.address.util;


import com.medibank.digital.mym.address.interceptors.CustomLoggingFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;


@Configuration
public class RequestLoggingFilterConfigurer {

    @Bean
    public CommonsRequestLoggingFilter requestLoggingFilter() {
        CustomLoggingFilter filter = new CustomLoggingFilter();
        filter.setIncludeQueryString(true);
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(1000);
        filter.setIncludeHeaders(false);
        filter.setAfterMessagePrefix("Request received: ");
        return filter;
    }
}
